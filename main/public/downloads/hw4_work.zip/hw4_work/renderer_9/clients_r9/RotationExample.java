/*
 * Renderer 9. The MIT License.
 * Copyright (c) 2022 rlkraft@pnw.edu
 * See LICENSE for details.
*/

import renderer.scene.*;
import renderer.scene.util.Assets;
import renderer.scene.util.ModelShading;
import renderer.models_L.*;
import renderer.pipeline.*;
import renderer.framebuffer.*;

import java.io.File;
import java.awt.Color;

/**
   Use this program to experiment with two-dimensional rotations.
<p>
   Suppose you want to rotate a 2D model around the point (a,b) in
   the model's coordinates, and you want this rotation to happen at
   the point (c,d) in world coordinates. You would do that with the
   following three transformations.
   <pre>{@code
      Matrix m = Matrix.translate(c, d, 0)
         .times( Matrix.rotateZ(theta) )
         .times( Matrix.translate(-a, -b, 0) );
   }</pre>
   Try to do the following. The bronto's nose is at the point
   (x, y) = (0.0834, 0.8540) in the bronto's model coordinates.
   Rotate the bronto around its nose but have the nose located
   at the point (0, 1.5) in the world coordinate system.
<p>
   The tip of the bronto's tail is at the point
   (x, y) = (0.9882, 0.3098) in the bronto's model
   coordinates. Try rotating the bronto around the
   tip of its tail.
*/
public class RotationExample
{
   private static final String assets = Assets.getPath();

   public static void main(String[] args)
   {
      // Use orthographic projection.
      final Scene scene = new Scene("RotationExample",
                                    Camera.projOrtho());

      // Create a 2D Model object.
      final Model m = new GRSModel(new File(assets + "grs/bronto.grs"));
      ModelShading.setColor(m, Color.black);
      scene.positionList.add( new Position(m) );

      // Create a set of x and y axes.
      final Model axes = new Axes2D(-1, +1, -1, +1, 24, 24);
      ModelShading.setColor(axes, Color.red);
      scene.positionList.add( new Position(axes) );

      // Create a framebuffer to render our scene into.
      final int width  = 512;
      final int height = 512;
      final FrameBuffer fb = new FrameBuffer(width, height, Color.gray);

      for (int i = 0; i <= 36; ++i)
      {
         // Rotate the center of the bronto around the point (-1, 2).
         final Matrix m1 = Matrix.scale(0.33) // scale the model to fit in the view rectangle
                   .times( Matrix.translate(-1, 2, 0) )
                   .times( Matrix.rotateZ(10*i) )
                   .times( Matrix.translate(-0.5, -0.5, 0) );

         scene.getPosition(0).transform(m1);

         // Render again.
         fb.clearFB();
         Pipeline.render(scene, fb);
         fb.dumpFB2File(String.format("PPM_RotationExample_a_Frame%02d.ppm", i));
      }

      for (int i = 0; i <= 36; ++i)
      {
         // Rotate the bronto's nose around the point (0, 1.5).
         final Matrix m2 = Matrix.scale(0.33) // scale the model to fit in the view rectangle
                   .times( Matrix.translate(0, 1.5, 0) )
                   .times( Matrix.rotateZ(10*i) )
                   .times( Matrix.translate(-0.0834, -0.8540, 0) );

         scene.getPosition(0).transform(m2);

         // Render again.
         fb.clearFB();
         Pipeline.render(scene, fb);
         fb.dumpFB2File(String.format("PPM_RotationExample_b_Frame%02d.ppm", i));
      }
   }
}

/*
In this file, the matrix multiplication T(c,d)*R_z(theta)*T(-a,-b)
is implemented with this code.

      Matrix m = Matrix.translate(c, d, 0)
         .times( Matrix.rotateZ(theta) )
         .times( Matrix.translate(-a, -b, 0) );

These three transformations can be implemented in this other way
(make sure you can see the subtle difference).

      Matrix m = Matrix.translate(c, d, 0)
         .times( Matrix.rotateZ(theta)
         .times( Matrix.translate(-a, -b, 0) ) );
*/
