/*
 * Renderer 9. The MIT License.
 * Copyright (c) 2022 rlkraft@pnw.edu
 * See LICENSE for details.
*/

import renderer.scene.*;
import renderer.scene.primitives.LineSegment;
import renderer.scene.util.ModelShading;
import renderer.models_L.Axes2D;
import renderer.pipeline.*;
import renderer.framebuffer.*;

import java.awt.Color;

/**
   Show that a scaling and a translation in the
   x-direction do not commute, that is,
      S_x * T_x != T_x * S_x.

   Show that a rotation and a translation in the
   x-direction do not commute, that is,
      R_z * T_x != T_x * R_z.

   Show how the transformations transform the coordinate system
   when you read the transformations from left-to-right.
*/
public class SimpleExamples_ver2
{
   public static void main(String[] args)
   {
      // Use orthographic projection.
      final Scene scene = new Scene("SimpleExamples_ver2",
                                    Camera.projOrtho(-4, 4, -4, 4));

      final Model axes = new Axes2D(-4, 4, -4, 4, 8, 8, Color.red);
      scene.addPosition(new Position(axes));

      final Model model = new Model();
      model.addVertex(new Vertex(0, 0, 0),
                      new Vertex(1, 0, 0));
      model.addPrimitive(new LineSegment(0, 1));
      ModelShading.setColor(model, Color.green);

      final Position position = new Position(model);
      scene.addPosition(position);

      final int fb_width  = 512;
      final int fb_height = 512;
      final FrameBuffer fb = new FrameBuffer(fb_width, fb_height, Color.black);

      fb.clearFB();
      Pipeline.render(scene, fb);
      fb.dumpFB2File("SimpleExamples_ver2_a_Model.ppm");

      // S_x * T_x
      // Show the transformed coordinate systems.
      model.visible = false;
      ModelShading.setColor(axes, Color.white);
      scene.getPosition(0).transform(Matrix.identity());
      fb.clearFB();
      Pipeline.render(scene, fb);
      fb.dumpFB2File("SimpleExamples_ver2_b_ST_step_0.ppm");
      ModelShading.setColor(axes, Color.blue);
      scene.getPosition(0).transform(Matrix.scale(2, 1, 1));
      Pipeline.render(scene, fb);
      fb.dumpFB2File("SimpleExamples_ver2_b_ST_step_1.ppm");
      ModelShading.setColor(axes, Color.red);
      scene.getPosition(0).transform(Matrix.scale(2, 1, 1)
                              .times(Matrix.translate(1, 0, 0)));
      Pipeline.render(scene, fb);
      fb.dumpFB2File("SimpleExamples_ver2_b_ST_step_2.ppm");
      final Matrix m1 = Matrix.scale(2, 1, 1).times(Matrix.translate(1, 0, 0));
      scene.getPosition(1).transform(m1);
      model.visible = true;
      Pipeline.render(scene, fb);
      fb.dumpFB2File("SimpleExamples_ver2_b_ST_step_3.ppm");


      // T_x * S_x
      // Show the transformed coordinate systems.
      model.visible = false;
      ModelShading.setColor(axes, Color.white);
      scene.getPosition(0).transform(Matrix.identity());
      fb.clearFB();
      Pipeline.render(scene, fb);
      fb.dumpFB2File("SimpleExamples_ver2_c_TS_step_0.ppm");
      ModelShading.setColor(axes, Color.blue);
      scene.getPosition(0).transform(Matrix.translate(1, 0, 0));
      Pipeline.render(scene, fb);
      fb.dumpFB2File("SimpleExamples_ver2_c_TS_step_1.ppm");
      ModelShading.setColor(axes, Color.red);
      scene.getPosition(0).transform(Matrix.translate(1, 0, 0)
                              .times(Matrix.scale(2, 1, 1)));
      Pipeline.render(scene, fb);
      fb.dumpFB2File("SimpleExamples_ver2_c_TS_step_2.ppm");
      final Matrix m2 = Matrix.translate(1, 0, 0).times(Matrix.scale(2, 1, 1));
      scene.getPosition(1).transform(m2);
      model.visible = true;
      Pipeline.render(scene, fb);
      fb.dumpFB2File("SimpleExamples_ver2_c_TS_step_3.ppm");


      // R_z * T_x
      // Show the transformed coordinate systems.
      model.visible = false;
      ModelShading.setColor(axes, Color.white);
      scene.getPosition(0).transform(Matrix.identity());
      fb.clearFB();
      Pipeline.render(scene, fb);
      fb.dumpFB2File("SimpleExamples_ver2_d_RT_step_0.ppm");
      ModelShading.setColor(axes, Color.blue);
      scene.getPosition(0).transform(Matrix.rotateZ(45));
      Pipeline.render(scene, fb);
      fb.dumpFB2File("SimpleExamples_ver2_d_RT_step_1.ppm");
      ModelShading.setColor(axes, Color.red);
      scene.getPosition(0).transform(Matrix.rotateZ(45)
                              .times(Matrix.translate(1, 0, 0)));
      Pipeline.render(scene, fb);
      fb.dumpFB2File("SimpleExamples_ver2_d_RT_step_2.ppm");
      final Matrix m3 = Matrix.rotateZ(45).times(Matrix.translate(1, 0, 0));
      scene.getPosition(1).transform(m3);
      model.visible = true;
      Pipeline.render(scene, fb);
      fb.dumpFB2File("SimpleExamples_ver2_d_RT_step_3.ppm");


      // T_x * R_z
      // Show the transformed coordinate systems.
      model.visible = false;
      ModelShading.setColor(axes, Color.white);
      scene.getPosition(0).transform(Matrix.identity());
      fb.clearFB();
      Pipeline.render(scene, fb);
      fb.dumpFB2File("SimpleExamples_ver2_e_TR_step_0.ppm");
      ModelShading.setColor(axes, Color.blue);
      scene.getPosition(0).transform(Matrix.translate(1, 0, 0));
      Pipeline.render(scene, fb);
      fb.dumpFB2File("SimpleExamples_ver2_e_TR_step_1.ppm");
      ModelShading.setColor(axes, Color.red);
      scene.getPosition(0).transform(Matrix.translate(1, 0, 0)
                              .times(Matrix.rotateZ(45)));
      Pipeline.render(scene, fb);
      fb.dumpFB2File("SimpleExamples_ver2_e_TR_step_2.ppm");
      final Matrix m4 = Matrix.translate(1, 0, 0).times(Matrix.rotateZ(45));
      scene.getPosition(1).transform(m4);
      model.visible = true;
      Pipeline.render(scene, fb);
      fb.dumpFB2File("SimpleExamples_ver2_e_TR_step_3.ppm");
   }
}
/*
            Scene
              |
              |
           Position
           /      \
          /        \
       S * T      Model
    or T * S
    or R * T
    or T * R
*/
