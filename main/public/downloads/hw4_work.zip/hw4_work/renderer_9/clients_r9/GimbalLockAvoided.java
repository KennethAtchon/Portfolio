/*
 * Renderer 9. The MIT License.
 * Copyright (c) 2022 rlkraft@pnw.edu
 * See LICENSE for details.
*/

import renderer.scene.*;
import renderer.scene.util.Assets;
import renderer.scene.util.ModelShading;
import renderer.models_L.*;
import renderer.framebuffer.FrameBufferPanel;

import java.awt.Color;
import javax.swing.JFrame;
import java.awt.BorderLayout;
import java.awt.event.KeyEvent;
import java.io.File;

/**
   In {@link GimbalLock} we implementated all rotations
   as a product of three rotations like this
   <pre>{@code
      R_z(a3) * R_y(a2) * R_x(a1)
   }</pre>
   Unfortunately, this scheme can cause gimbal lock.
<p>
   In this program we implemet rotations in a way that
   avoids gimbal lock.
<p>
   The main idea in this program is to accumulate rotations.
   If {@code R_acc} is the current rotation matrix of the model
   and the user asks for an additional rotation {@code R} (where
   {@code R} will be either {@code R_x}, {@code R_y}, or {@code R_z}),
   then the new accumulated rotation matrix of the model can be
   either
   <pre>{@code
      R_acc = R_acc * R
   }</pre>
   or
   <pre>{@code
      R_acc = R * R_acc
   }</pre>
   depending on whether we wish to accumulate the additional rotation
   on the right or on the left of the current rotation.
   <p>
   In this program, the key commands x, X, y, Y, z, Z cause the additional
   rotation to be accumulated on the left of the current rotation.
   <p>
   The key combinations Alt-x, Alt-X, Alt-y, Alt-Y, Alt-z, Alt-Z cause the
   additional rotation to be accumulated on the right of the current rotation.
   <p>
   Accumulating rotations on the right implements roll, yaw, and pitch rotations
   of the model.
   <p>
   Accumulating rotations on the left implements rotations of the model around
   a fixed x-axis, y-axis, and z-axis.
*/
public class GimbalLockAvoided extends InteractiveAbstractClient_R9
{
   private static final String assets = Assets.getPath();

   private final double deltaAngle = 1.0;

   protected double[] rollRotation = {0.0};
   protected double[] pitchRotation = {0.0};
   protected double[] yawRotation = {0.0};

   /**
      This constructor instantiates the Scene object
      and initializes it with appropriate geometry.
      Then this constructor instantiates the GUI.
   */
   public GimbalLockAvoided()
   {
      scene = new Scene("GimbalLockAvoided",
                        Camera.projOrtho(fovy, aspectRatio));
      this.perspective = false;

      // Create several Model objects.
      scene.addPosition(new Position(new ObjSimpleModel(new File(assets + "cessna.obj"))));
      scene.addPosition(new Position(new ObjSimpleModel(new File(assets + "galleon.obj"))));
      scene.addPosition(new Position(new ObjSimpleModel(new File(assets + "cow.obj"))));
      scene.addPosition(new Position(new ObjSimpleModel(new File(assets + "horse.obj"))));

      // Give each model a random color.
      for (final Position p : scene.positionList)
      {
         ModelShading.setRandomColor(p.getModel());
      }

      // Create a set of x and y axes.
      final Model axes = new Axes2D(-1, +1, -1, +1, 20, 20);
      ModelShading.setColor(axes, Color.red);
      final Position axes_p = new Position(axes);
      scene.addPosition(axes_p);

      // Make the interactive models invisible, except for the current model.
      numberOfInteractiveModels = scene.positionList.size() - 1;
      for (int i = 0; i < numberOfInteractiveModels; ++i)
      {
         scene.getPosition(i).visible = false;
      }

      currentModel = 0; // airplane
      scene.getPosition(currentModel).visible = true;
      interactiveModelsAllVisible = false;

      showMatrix = true;


      // Create a FrameBufferPanel that holds a FrameBuffer.
      final int width  = 1024;
      final int height = 1024;
      fbp = new FrameBufferPanel(width, height, Color.darkGray);
      fbp.getFrameBuffer().getViewport().setBackgroundColorVP(Color.black);

      // Create a JFrame that will hold the FrameBufferPanel.
      jf = new JFrame("Renderer 9 - Gimbal Lock Avoided");
      jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      jf.getContentPane().add(fbp, BorderLayout.CENTER);
      jf.pack();
      jf.setLocationRelativeTo(null);
      jf.setVisible(true);

      // Create event handler objects for events from the JFrame.
      jf.addKeyListener(this);
      jf.addComponentListener(this);

      print_help_message();
   }


   @Override protected void setTransformations(final KeyEvent e)
   {
      final char c = e.getKeyChar();

      xRotation[0] = 0.0;
      yRotation[0] = 0.0;
      zRotation[0] = 0.0;
      rollRotation[0] = 0.0;  // X
      yawRotation[0] = 0.0;   // Y
      pitchRotation[0] = 0.0; // Z

      if ('=' == c)
      {
         scene.getPosition(currentModel).transform(Matrix.identity());
      }
      else if ('x' == c && e.isAltDown())
      {
         rollRotation[0] = -deltaAngle;
      }
      else if ('X' == c && e.isAltDown())
      {
         rollRotation[0] = +deltaAngle;
      }
      else if ('y' == c && e.isAltDown())
      {
         yawRotation[0] = -deltaAngle;
      }
      else if ('Y' == c && e.isAltDown())
      {
         yawRotation[0] = +deltaAngle;
      }
      else if ('z' == c && e.isAltDown())
      {
         pitchRotation[0] = -deltaAngle;
      }
      else if ('Z' == c && e.isAltDown())
      {
         pitchRotation[0] = +deltaAngle;
      }
      else if ('x' == c)
      {
         xRotation[0] = -deltaAngle;
      }
      else if ('X' == c)
      {
         xRotation[0] = +deltaAngle;
      }
      else if ('y' == c)
      {
         yRotation[0] = -deltaAngle;
      }
      else if ('Y' == c)
      {
         yRotation[0] = +deltaAngle;
      }
      else if ('z' == c)
      {
         zRotation[0] = -deltaAngle;
      }
      else if ('Z' == c)
      {
         zRotation[0] = +deltaAngle;
      }
      else if ('-' == c) // for debugging, "eulerize" the rotations
      {
         final Matrix m = scene.getPosition(currentModel).getMatrix();
/*
         System.out.println("---------");
         System.out.println( m );
         double[] eulerAngles = m.rot2euler();
         System.out.printf("e_x = %f, e_y = %f, e_z = %f\n",
                            eulerAngles[0]*(180.0/Math.PI),
                            eulerAngles[1]*(180.0/Math.PI),
                            eulerAngles[2]*(180.0/Math.PI));
         System.out.println("---------");
*/
         scene.getPosition(currentModel).transform(m.eulerize());
      }

      final Matrix m1 = scene.getPosition(currentModel).getMatrix();
      // Accumulate one new rotation. At most one of the following
      // rotations will be a rotation by (plus or minus) 5 degrees,
      // the other rotations will be I.
      final Matrix m2 = Matrix.rotateZ(zRotation[0])
                 .times(Matrix.rotateY(yRotation[0]))
                 .times(Matrix.rotateX(xRotation[0]))
                 .times(m1)
                 .times(Matrix.rotateZ(pitchRotation[0])) // X
                 .times(Matrix.rotateY(yawRotation[0]))   // Y
                 .times(Matrix.rotateX(rollRotation[0])); // Z

      scene.getPosition(currentModel).transform(m2);
   }


   @Override protected void displayMatrix(final KeyEvent e)
   {
      final char c = e.getKeyChar();

      if (showMatrix && ('m'==c||'='==c||'-'==c
                       ||'x'==c||'y'==c||'z'==c
                       ||'X'==c||'Y'==c||'Z'==c))
      {
         System.out.println("xRot = " + xRotation[0]
                        + ", yRot = " + yRotation[0]
                        + ", zRot = " + zRotation[0]);
         System.out.println("roll = " + rollRotation[0]
                         + ", yaw = " + yawRotation[0]
                       + ", pitch = " + pitchRotation[0]);
         final Matrix m = scene.getPosition(currentModel).getMatrix();
         System.out.println( m );
         double[] eulerAngles = m.rot2euler();
         System.out.printf(" e_x = %f, e_y = %f, e_z = %f\n",
                            eulerAngles[0]*(180.0/Math.PI),
                            eulerAngles[1]*(180.0/Math.PI),
                            eulerAngles[2]*(180.0/Math.PI));
      }
   }


   public void print_help_message()
   {
      System.out.println("Use the '/' key to cycle through the models.");
      System.out.println("Use the 'p' key to toggle between parallel and orthographic projection.");
      System.out.println("Use the x/X, y/Y, z/Z, keys to rotate the models around the x, y, z axes.");
      System.out.println("Use Alt x/X, y/Y, z/Z  for roll/yaw/pitch rotations.");
      System.out.println("Use the 'm' key to toggle the display of matrix information.");
      System.out.println("Use the 'c' key to change the random solid model color.");
      System.out.println("Use the 'C' key to randomly change model's colors.");
    //System.out.println("Use the 'e' key to change the random vertex colors.");
      System.out.println("Use the 'e' key to change the random solid edge colors.");
      System.out.println("Use the 'E' key to change the random edge colors.");
      System.out.println("Use the 'a' key to toggle antialiasing on and off.");
      System.out.println("Use the 'g' key to toggle gamma correction on and off.");
      System.out.println("Use the '=' key to reset the Model transformation matrix to the identity.");
      System.out.println("Use the '-' key to \"eulerize\" the Model transformation matrix.");
      System.out.println("Use the '+' key to save a \"screenshot\" of the framebuffer.");
      System.out.println("Use the 'h' key to redisplay this help message.");
      System.out.println();
   }


   /**
      Create an instance of this class which has
      the affect of creating the GUI application.
   */
   public static void main(String[] args)
   {
      // We need to call the program's constructor in the
      // Java GUI Event Dispatch Thread, otherwise we get a
      // race condition between the constructor (running in
      // the main() thread) and the very first ComponentEvent
      // (running in the EDT).
      javax.swing.SwingUtilities.invokeLater(
         () -> new GimbalLockAvoided()
      );
   }
}
