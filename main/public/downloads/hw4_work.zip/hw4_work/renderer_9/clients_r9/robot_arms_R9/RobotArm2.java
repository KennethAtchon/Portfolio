/*
 * Renderer 9. The MIT License.
 * Copyright (c) 2022 rlkraft@pnw.edu
 * See LICENSE for details.
*/

import renderer.scene.*;
import renderer.scene.primitives.*;
import renderer.scene.util.ModelShading;
import renderer.scene.util.DrawSceneGraph;
import renderer.pipeline.*;
import renderer.framebuffer.*;

import java.awt.Color;
import javax.swing.JFrame;
import java.awt.BorderLayout;
import java.awt.event.KeyListener;
import java.awt.event.KeyEvent;
import java.awt.event.ComponentListener;
import java.awt.event.ComponentEvent;

/**
   Draw an interactive robot arm with shoulder, elbow, wrist, and finger joints.
<p>
   The tree for this scene is shown below.
<p>
   Remember that every position node in the tree contains a matrix
   and a model.
<p>
<pre>{@code
            Scene
           /     \
          /       \
    Camera        List<Position>
                 /   \    \    \----------------------\
                /     \    \                           \
               /       \    \----------\                \
              /         \               \                \
       Position        Position         Position         Position
         / \            /   \            /   \            /    |
        /   \          /     \          /     \          /     |
  Matrix     \      Matrix    \      Matrix    \    Matrix     |
    RS        \     RSTRS      \    RSTRSTRS   /  RSTRSTRSTRS /
               \                \             /              /
                \                \           /              /
                 \--------------Model-------/              /
                               armSegment-----------------/
</pre>
*/
public class RobotArm2 implements KeyListener, ComponentListener
{
   private double shoulderRotation = 0.0;
   private double    elbowRotation = 0.0;
   private double    wristRotation = 0.0;
   private double   fingerRotation = 0.0;

   private double shoulderLength = 0.4;
   private double    elbowLength = 0.3;
   private double    wristLength = 0.2;
   private double   fingerLength = 0.1;

   private final Scene scene;
   private final Position shoulder_p;
   private final Position elbow_p;
   private final Position wrist_p;
   private final Position finger_p;

   private boolean takeScreenshot = false;
   private int screenshotNumber = 0;

   private boolean useRenderer1 = true;

   private final JFrame jf;
   private final FrameBufferPanel fbp;

   /**
      This constructor instantiates the Scene object
      and initializes it with appropriate geometry.
      Then this constructor instantiates the GUI.
   */
   public RobotArm2()
   {
      // Create one Model that can be used
      // for each segment of the robot arm.
      final Vertex v0 = new Vertex(0, 0, 0);
      final Vertex v1 = new Vertex(1, 0, 0);
      final Model armSegment = new Model("arm_segment");
      armSegment.addVertex(v0, v1);
      armSegment.addPrimitive(new LineSegment(0, 1));
      ModelShading.setColor(armSegment, Color.blue);

      scene = new Scene("Robot Arm 2",
                        Camera.projOrtho());

      shoulder_p = new Position(armSegment,
                                "shoulder",
                                Matrix.scale(shoulderLength,
                                             shoulderLength,
                                             1) );
      scene.addPosition(shoulder_p);

      elbow_p = new Position(armSegment,
                             "elbow",
                             Matrix.scale(shoulderLength,
                                          shoulderLength,
                                          1)
                      .times(Matrix.translate(1, 0, 0))
                      .times(Matrix.scale(elbowLength/shoulderLength,
                                          elbowLength/shoulderLength,
                                          1)) );
      scene.addPosition(elbow_p);

      wrist_p = new Position(armSegment,
                             "wrist",
                             Matrix.scale(shoulderLength,
                                          shoulderLength,
                                          1)
                      .times(Matrix.translate(1, 0, 0))
                      .times(Matrix.scale(elbowLength/shoulderLength,
                                          elbowLength/shoulderLength,
                                          1))
                      .times(Matrix.translate(1, 0, 0))
                      .times(Matrix.scale(wristLength/elbowLength,
                                          wristLength/elbowLength,
                                          1)) );
      scene.addPosition(wrist_p);

      finger_p = new Position(armSegment,
                              "finger",
                              Matrix.scale(shoulderLength,
                                          shoulderLength,
                                          1)
                       .times(Matrix.translate(1, 0, 0))
                       .times(Matrix.scale(elbowLength/shoulderLength,
                                           elbowLength/shoulderLength,
                                           1))
                       .times(Matrix.translate(1, 0, 0))
                       .times(Matrix.scale(wristLength/elbowLength,
                                           wristLength/elbowLength,
                                           1))
                       .times(Matrix.translate(1, 0, 0))
                       .times(Matrix.scale(fingerLength/wristLength,
                                           fingerLength/wristLength,
                                           1)) );
      scene.addPosition(finger_p);

      DrawSceneGraph.draw(scene, "RobotArm_2");


      // Create a FrameBufferPanel that holds a FrameBuffer.
      final int width  = 1024;
      final int height = 1024;
      fbp = new FrameBufferPanel(width, height, Color.black);

      // Create a JFrame that will hold the FrameBufferPanel.
      jf = new JFrame("Renderer 9 - Robot Arm 2");
      jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      jf.getContentPane().add(fbp, BorderLayout.CENTER);
      jf.pack();
      jf.setLocationRelativeTo(null);
      jf.setVisible(true);

      // Create event handler objects for events from the JFrame.
      jf.addKeyListener(this);
      jf.addComponentListener(this);

      print_help_message();
   }


   // Implement the KeyListener interface.
   @Override public void keyPressed(KeyEvent e){}
   @Override public void keyReleased(KeyEvent e){}
   @Override public void keyTyped(KeyEvent e)
   {
      //System.out.println( e );

      final char c = e.getKeyChar();
      if ('h' == c)
      {
         print_help_message();
         return;
      }
      else if ('d' == c && e.isAltDown())
      {
         System.out.println();
         System.out.println( scene );
      }
      else if ('d' == c)
      {
         scene.debug = ! scene.debug;
         Clip.debug = scene.debug;
      }
      else if ('D' == c)
      {
         Rasterize.debug = ! Rasterize.debug;
      }
      else if ('1' == c)
      {
         if (! useRenderer1)
         {
            useRenderer1 = true;
         }
         System.out.println("Using Pipeline 1.");
      }
      else if ('2' == c)
      {
         if (useRenderer1)
         {
            useRenderer1 = false;
         }
         System.out.println("Using Pipeline 2.");
      }
      else if ('c' == c)
      {
         // Change the solid random color of the robot arm.
         final Color color = ModelShading.randomColor();
         ModelShading.setColor(shoulder_p.getModel(), color);
      }
      else if ('C' == c)
      {
         // Change the solid random color of each segment of the robot arm.
         ModelShading.setRandomColor(shoulder_p.getModel());
         ModelShading.setRandomColor(elbow_p.getModel());
         ModelShading.setRandomColor(wrist_p.getModel());
         ModelShading.setRandomColor(finger_p.getModel());
      }
      else if ('r' == c)
      {
         // Change the random color at each end of each segment of the robot arm.
         ModelShading.setRainbowPrimitiveColors(shoulder_p.getModel());
      }
      else if ('R' == c)
      {
         // Change the random color at each vertex of the robot arm.
         final Color c1 = ModelShading.randomColor();
         final Color c2 = ModelShading.randomColor();
         shoulder_p.getModel().colorList.clear();
         shoulder_p.getModel().addColor(c1, c2);
         shoulder_p.getModel().getPrimitive(0).setColorIndices(0, 1);
      }
      else if ('=' == c)
      {
         shoulderRotation = 0.0;
            elbowRotation = 0.0;
            wristRotation = 0.0;
           fingerRotation = 0.0;
      }
      else if ('s' == c)
      {
         shoulderRotation += 2.0;
      }
      else if ('S' == c)
      {
         shoulderRotation -= 2.0;
      }
      else if ('e' == c)
      {
         elbowRotation += 2.0;
      }
      else if ('E' == c)
      {
         elbowRotation -= 2.0;
      }
      else if ('w' == c)
      {
         wristRotation += 2.0;
      }
      else if ('W' == c)
      {
         wristRotation -= 2.0;
      }
      else if ('f' == c)
      {
         fingerRotation += 2.0;
      }
      else if ('F' == c)
      {
         fingerRotation -= 2.0;
      }
      else if ('+' == c)
      {
         takeScreenshot = true;
      }

      // Update the matrices.
      shoulder_p.transform( Matrix.rotateZ(shoulderRotation)
                     .times(Matrix.scale(shoulderLength,
                                         shoulderLength,
                                         1)) );

      elbow_p.transform( Matrix.rotateZ(shoulderRotation)
                  .times(Matrix.scale(shoulderLength,
                                      shoulderLength,
                                      1))
                  .times(Matrix.translate(1, 0, 0))
                  .times(Matrix.rotateZ(elbowRotation))
                  .times(Matrix.scale(elbowLength/shoulderLength,
                                      elbowLength/shoulderLength,
                                      1)) );

      wrist_p.transform( Matrix.rotateZ(shoulderRotation)
                  .times(Matrix.scale(shoulderLength,
                                      shoulderLength,
                                      1))
                  .times(Matrix.translate(1, 0, 0))
                  .times(Matrix.rotateZ(elbowRotation))
                  .times(Matrix.scale(elbowLength/shoulderLength,
                                      elbowLength/shoulderLength,
                                      1))
                  .times(Matrix.translate(1, 0, 0))
                  .times(Matrix.rotateZ(wristRotation))
                  .times(Matrix.scale(wristLength/elbowLength,
                                      wristLength/elbowLength,
                                      1)) );

      finger_p.transform( Matrix.rotateZ(shoulderRotation)
                   .times(Matrix.scale(shoulderLength,
                                       shoulderLength,
                                       1))
                   .times(Matrix.translate(1, 0, 0))
                   .times(Matrix.rotateZ(elbowRotation))
                   .times(Matrix.scale(elbowLength/shoulderLength,
                                       elbowLength/shoulderLength,
                                       1))
                   .times(Matrix.translate(1, 0, 0))
                   .times(Matrix.rotateZ(wristRotation))
                   .times(Matrix.scale(wristLength/elbowLength,
                                       wristLength/elbowLength,
                                       1))
                   .times(Matrix.translate(1, 0, 0))
                   .times(Matrix.rotateZ(fingerRotation))
                   .times(Matrix.scale(fingerLength/wristLength,
                                       fingerLength/wristLength,
                                       1)) );

      // Render again.
      final FrameBuffer fb = this.fbp.getFrameBuffer();
      fb.clearFB();
      if (useRenderer1)
      {
         Pipeline.render(scene, fb);
      }
      else
      {
         Pipeline2.render(scene, fb);
      }
      if (takeScreenshot)
      {
         fb.dumpFB2File(String.format("Screenshot%03d.png", screenshotNumber), "png");
         ++screenshotNumber;
         takeScreenshot = false;
      }
      fbp.repaint();
   }


   // Implement the ComponentListener interface.
   @Override public void componentMoved(ComponentEvent e){}
   @Override public void componentHidden(ComponentEvent e){}
   @Override public void componentShown(ComponentEvent e){}
   @Override public void componentResized(ComponentEvent e)
   {
      //System.out.println( e );
      /*
      System.out.printf("JFrame [w = %d, h = %d]: " +
                        "FrameBufferPanel [w = %d, h = %d].\n",
                        jf.getWidth(), jf.getHeight(),
                        fbp.getWidth(), fbp.getHeight());
      */
      // Get the new size of the FrameBufferPanel.
      final int w = fbp.getWidth();
      final int h = fbp.getHeight();

      // Create a new FrameBuffer that fits the FrameBufferPanel.
      final Color bg = fbp.getFrameBuffer().getBackgroundColorFB();
      final FrameBuffer fb = new FrameBuffer(w, h, bg);
      fbp.setFrameBuffer(fb);
      if (useRenderer1)
      {
         Pipeline.render(scene, fb);
      }
      else
      {
         Pipeline2.render(scene, fb);
      }
      fbp.repaint();
   }


   private void print_help_message()
   {
      System.out.println("Use the 'd' key to toggle debugging information on and off.");
      System.out.println("Use the 'Alt-d' key combination to print the Scene data structure.");
      System.out.println("Use the '1' and '2' keys to switch between the two renderers.");
      System.out.println("Use the 'c' key to change the random solid arm color.");
      System.out.println("Use the 'C' key to randomly change arm segment colors.");
      System.out.println("Use the 'r' key to randomly change arm segment end colors.");
      System.out.println("Use the 'R' key to randomly change arm hinge colors.");
      System.out.println("Use the s/S keys to rotate the arm at the shoulder.");
      System.out.println("Use the e/E keys to rotate the arm at the elbow.");
      System.out.println("Use the w/W keys to rotate the arm at the wrist.");
      System.out.println("Use the f/F keys to rotate the arm at the finger.");
      System.out.println("Use the '=' key to reset the robot arm.");
      System.out.println("Use the '+' key to save a \"screenshot\" of the framebuffer.");
      System.out.println("Use the 'h' key to redisplay this help message.");
   }

   /**
      Create an instance of this class which has
      the affect of creating the GUI application.
   */
   public static void main(String[] args)
   {
      // We need to call the program's constructor in the
      // Java GUI Event Dispatch Thread, otherwise we get a
      // race condition between the constructor (running in
      // the main() thread) and the very first ComponentEvent
      // (running in the EDT).
      javax.swing.SwingUtilities.invokeLater(
         () -> new RobotArm2()
      );
   }
}
