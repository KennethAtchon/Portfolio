
In the next two renderers we will learn a better way to implement
the examples in this folder.
