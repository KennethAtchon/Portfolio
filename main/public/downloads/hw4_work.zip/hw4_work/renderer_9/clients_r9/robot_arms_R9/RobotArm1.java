/*
 * Renderer 9. The MIT License.
 * Copyright (c) 2022 rlkraft@pnw.edu
 * See LICENSE for details.
*/

import renderer.scene.*;
import renderer.scene.primitives.*;
import renderer.scene.util.ModelShading;
import renderer.scene.util.DrawSceneGraph;
import renderer.pipeline.*;
import renderer.framebuffer.*;

import java.awt.Color;
import javax.swing.JFrame;
import java.awt.BorderLayout;
import java.awt.event.KeyListener;
import java.awt.event.KeyEvent;
import java.awt.event.ComponentListener;
import java.awt.event.ComponentEvent;

/**
   Draw an interactive robot arm with shoulder, elbow, wrist, and finger joints.
<p>
   The tree for this scene is shown below.
<p>
   Remember that every position node in the tree contains a matrix
   and a model.
<p>
<pre>{@code
            Scene
           /     \
          /       \
    Camera        List<Position>
                 /   \    \    \----------------------\
                /     \    \                           \
               /       \    \----------\                \
              /         \               \                \
       Position        Position         Position         Position
         / \            /   \            /   \            /    \
        /   \          /     \          /     \          /      \
  Matrix  Model     Matrix  Model    Matrix  Model    Matrix     Model
    R    shoulder    RTR    elbow    RTRTR   wrist    RTRTRTR    finger
</pre>
*/
public class RobotArm1 implements KeyListener, ComponentListener
{
   private double shoulderRotation = 0.0;
   private double    elbowRotation = 0.0;
   private double    wristRotation = 0.0;
   private double   fingerRotation = 0.0;

   private double shoulderLength = 0.4;
   private double    elbowLength = 0.3;
   private double    wristLength = 0.2;
   private double   fingerLength = 0.1;

   private final Scene scene;
   private final Position shoulder_p;
   private final Position elbow_p;
   private final Position wrist_p;
   private final Position finger_p;

   private boolean takeScreenshot = false;
   private int screenshotNumber = 0;

   private boolean useRenderer1 = true;

   private final JFrame jf;
   private final FrameBufferPanel fbp;

   /**
      This constructor instantiates the Scene object
      and initializes it with appropriate geometry.
      Then this constructor instantiates the GUI.
   */
   public RobotArm1()
   {
      scene = new Scene("Robot Arm 1",
                        Camera.projOrtho());

      final Model shoulder = new Model("shoulder_segment");
      shoulder.addVertex(new Vertex(0, 0, 0),
                         new Vertex(shoulderLength, 0, 0));
      shoulder.addPrimitive(new LineSegment(0, 1));
      ModelShading.setColor(shoulder, Color.blue);
      shoulder_p = new Position(shoulder,
                                "shoulder");
      scene.addPosition(shoulder_p);

      final Model elbow = new Model("elbow_segment");
      elbow.addVertex(new Vertex(0, 0, 0),
                      new Vertex(elbowLength, 0, 0));
      elbow.addPrimitive(new LineSegment(0, 1));
      ModelShading.setColor(elbow, Color.red);
      elbow_p = new Position(elbow,
                             "elbow",
                             Matrix.translate(shoulderLength, 0, 0));
      scene.addPosition(elbow_p);

      final Model wrist = new Model("wrist_segment");
      wrist.addVertex(new Vertex(0, 0, 0),
                      new Vertex(wristLength, 0, 0));
      wrist.addPrimitive(new LineSegment(0, 1));
      ModelShading.setColor(wrist, Color.green);
      wrist_p = new Position(wrist,
                             "wrist",
                             Matrix.translate(shoulderLength, 0, 0)
                      .times(Matrix.translate(elbowLength, 0, 0)));
      scene.addPosition(wrist_p);

      final Model finger = new Model("finger_segment");
      finger.addVertex(new Vertex(0, 0, 0),
                       new Vertex(fingerLength, 0, 0));
      finger.addPrimitive(new LineSegment(0, 1));
      ModelShading.setColor(finger, Color.magenta);
      finger_p = new Position(finger,
                              "finger",
                              Matrix.translate(shoulderLength, 0, 0)
                       .times(Matrix.translate(elbowLength, 0, 0))
                       .times(Matrix.translate(wristLength, 0, 0)));
      scene.addPosition(finger_p);

      DrawSceneGraph.draw(scene, "RobotArm_1");


      // Create a FrameBufferPanel that holds a FrameBuffer.
      final int width  = 1024;
      final int height = 1024;
      fbp = new FrameBufferPanel(width, height, Color.black);

      // Create a JFrame that will hold the FrameBufferPanel.
      jf = new JFrame("Renderer 9 - Robot Arm 1");
      jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      jf.getContentPane().add(fbp, BorderLayout.CENTER);
      jf.pack();
      jf.setLocationRelativeTo(null);
      jf.setVisible(true);

      // Create event handler objects for events from the JFrame.
      jf.addKeyListener(this);
      jf.addComponentListener(this);

      print_help_message();
   }


   // Implement the KeyListener interface.
   @Override public void keyPressed(KeyEvent e){}
   @Override public void keyReleased(KeyEvent e){}
   @Override public void keyTyped(KeyEvent e)
   {
      //System.out.println( e );

      final char c = e.getKeyChar();
      if ('h' == c)
      {
         print_help_message();
         return;
      }
      else if ('d' == c && e.isAltDown())
      {
         System.out.println();
         System.out.println( scene );
      }
      else if ('d' == c)
      {
         scene.debug = ! scene.debug;
         Clip.debug = scene.debug;
      }
      else if ('D' == c)
      {
         Rasterize.debug = ! Rasterize.debug;
      }
      else if ('1' == c)
      {
         if (! useRenderer1)
         {
            useRenderer1 = true;
         }
         System.out.println("Using Pipeline 1.");
      }
      else if ('2' == c)
      {
         if (useRenderer1)
         {
            useRenderer1 = false;
         }
         System.out.println("Using Pipeline 2.");
      }
      else if ('c' == c)
      {
         // Change the solid random color of the robot arm.
         final Color color = ModelShading.randomColor();
         ModelShading.setColor(shoulder_p.getModel(), color);
         ModelShading.setColor(elbow_p.getModel(), color);
         ModelShading.setColor(wrist_p.getModel(), color);
         ModelShading.setColor(finger_p.getModel(), color);
      }
      else if ('C' == c)
      {
         // Change the solid random color of each segment of the robot arm.
         ModelShading.setRandomColor(shoulder_p.getModel());
         ModelShading.setRandomColor(elbow_p.getModel());
         ModelShading.setRandomColor(wrist_p.getModel());
         ModelShading.setRandomColor(finger_p.getModel());
      }
      else if ('r' == c)
      {
         // Change the random color at each end of each segment of the robot arm.
         ModelShading.setRainbowPrimitiveColors(shoulder_p.getModel());
         ModelShading.setRainbowPrimitiveColors(elbow_p.getModel());
         ModelShading.setRainbowPrimitiveColors(wrist_p.getModel());
         ModelShading.setRainbowPrimitiveColors(finger_p.getModel());
      }
      else if ('R' == c)
      {
         // Change the random color at each vertex of the robot arm.
         final Color c1 = ModelShading.randomColor();
         final Color c2 = ModelShading.randomColor();
         final Color c3 = ModelShading.randomColor();
         final Color c4 = ModelShading.randomColor();
         final Color c5 = ModelShading.randomColor();
         shoulder_p.getModel().colorList.clear();
            elbow_p.getModel().colorList.clear();
            wrist_p.getModel().colorList.clear();
           finger_p.getModel().colorList.clear();
        shoulder_p.getModel().addColor(c1, c2);
           elbow_p.getModel().addColor(c2, c3);
           wrist_p.getModel().addColor(c3, c4);
          finger_p.getModel().addColor(c4, c5);
         shoulder_p.getModel().getPrimitive(0).setColorIndices(0, 1);
            elbow_p.getModel().getPrimitive(0).setColorIndices(0, 1);
            wrist_p.getModel().getPrimitive(0).setColorIndices(0, 1);
           finger_p.getModel().getPrimitive(0).setColorIndices(0, 1);
      }
      else if ('=' == c)
      {
         shoulderRotation = 0.0;
            elbowRotation = 0.0;
            wristRotation = 0.0;
           fingerRotation = 0.0;
      }
      else if ('s' == c)
      {
         shoulderRotation += 2.0;
      }
      else if ('S' == c)
      {
         shoulderRotation -= 2.0;
      }
      else if ('e' == c)
      {
         elbowRotation += 2.0;
      }
      else if ('E' == c)
      {
         elbowRotation -= 2.0;
      }
      else if ('w' == c)
      {
         wristRotation += 2.0;
      }
      else if ('W' == c)
      {
         wristRotation -= 2.0;
      }
      else if ('f' == c)
      {
         fingerRotation += 2.0;
      }
      else if ('F' == c)
      {
         fingerRotation -= 2.0;
      }
      else if ('+' == c)
      {
         takeScreenshot = true;
      }

      // Update the matrices.
      shoulder_p.transform( Matrix.rotateZ(shoulderRotation) );

      elbow_p.transform( Matrix.rotateZ(shoulderRotation)
                  .times(Matrix.translate(shoulderLength, 0, 0))
                  .times(Matrix.rotateZ(elbowRotation)) );

      wrist_p.transform( Matrix.rotateZ(shoulderRotation)
                  .times(Matrix.translate(shoulderLength, 0, 0))
                  .times(Matrix.rotateZ(elbowRotation))
                  .times(Matrix.translate(elbowLength, 0, 0))
                  .times(Matrix.rotateZ(wristRotation)) );

      finger_p.transform( Matrix.rotateZ(shoulderRotation)
                   .times(Matrix.translate(shoulderLength, 0, 0))
                   .times(Matrix.rotateZ(elbowRotation))
                   .times(Matrix.translate(elbowLength, 0, 0))
                   .times(Matrix.rotateZ(wristRotation))
                   .times(Matrix.translate(wristLength, 0, 0))
                   .times(Matrix.rotateZ(fingerRotation)) );

      // Render again.
      final FrameBuffer fb = this.fbp.getFrameBuffer();
      fb.clearFB();
      if (useRenderer1)
      {
         Pipeline.render(scene, fb);
      }
      else
      {
         Pipeline2.render(scene, fb);
      }
      if (takeScreenshot)
      {
         fb.dumpFB2File(String.format("Screenshot%03d.png", screenshotNumber), "png");
         ++screenshotNumber;
         takeScreenshot = false;
      }
      fbp.repaint();
   }


   // Implement the ComponentListener interface.
   @Override public void componentMoved(ComponentEvent e){}
   @Override public void componentHidden(ComponentEvent e){}
   @Override public void componentShown(ComponentEvent e){}
   @Override public void componentResized(ComponentEvent e)
   {
      //System.out.println( e );
      /*
      System.out.printf("JFrame [w = %d, h = %d]: " +
                        "FrameBufferPanel [w = %d, h = %d].\n",
                        jf.getWidth(), jf.getHeight(),
                        fbp.getWidth(), fbp.getHeight());
      */
      // Get the new size of the FrameBufferPanel.
      final int w = fbp.getWidth();
      final int h = fbp.getHeight();

      // Create a new FrameBuffer that fits the FrameBufferPanel.
      final Color bg = fbp.getFrameBuffer().getBackgroundColorFB();
      final FrameBuffer fb = new FrameBuffer(w, h, bg);
      fbp.setFrameBuffer(fb);
      if (useRenderer1)
      {
         Pipeline.render(scene, fb);
      }
      else
      {
         Pipeline2.render(scene, fb);
      }
      fbp.repaint();
   }


   private void print_help_message()
   {
      System.out.println("Use the 'd' key to toggle debugging information on and off.");
      System.out.println("Use the 'Alt-d' key combination to print the Scene data structure.");
      System.out.println("Use the '1' and '2' keys to switch between the two renderers.");
      System.out.println("Use the 'c' key to change the random solid arm color.");
      System.out.println("Use the 'C' key to randomly change arm segment colors.");
      System.out.println("Use the 'r' key to randomly change arm segment end colors.");
      System.out.println("Use the 'R' key to randomly change arm hinge colors.");
      System.out.println("Use the s/S keys to rotate the arm at the shoulder.");
      System.out.println("Use the e/E keys to rotate the arm at the elbow.");
      System.out.println("Use the w/W keys to rotate the arm at the wrist.");
      System.out.println("Use the f/F keys to rotate the arm at the finger.");
      System.out.println("Use the '=' key to reset the robot arm.");
      System.out.println("Use the '+' key to save a \"screenshot\" of the framebuffer.");
      System.out.println("Use the 'h' key to redisplay this help message.");
   }


   /**
      Create an instance of this class which has
      the affect of creating the GUI application.
   */
   public static void main(String[] args)
   {
      // We need to call the program's constructor in the
      // Java GUI Event Dispatch Thread, otherwise we get a
      // race condition between the constructor (running in
      // the main() thread) and the very first ComponentEvent
      // (running in the EDT).
      javax.swing.SwingUtilities.invokeLater(
         () -> new RobotArm1()
      );
   }
}
