/*
 * Renderer 9. The MIT License.
 * Copyright (c) 2022 rlkraft@pnw.edu
 * See LICENSE for details.
*/

import renderer.scene.*;
import renderer.scene.primitives.*;
import renderer.scene.util.ModelShading;
import renderer.scene.util.DrawSceneGraph;
import renderer.pipeline.*;
import renderer.framebuffer.*;

import java.util.ArrayList;
import java.awt.Color;
import javax.swing.JFrame;
import java.awt.BorderLayout;
import java.awt.event.KeyListener;
import java.awt.event.KeyEvent;
import java.awt.event.ComponentListener;
import java.awt.event.ComponentEvent;

/**
   Draw two interactive robot arms each with one shoulder,
   two elbow, two wrist, and two finger joints.
<pre>{@code
          Scene
         /     \
        /       \
  Camera    List<Position>
             /     \0       1        2               3            4            5              6
            /       \--------\--------\---------------\------------\------------\--------------\
           /         \        \        \               \            \            \              \
          /     Position   Position    Position        Position     Position     Position       Position
         /        /  |      /    |      /    |          /    |       /   |        /   |           /   |
        /        /   |     /     |     /     |         /     |      /    |       /    |          /    |
       /   Matrix    |  Matrix   |  Matrix   |    Matrix     |   Matrix  |    Matrix  |     Matrix    |
       \     RS      |  RSTRS    | RSTRSTRS  /  RSTRSTRSTRS /    RSTRS   |   RSTRSTRS |   RSTRSTRSTRS /
        \            \           |          /              /             /           /               /
         \            \          |         /              /             /           /               /
          \            \-------Model------/--------------/-------------/-----------/---------------/
           \                  armSegment1
            \
             \7       8        9               10           11           12             13
              \--------\--------\---------------\------------\------------\--------------\
               \        \        \               \            \            \              \
          Position   Position    Position        Position     Position     Position       Position
            /  |      /    |      /    |          /    |       /   |        /   |           /   |
           /   |     /     |     /     |         /     |      /    |       /    |          /    |
     Matrix    |  Matrix   |  Matrix   |    Matrix     |   Matrix  |    Matrix  |     Matrix    |
       RS      |  RSTRS    | RSTRSTRS  /  RSTRSTRSTRS /    RSTRS   |   RSTRSTRS |   RSTRSTRSTRS /
               \           |          /              /             /           /               /
                \          |         /              /             /           /               /
                 \-------Model------/--------------/-------------/-----------/---------------/
                        armSegment2
</pre>
*/
public class RobotArms3 implements KeyListener, ComponentListener
{
   private final double[] xTranslation = {0.0,  0.0};
   private final double[] yTranslation = {0.5, -0.5};

   private final double[] shoulderRotation = {0.0, 0.0};
   private final double[]   elbowRotation1 = { 15,  15};
   private final double[]   elbowRotation2 = {-15, -15};
   private final double[]   wristRotation1 = {0.0, 0.0};
   private final double[]   wristRotation2 = {0.0, 0.0};
   private final double[]  fingerRotation1 = {0.0, 0.0};
   private final double[]  fingerRotation2 = {0.0, 0.0};

   private final double[] shoulderLength = {0.4, 0.4};
   private final double[]   elbowLength1 = {0.3, 0.3};
   private final double[]   elbowLength2 = {0.3, 0.3};
   private final double[]   wristLength1 = {0.2, 0.2};
   private final double[]   wristLength2 = {0.2, 0.2};
   private final double[]  fingerLength1 = {0.1, 0.1};
   private final double[]  fingerLength2 = {0.1, 0.1};

   private final Scene scene;
   private final Position[] shoulder_p = new Position[2];
   private final Position[] elbow1_p   = new Position[2];
   private final Position[] elbow2_p   = new Position[2];
   private final Position[] wrist1_p   = new Position[2];
   private final Position[] wrist2_p   = new Position[2];
   private final Position[] finger1_p  = new Position[2];
   private final Position[] finger2_p  = new Position[2];
   private int currentArm = 0;

   private boolean takeScreenshot = false;
   private int screenshotNumber = 0;

   private boolean useRenderer1 = true;

   private final JFrame jf;
   private final FrameBufferPanel fbp;

   /**
      This constructor instantiates the Scene object
      and initializes it with appropriate geometry.
      Then this constructor instantiates the GUI.
   */
   public RobotArms3()
   {
      // Create a Model that can be used
      // for each segment of one robot arm.
      final Vertex v0 = new Vertex(0, 0, 0);
      final Vertex v1 = new Vertex(1, 0, 0);
      final Model armSegment1 = new Model("arm_segment_1");
      armSegment1.addVertex(v0, v1);
      armSegment1.addPrimitive(new LineSegment(0, 1));
      ModelShading.setColor(armSegment1, Color.blue);

      // Create a Model that can be used
      // for each segment of one robot arm.
      final Model armSegment2 = new Model("arm_segment_2");
      armSegment2.addVertex(v0, v1);
      armSegment2.addPrimitive(new LineSegment(0, 1));
      ModelShading.setColor(armSegment2, Color.red);

      scene = new Scene("Robot Arms 3",
                        Camera.projOrtho());

      /*
         Create two robot arms each with one shoulder,
         two elbow, two wrist, and two finger joints.
      */
      // First arm.
      shoulder_p[0] = new Position(armSegment1,
                                   "arm_1",
                                   Matrix.translate(xTranslation[0],
                                                   yTranslation[0],
                                                   0)
                            .times(Matrix.rotateZ(shoulderRotation[0]))
                            .times(Matrix.scale(shoulderLength[0],
                                                shoulderLength[0],
                                                1)) );
      scene.addPosition(shoulder_p[0]);

      // two elbows
      elbow1_p[0] = new Position(armSegment1,
                                 "elbow_1",
                                 Matrix.translate(xTranslation[0],
                                                 yTranslation[0],
                                                 0)
                          .times(Matrix.rotateZ(shoulderRotation[0]))
                          .times(Matrix.scale(shoulderLength[0],
                                              shoulderLength[0],
                                              1))
                          .times(Matrix.translate(1, 0, 0))
                          .times(Matrix.rotateZ(elbowRotation1[0]))
                          .times(Matrix.scale(elbowLength1[0]/shoulderLength[0],
                                              elbowLength1[0]/shoulderLength[0],
                                              1)) );
      scene.addPosition(elbow1_p[0]);

      elbow2_p[0] = new Position(armSegment1,
                                 "elbow_2",
                                 Matrix.translate(xTranslation[0],
                                                 yTranslation[0],
                                                 0)
                          .times(Matrix.rotateZ(shoulderRotation[0]))
                          .times(Matrix.scale(shoulderLength[0],
                                              shoulderLength[0],
                                              1))
                          .times(Matrix.translate(1, 0, 0))
                          .times(Matrix.rotateZ(elbowRotation2[0]))
                          .times(Matrix.scale(elbowLength2[0]/shoulderLength[0],
                                              elbowLength2[0]/shoulderLength[0],
                                              1)) );
      scene.addPosition(elbow2_p[0]);

      // two wrists
      wrist1_p[0] = new Position(armSegment1,
                                 "wrist_1",
                                 Matrix.translate(xTranslation[0],
                                                 yTranslation[0],
                                                 0)
                          .times(Matrix.rotateZ(shoulderRotation[0]))
                          .times(Matrix.scale(shoulderLength[0],
                                              shoulderLength[0],
                                              1))
                          .times(Matrix.translate(1, 0, 0))
                          .times(Matrix.rotateZ(elbowRotation1[0]))
                          .times(Matrix.scale(elbowLength1[0]/shoulderLength[0],
                                              elbowLength1[0]/shoulderLength[0],
                                              1))
                          .times(Matrix.translate(1, 0, 0))
                          .times(Matrix.scale(wristLength1[0]/elbowLength1[0],
                                              wristLength1[0]/elbowLength1[0],
                                              1)) );
      scene.addPosition(wrist1_p[0]);

      wrist2_p[0] = new Position(armSegment1,
                                 "wrist_2",
                                 Matrix.translate(xTranslation[0],
                                                 yTranslation[0],
                                                 0)
                          .times(Matrix.rotateZ(shoulderRotation[0]))
                          .times(Matrix.scale(shoulderLength[0],
                                              shoulderLength[0],
                                              1))
                          .times(Matrix.translate(1, 0, 0))
                          .times(Matrix.rotateZ(elbowRotation2[0]))
                          .times(Matrix.scale(elbowLength2[0]/shoulderLength[0],
                                              elbowLength2[0]/shoulderLength[0],
                                              1))
                          .times(Matrix.translate(1, 0, 0))
                          .times(Matrix.scale(wristLength2[0]/elbowLength2[0],
                                              wristLength2[0]/elbowLength2[0],
                                              1)) );
      scene.addPosition(wrist2_p[0]);

      // two fingers
      finger1_p[0] = new Position(armSegment1,
                                  "finger_1",
                                  Matrix.translate(xTranslation[0],
                                                  yTranslation[0],
                                                  0)
                           .times(Matrix.rotateZ(shoulderRotation[0]))
                           .times(Matrix.scale(shoulderLength[0],
                                               shoulderLength[0],
                                               1))
                           .times(Matrix.translate(1, 0, 0))
                           .times(Matrix.rotateZ(elbowRotation1[0]))
                           .times(Matrix.scale(elbowLength1[0]/shoulderLength[0],
                                               elbowLength1[0]/shoulderLength[0],
                                               1))
                           .times(Matrix.translate(1, 0, 0))
                           .times(Matrix.scale(wristLength1[0]/elbowLength1[0],
                                               wristLength1[0]/elbowLength1[0],
                                               1))
                           .times(Matrix.translate(1, 0, 0))
                           .times(Matrix.scale(fingerLength1[0]/wristLength1[0],
                                               fingerLength1[0]/wristLength1[0],
                                               1)) );
      scene.addPosition(finger1_p[0]);

      finger2_p[0] = new Position(armSegment1,
                                  "finger_2",
                                  Matrix.translate(xTranslation[0],
                                                  yTranslation[0],
                                                  0)
                           .times(Matrix.rotateZ(shoulderRotation[0]))
                           .times(Matrix.scale(shoulderLength[0],
                                               shoulderLength[0],
                                               1))
                           .times(Matrix.translate(1, 0, 0))
                           .times(Matrix.rotateZ(elbowRotation2[0]))
                           .times(Matrix.scale(elbowLength2[0]/shoulderLength[0],
                                               elbowLength2[0]/shoulderLength[0],
                                               1))
                           .times(Matrix.translate(1, 0, 0))
                           .times(Matrix.scale(wristLength2[0]/elbowLength2[0],
                                               wristLength2[0]/elbowLength2[0],
                                               1))
                           .times(Matrix.translate(1, 0, 0))
                           .times(Matrix.scale(fingerLength2[0]/wristLength2[0],
                                               fingerLength2[0]/wristLength2[0],
                                               1)) );
      scene.addPosition(finger2_p[0]);

      // Second arm.
      shoulder_p[1] = new Position(armSegment2,
                                   "arm_2",
                                   Matrix.translate(xTranslation[1],
                                                    yTranslation[1],
                                                    0)
                            .times(Matrix.rotateZ(shoulderRotation[1]))
                            .times(Matrix.scale(shoulderLength[1],
                                                shoulderLength[1],
                                                1)) );
      scene.addPosition(shoulder_p[1]);

      // two elbows
      elbow1_p[1] = new Position(armSegment2,
                                 "elbow_1",
                                 Matrix.translate(xTranslation[1],
                                                  yTranslation[1],
                                                  0)
                          .times(Matrix.rotateZ(shoulderRotation[1]))
                          .times(Matrix.scale(shoulderLength[1],
                                              shoulderLength[1],
                                              1))
                          .times(Matrix.translate(1, 0, 0))
                          .times(Matrix.rotateZ(elbowRotation1[1]))
                          .times(Matrix.scale(elbowLength1[1]/shoulderLength[1],
                                              elbowLength1[1]/shoulderLength[1],
                                              1)) );
      scene.addPosition(elbow1_p[1]);

      elbow2_p[1] = new Position(armSegment2,
                                 "elbow_2",
                                 Matrix.translate(xTranslation[1],
                                                  yTranslation[1],
                                                  0)
                          .times(Matrix.rotateZ(shoulderRotation[1]))
                          .times(Matrix.scale(shoulderLength[1],
                                              shoulderLength[1],
                                              1))
                          .times(Matrix.translate(1, 0, 0))
                          .times(Matrix.rotateZ(elbowRotation2[1]))
                          .times(Matrix.scale(elbowLength2[1]/shoulderLength[1],
                                              elbowLength2[1]/shoulderLength[1],
                                              1)) );
      scene.addPosition(elbow2_p[1]);

      // two wrists
      wrist1_p[1] = new Position(armSegment2,
                                 "wrist_1",
                                 Matrix.translate(xTranslation[1],
                                                    yTranslation[1],
                                                    0)
                          .times(Matrix.rotateZ(shoulderRotation[1]))
                          .times(Matrix.scale(shoulderLength[1],
                                              shoulderLength[1],
                                              1))
                          .times(Matrix.translate(1, 0, 0))
                          .times(Matrix.rotateZ(elbowRotation1[1]))
                          .times(Matrix.scale(elbowLength1[1]/shoulderLength[1],
                                              elbowLength1[1]/shoulderLength[1],
                                              1))
                          .times(Matrix.translate(1, 0, 0))
                          .times(Matrix.scale(wristLength1[1]/elbowLength1[1],
                                              wristLength1[1]/elbowLength1[1],
                                              1)) );
      scene.addPosition(wrist1_p[1]);

      wrist2_p[1] = new Position(armSegment2,
                                 "wrist_2",
                                 Matrix.translate(xTranslation[1],
                                                  yTranslation[1],
                                                  0)
                          .times(Matrix.rotateZ(shoulderRotation[1]))
                          .times(Matrix.scale(shoulderLength[1],
                                              shoulderLength[1],
                                              1))
                          .times(Matrix.translate(1, 0, 0))
                          .times(Matrix.rotateZ(elbowRotation2[1]))
                          .times(Matrix.scale(elbowLength2[1]/shoulderLength[1],
                                              elbowLength2[1]/shoulderLength[1],
                                              1))
                          .times(Matrix.translate(1, 0, 0))
                          .times(Matrix.scale(wristLength2[1]/elbowLength2[1],
                                              wristLength2[1]/elbowLength2[1],
                                              1)) );
      scene.addPosition(wrist2_p[1]);

      // two fingers
      finger1_p[1] = new Position(armSegment2,
                                  "finger_1",
                                  Matrix.translate(xTranslation[1],
                                                   yTranslation[1],
                                                   0)
                           .times(Matrix.rotateZ(shoulderRotation[1]))
                           .times(Matrix.scale(shoulderLength[1],
                                               shoulderLength[1],
                                               1))
                           .times(Matrix.translate(1, 0, 0))
                           .times(Matrix.rotateZ(elbowRotation1[1]))
                           .times(Matrix.scale(elbowLength1[1]/shoulderLength[1],
                                               elbowLength1[1]/shoulderLength[1],
                                               1))
                           .times(Matrix.translate(1, 0, 0))
                           .times(Matrix.scale(wristLength1[1]/elbowLength1[1],
                                               wristLength1[1]/elbowLength1[1],
                                               1))
                           .times(Matrix.translate(1, 0, 0))
                           .times(Matrix.scale(fingerLength1[1]/wristLength1[1],
                                               fingerLength1[1]/wristLength1[1],
                                               1)) );
      scene.addPosition(finger1_p[1]);

      finger2_p[1] = new Position(armSegment2,
                                  "finger_2",
                                  Matrix.translate(xTranslation[1],
                                                   yTranslation[1],
                                                   0)
                           .times(Matrix.rotateZ(shoulderRotation[1]))
                           .times(Matrix.scale(shoulderLength[1],
                                               shoulderLength[1],
                                               1))
                           .times(Matrix.translate(1, 0, 0))
                           .times(Matrix.rotateZ(elbowRotation2[1]))
                           .times(Matrix.scale(elbowLength2[1]/shoulderLength[1],
                                               elbowLength2[1]/shoulderLength[1],
                                               1))
                           .times(Matrix.translate(1, 0, 0))
                           .times(Matrix.scale(wristLength2[1]/elbowLength2[1],
                                               wristLength2[1]/elbowLength2[1],
                                               1))
                           .times(Matrix.translate(1, 0, 0))
                           .times(Matrix.scale(fingerLength2[1]/wristLength2[1],
                                               fingerLength2[1]/wristLength2[1],
                                               1)) );
      scene.addPosition(finger2_p[1]);

      DrawSceneGraph.draw(scene, "RobotArms_3");


      // Create a FrameBufferPanel that holds a FrameBuffer.
      final int width  = 1024;
      final int height = 1024;
      fbp = new FrameBufferPanel(width, height, Color.black);

      // Create a JFrame that will hold the FrameBufferPanel.
      jf = new JFrame("Renderer 9 - Robot Arms 3");
      jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      jf.getContentPane().add(fbp, BorderLayout.CENTER);
      jf.pack();
      jf.setLocationRelativeTo(null);
      jf.setVisible(true);

      // Create event handler objects for events from the JFrame.
      jf.addKeyListener(this);
      jf.addComponentListener(this);

      print_help_message();
   }


   // Implement the KeyListener interface.
   @Override public void keyPressed(KeyEvent e)
   {
      //System.out.println( e );

      if (e.isControlDown())
      {
         if (e.isShiftDown())
         {
            if (e.getKeyCode() == KeyEvent.VK_S) // ^S (83)
            {
               shoulderLength[currentArm] -= 0.02;
            }
            else if (e.getKeyCode() == KeyEvent.VK_E) // ^E (69)
            {
               elbowLength1[currentArm] -= 0.02;
            }
            else if (e.getKeyCode() == KeyEvent.VK_W) // ^W (87)
            {
               wristLength1[currentArm] -= 0.02;
            }
            else if (e.getKeyCode() == KeyEvent.VK_F) // ^F (70)
            {
               fingerLength1[currentArm] -= 0.02;
            }
            else if (e.getKeyCode() == KeyEvent.VK_Q) // ^Q
            {
               elbowLength2[currentArm] -= 0.02;
            }
            else if (e.getKeyCode() == KeyEvent.VK_Z) // ^Z
            {
               wristLength2[currentArm] -= 0.02;
            }
            else if (e.getKeyCode() == KeyEvent.VK_A) // ^A
            {
               fingerLength2[currentArm] -= 0.02;
            }
         }
         else // no shift key
         {
            if (e.getKeyCode() == KeyEvent.VK_S) // ^s (93)
            {
               shoulderLength[currentArm] += 0.02;
            }
            else if (e.getKeyCode() == KeyEvent.VK_E) // ^e (69)
            {
               elbowLength1[currentArm] += 0.02;
            }
            else if (e.getKeyCode() == KeyEvent.VK_W)  // ^w (87)
            {
               wristLength1[currentArm] += 0.02;
            }
            else if (e.getKeyCode() == KeyEvent.VK_F) // ^f (70)
            {
               fingerLength1[currentArm] += 0.02;
            }
            else if (e.getKeyCode() == KeyEvent.VK_Q) // ^q
            {
               elbowLength2[currentArm] += 0.02;
            }
            else if (e.getKeyCode() == KeyEvent.VK_Z)  // ^z
            {
               wristLength2[currentArm] += 0.02;
            }
            else if (e.getKeyCode() == KeyEvent.VK_A) // ^a
            {
               fingerLength2[currentArm] += 0.02;
            }
         }
      }
   }

   @Override public void keyReleased(KeyEvent e){}

   @Override public void keyTyped(KeyEvent e)
   {
      //System.out.println( e );

      final char c = e.getKeyChar();
      if ('h' == c)
      {
         print_help_message();
         return;
      }
      else if ('d' == c && e.isAltDown())
      {
         System.out.println();
         System.out.println( scene );
      }
      else if ('d' == c)
      {
         scene.debug = ! scene.debug;
         Clip.debug = scene.debug;
      }
      else if ('D' == c)
      {
         Rasterize.debug = ! Rasterize.debug;
      }
      else if ('1' == c)
      {
         if (! useRenderer1)
         {
            useRenderer1 = true;
         }
         System.out.println("Using Pipeline 1.");
      }
      else if ('2' == c)
      {
         if (useRenderer1)
         {
            useRenderer1 = false;
         }
         System.out.println("Using Pipeline 2.");
      }
      else if ('/' == c)
      {
         currentArm = (currentArm + 1) % 2;
      }
      else if ('c' == c)
      {
         // Change the solid random color of the robot arm.
         final Color color = ModelShading.randomColor();
         ModelShading.setColor(shoulder_p[currentArm].getModel(), color);
         ModelShading.setColor(  elbow1_p[currentArm].getModel(), color);
         ModelShading.setColor(  elbow2_p[currentArm].getModel(), color);
         ModelShading.setColor(  wrist1_p[currentArm].getModel(), color);
         ModelShading.setColor(  wrist2_p[currentArm].getModel(), color);
         ModelShading.setColor( finger1_p[currentArm].getModel(), color);
         ModelShading.setColor( finger2_p[currentArm].getModel(), color);
      }
      else if ('C' == c)
      {
         // Change the solid random color of each segment of the robot arm.
         ModelShading.setRandomColor(shoulder_p[currentArm].getModel());
         ModelShading.setRandomColor(  elbow1_p[currentArm].getModel());
         ModelShading.setRandomColor(  elbow2_p[currentArm].getModel());
         ModelShading.setRandomColor(  wrist1_p[currentArm].getModel());
         ModelShading.setRandomColor(  wrist2_p[currentArm].getModel());
         ModelShading.setRandomColor( finger1_p[currentArm].getModel());
         ModelShading.setRandomColor( finger2_p[currentArm].getModel());
      }
      else if ('r' == c)
      {
         // Change the random color at each end of each segment of the robot arm.
         ModelShading.setRainbowPrimitiveColors(shoulder_p[currentArm].getModel());
         ModelShading.setRainbowPrimitiveColors(  elbow1_p[currentArm].getModel());
         ModelShading.setRainbowPrimitiveColors(  elbow2_p[currentArm].getModel());
         ModelShading.setRainbowPrimitiveColors(  wrist1_p[currentArm].getModel());
         ModelShading.setRainbowPrimitiveColors(  wrist2_p[currentArm].getModel());
         ModelShading.setRainbowPrimitiveColors( finger1_p[currentArm].getModel());
         ModelShading.setRainbowPrimitiveColors( finger2_p[currentArm].getModel());
      }
      else if ('R' == c)
      {
         // Change the random color at each vertex of the robot arm.
         final Color c1 = ModelShading.randomColor();
         final Color c2 = ModelShading.randomColor();
         final Color c3 = ModelShading.randomColor();
         final Color c4 = ModelShading.randomColor();
         final Color c5 = ModelShading.randomColor();
         final Color c6 = ModelShading.randomColor();
         final Color c7 = ModelShading.randomColor();
         final Color c8 = ModelShading.randomColor();
         shoulder_p[currentArm].getModel().colorList.clear();
           elbow1_p[currentArm].getModel().colorList.clear();
           elbow2_p[currentArm].getModel().colorList.clear();
           wrist1_p[currentArm].getModel().colorList.clear();
           wrist2_p[currentArm].getModel().colorList.clear();
          finger1_p[currentArm].getModel().colorList.clear();
          finger2_p[currentArm].getModel().colorList.clear();
         shoulder_p[currentArm].getModel().addColor(c1, c2);
           elbow1_p[currentArm].getModel().addColor(c2, c3);
           elbow2_p[currentArm].getModel().addColor(c2, c4);
           wrist1_p[currentArm].getModel().addColor(c3, c5);
           wrist2_p[currentArm].getModel().addColor(c4, c6);
          finger1_p[currentArm].getModel().addColor(c5, c7);
          finger2_p[currentArm].getModel().addColor(c6, c8);
         shoulder_p[currentArm].getModel().getPrimitive(0).setColorIndices(0, 1);
           elbow1_p[currentArm].getModel().getPrimitive(0).setColorIndices(0, 1);
           elbow2_p[currentArm].getModel().getPrimitive(0).setColorIndices(0, 1);
           wrist1_p[currentArm].getModel().getPrimitive(0).setColorIndices(0, 1);
           wrist2_p[currentArm].getModel().getPrimitive(0).setColorIndices(0, 1);
          finger1_p[currentArm].getModel().getPrimitive(0).setColorIndices(0, 1);
          finger2_p[currentArm].getModel().getPrimitive(0).setColorIndices(0, 1);
      }
      else if ('=' == c)
      {
         xTranslation[currentArm] = 0.0;
         if (0 == currentArm)
            yTranslation[0] =  0.5;
         else
            yTranslation[1] = -0.5;

        shoulderRotation[currentArm] = 0.0;
           elbowRotation1[currentArm] =  15.0;
           elbowRotation2[currentArm] = -15.0;
           wristRotation1[currentArm] = 0.0;
           wristRotation2[currentArm] = 0.0;
          fingerRotation1[currentArm] = 0.0;
          fingerRotation2[currentArm] = 0.0;

           shoulderLength[currentArm] = 0.4;
             elbowLength1[currentArm] = 0.3;
             elbowLength2[currentArm] = 0.3;
             wristLength1[currentArm] = 0.2;
             wristLength2[currentArm] = 0.2;
            fingerLength1[currentArm] = 0.1;
            fingerLength2[currentArm] = 0.1;
      }
      else if ('x' == c)
      {
         xTranslation[currentArm] += 0.02;
      }
      else if ('X' == c)
      {
         xTranslation[currentArm] -= 0.02;
      }
      else if ('y' == c)
      {
         yTranslation[currentArm] += 0.02;
      }
      else if ('Y' == c)
      {
         yTranslation[currentArm] -= 0.02;
      }
      else if ('s' == c)
      {
         shoulderRotation[currentArm] += 2.0;
      }
      else if ('S' == c)
      {
         shoulderRotation[currentArm] -= 2.0;
      }
      else if ('e' == c)
      {
         elbowRotation1[currentArm] += 2.0;
      }
      else if ('E' == c)
      {
         elbowRotation1[currentArm] -= 2.0;
      }
      else if ('w' == c)
      {
         wristRotation1[currentArm] += 2.0;
      }
      else if ('W' == c)
      {
         wristRotation1[currentArm] -= 2.0;
      }
      else if ('f' == c)
      {
         fingerRotation1[currentArm] += 2.0;
      }
      else if ('F' == c)
      {
         fingerRotation1[currentArm] -= 2.0;
      }
      else if ('q' == c)
      {
         elbowRotation2[currentArm] += 2.0;
      }
      else if ('Q' == c)
      {
         elbowRotation2[currentArm] -= 2.0;
      }
      else if ('z' == c)
      {
         wristRotation2[currentArm] += 2.0;
      }
      else if ('Z' == c)
      {
         wristRotation2[currentArm] -= 2.0;
      }
      else if ('a' == c)
      {
         fingerRotation2[currentArm] += 2.0;
      }
      else if ('A' == c)
      {
         fingerRotation2[currentArm] -= 2.0;
      }
      else if ('+' == c)
      {
         takeScreenshot = true;
      }

      // Update the nested matrices for the sub models.
      shoulder_p[currentArm].transform(
                             Matrix.translate(xTranslation[currentArm],
                                              yTranslation[currentArm],
                                              0)
                      .times(Matrix.rotateZ(shoulderRotation[currentArm]))
                      .times(Matrix.scale(shoulderLength[currentArm],
                                          shoulderLength[currentArm],
                                          1)) );

      elbow1_p[currentArm].transform(
                             Matrix.translate(xTranslation[currentArm],
                                              yTranslation[currentArm],
                                              0)
                      .times(Matrix.rotateZ(shoulderRotation[currentArm]))
                      .times(Matrix.scale(shoulderLength[currentArm],
                                          shoulderLength[currentArm],
                                          1))
                      .times(Matrix.translate(1, 0, 0))
                      .times(Matrix.rotateZ(elbowRotation1[currentArm]))
                      .times(Matrix.scale(elbowLength1[currentArm]/shoulderLength[currentArm],
                                          elbowLength1[currentArm]/shoulderLength[currentArm],
                                          1)) );

      elbow2_p[currentArm].transform(
                             Matrix.translate(xTranslation[currentArm],
                                              yTranslation[currentArm],
                                              0)
                      .times(Matrix.rotateZ(shoulderRotation[currentArm]))
                      .times(Matrix.scale(shoulderLength[currentArm],
                                          shoulderLength[currentArm],
                                          1))
                      .times(Matrix.translate(1, 0, 0))
                      .times(Matrix.rotateZ(elbowRotation2[currentArm]))
                      .times(Matrix.scale(elbowLength2[currentArm]/shoulderLength[currentArm],
                                          elbowLength2[currentArm]/shoulderLength[currentArm],
                                          1)) );

      wrist1_p[currentArm].transform(
                             Matrix.translate(xTranslation[currentArm],
                                              yTranslation[currentArm],
                                              0)
                      .times(Matrix.rotateZ(shoulderRotation[currentArm]))
                      .times(Matrix.scale(shoulderLength[currentArm],
                                          shoulderLength[currentArm],
                                          1))
                      .times(Matrix.translate(1, 0, 0))
                      .times(Matrix.rotateZ(elbowRotation1[currentArm]))
                      .times(Matrix.scale(elbowLength1[currentArm]/shoulderLength[currentArm],
                                          elbowLength1[currentArm]/shoulderLength[currentArm],
                                          1))
                      .times(Matrix.translate(1, 0, 0))
                      .times(Matrix.rotateZ(wristRotation1[currentArm]))
                      .times(Matrix.scale(wristLength1[currentArm]/elbowLength1[currentArm],
                                          wristLength1[currentArm]/elbowLength1[currentArm],
                                          1)) );

      wrist2_p[currentArm].transform(
                             Matrix.translate(xTranslation[currentArm],
                                              yTranslation[currentArm],
                                              0)
                      .times(Matrix.rotateZ(shoulderRotation[currentArm]))
                      .times(Matrix.scale(shoulderLength[currentArm],
                                          shoulderLength[currentArm],
                                          1))
                      .times(Matrix.translate(1, 0, 0))
                      .times(Matrix.rotateZ(elbowRotation2[currentArm]))
                      .times(Matrix.scale(elbowLength2[currentArm]/shoulderLength[currentArm],
                                          elbowLength2[currentArm]/shoulderLength[currentArm],
                                          1))
                      .times(Matrix.translate(1, 0, 0))
                      .times(Matrix.rotateZ(wristRotation2[currentArm]))
                      .times(Matrix.scale(wristLength2[currentArm]/elbowLength2[currentArm],
                                          wristLength2[currentArm]/elbowLength2[currentArm],
                                          1)) );

      finger1_p[currentArm].transform(
                             Matrix.translate(xTranslation[currentArm],
                                              yTranslation[currentArm],
                                              0)
                      .times(Matrix.rotateZ(shoulderRotation[currentArm]))
                      .times(Matrix.scale(shoulderLength[currentArm],
                                          shoulderLength[currentArm],
                                          1))
                      .times(Matrix.translate(1, 0, 0))
                      .times(Matrix.rotateZ(elbowRotation1[currentArm]))
                      .times(Matrix.scale(elbowLength1[currentArm]/shoulderLength[currentArm],
                                          elbowLength1[currentArm]/shoulderLength[currentArm],
                                          1))
                      .times(Matrix.translate(1, 0, 0))
                      .times(Matrix.rotateZ(wristRotation1[currentArm]))
                      .times(Matrix.scale(wristLength1[currentArm]/elbowLength1[currentArm],
                                          wristLength1[currentArm]/elbowLength1[currentArm],
                                          1))
                      .times(Matrix.translate(1, 0, 0))
                      .times(Matrix.rotateZ(fingerRotation1[currentArm]))
                      .times(Matrix.scale(fingerLength1[currentArm]/wristLength1[currentArm],
                                          fingerLength1[currentArm]/wristLength1[currentArm],
                                          1)) );

      finger2_p[currentArm].transform(
                             Matrix.translate(xTranslation[currentArm],
                                              yTranslation[currentArm],
                                              0)
                      .times(Matrix.rotateZ(shoulderRotation[currentArm]))
                      .times(Matrix.scale(shoulderLength[currentArm],
                                          shoulderLength[currentArm],
                                          1))
                      .times(Matrix.translate(1, 0, 0))
                      .times(Matrix.rotateZ(elbowRotation2[currentArm]))
                      .times(Matrix.scale(elbowLength2[currentArm]/shoulderLength[currentArm],
                                          elbowLength2[currentArm]/shoulderLength[currentArm],
                                          1))
                      .times(Matrix.translate(1, 0, 0))
                      .times(Matrix.rotateZ(wristRotation2[currentArm]))
                      .times(Matrix.scale(wristLength2[currentArm]/elbowLength2[currentArm],
                                          wristLength2[currentArm]/elbowLength2[currentArm],
                                          1))
                      .times(Matrix.translate(1, 0, 0))
                      .times(Matrix.rotateZ(fingerRotation2[currentArm]))
                      .times(Matrix.scale(fingerLength2[currentArm]/wristLength2[currentArm],
                                          fingerLength2[currentArm]/wristLength2[currentArm],
                                          1)) );

      // Render again.
      final FrameBuffer fb = this.fbp.getFrameBuffer();
      fb.clearFB();
      if (useRenderer1)
      {
         Pipeline.render(scene, fb);
      }
      else
      {
         Pipeline2.render(scene, fb);
      }
      if (takeScreenshot)
      {
         fb.dumpFB2File(String.format("Screenshot%03d.png", screenshotNumber), "png");
         ++screenshotNumber;
         takeScreenshot = false;
      }
      fbp.repaint();
   }


   // Implement the ComponentListener interface.
   @Override public void componentMoved(ComponentEvent e){}
   @Override public void componentHidden(ComponentEvent e){}
   @Override public void componentShown(ComponentEvent e){}
   @Override public void componentResized(ComponentEvent e)
   {
      //System.out.println( e );
      /*
      System.out.printf("JFrame [w = %d, h = %d]: " +
                        "FrameBufferPanel [w = %d, h = %d].\n",
                        jf.getWidth(), jf.getHeight(),
                        fbp.getWidth(), fbp.getHeight());
      */
      // Get the new size of the FrameBufferPanel.
      final int w = fbp.getWidth();
      final int h = fbp.getHeight();

      // Create a new FrameBuffer that fits the FrameBufferPanel.
      final Color bg = fbp.getFrameBuffer().getBackgroundColorFB();
      final FrameBuffer fb = new FrameBuffer(w, h, bg);
      fbp.setFrameBuffer(fb);
      if (useRenderer1)
      {
         Pipeline.render(scene, fb);
      }
      else
      {
         Pipeline2.render(scene, fb);
      }
      fbp.repaint();
   }


   private void print_help_message()
   {
      System.out.println("Use the 'd' key to toggle debugging information on and off.");
      System.out.println("Use the '1' and '2' keys to switch between the two renderers.");
      System.out.println("Use the '/' key to toggle between the two robot arms.");
      System.out.println();
      System.out.println("Use the 'c' key to change the random solid arm color.");
      System.out.println("Use the 'C' key to randomly change arm segment colors.");
      System.out.println("Use the 'r' key to randomly change arm segment end colors.");
      System.out.println("Use the 'R' key to randomly change arm hinge colors.");
      System.out.println();
      System.out.println("Use the s/S keys to rotate the current arm at the shoulder.");
      System.out.println();
      System.out.println("Use the e/E keys to rotate the current arm at elbow 1.");
      System.out.println("Use the w/W keys to rotate the current arm at wrist 1.");
      System.out.println("Use the f/F keys to rotate the current arm at finger 1.");
      System.out.println();
      System.out.println("Use the q/Q keys to rotate the current arm at elbow 2.");
      System.out.println("Use the z/Z keys to rotate the current arm at wrist 2.");
      System.out.println("Use the a/A keys to rotate the current arm at finger 2.");
      System.out.println();
      System.out.println("Use the ^s/^S keys to extend the length of the current arm at the shoulder.");
      System.out.println();
      System.out.println("Use the ^e/^E keys to extend the length of the current arm at elbow 1.");
      System.out.println("Use the ^w/^W keys to extend the length of the current arm at wrist 1.");
      System.out.println("Use the ^f/^F keys to extend the length of the current arm at finger 1.");
      System.out.println();
      System.out.println("Use the ^q/^Q keys to extend the length of the current arm at elbow 2.");
      System.out.println("Use the ^z/^Z keys to extend the length of the current arm at wrist 2.");
      System.out.println("Use the ^a/^A keys to extend the length of the current arm at finger 2.");
      System.out.println();
      System.out.println("Use the x/X keys to translate the current arm along the x-axis.");
      System.out.println("Use the y/Y keys to translate the current arm along the y-axis.");
      System.out.println();
      System.out.println("Use the '=' key to reset the current robot arm.");
      System.out.println("Use the '+' key to save a \"screenshot\" of the framebuffer.");
      System.out.println("Use the 'h' key to redisplay this help message.");
   }


   /**
      Create an instance of this class which has
      the affect of creating the GUI application.
   */
   public static void main(String[] args)
   {
      // We need to call the program's constructor in the
      // Java GUI Event Dispatch Thread, otherwise we get a
      // race condition between the constructor (running in
      // the main() thread) and the very first ComponentEvent
      // (running in the EDT).
      javax.swing.SwingUtilities.invokeLater(
         () -> new RobotArms3()
      );
   }
}