/*
 * Renderer 9. The MIT License.
 * Copyright (c) 2022 rlkraft@pnw.edu
 * See LICENSE for details.
*/

import renderer.scene.*;
import renderer.scene.util.ModelShading;
import renderer.models_L.*;
import renderer.framebuffer.FrameBuffer;

import java.awt.Color;

/**

*/
public class TestPipelineLogging
{
   public static void main(String[] args)
   {
      final Scene scene = new Scene("TestPipelineLogging");

      scene.addPosition(new Position(new Octahedron(),
                                     Matrix.translate(0, 0, -2)));

      scene.addPosition(new Position(new Tetrahedron(),
                                     Matrix.translate(0, 0, -2)));

      for (final Position p : scene.positionList)
      {
         ModelShading.setRandomColor( p.getModel() );
      }

      final int width  = 1024;
      final int height = 1024;
      final FrameBuffer fb = new FrameBuffer(width, height);

      scene.debug = true;

      renderer.pipeline.Clip.debug = true;

      System.err.println("\n\n ############ log divider ############\n\n");

      fb.clearFB(Color.darkGray);
      renderer.pipeline.Pipeline.render(scene, fb);
      fb.dumpFB2File("TestPipelineLogging_1.ppm");

      System.err.println("\n\n ############ log divider ############\n\n");

      fb.clearFB(Color.darkGray.darker());
      renderer.pipeline.Pipeline2.render(scene, fb);
      fb.dumpFB2File("TestPipelineLogging_2.ppm");
   }
}
