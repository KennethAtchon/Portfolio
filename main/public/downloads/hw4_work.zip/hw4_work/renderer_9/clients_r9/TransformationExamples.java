/*
 * Renderer 9. The MIT License.
 * Copyright (c) 2022 rlkraft@pnw.edu
 * See LICENSE for details.
*/

import renderer.scene.*;
import renderer.scene.util.Assets;
import renderer.scene.util.ModelShading;
import renderer.models_L.*;
import renderer.pipeline.*;
import renderer.framebuffer.*;

import java.io.File;
import java.awt.Color;

/**
   Use this program to experiment with two-dimensional transformations.
<p>
   Try mixing the ordering of rotations, translations, and scales.
*/
public class TransformationExamples
{
   private static final String assets = Assets.getPath();

   public static void main(String[] args)
   {
      // Use orthographic projection.
      final Scene scene = new Scene("TransformationExamples",
                                    Camera.projOrtho());

      // Create a 2D Model object.
      final Model m = new GRSModel(new File(assets + "grs/bronto_v2.grs"));
      ModelShading.setColor(m, Color.black);
      final Position position = new Position(m);
      scene.positionList.add(position);

      // Create a set of x and y axes.
      final Model axes = new Axes2D(-1, +1, -1, +1, 24, 24);
      ModelShading.setColor(axes, Color.red);
      scene.positionList.add(new Position(axes));

      // Draw a circle.
      final Model circle = new Circle(0.5, 60);
      ModelShading.setColor(circle, Color.blue);
      scene.positionList.add(new Position(circle));

      // Create a framebuffer to render our scene into.
      final int width  = 800;
      final int height = 800;
      final FrameBuffer fb = new FrameBuffer(width, height, Color.gray);

      for (int i = 0; i <= 36; ++i)
      {
         // try changing the order of these transformations
         final Matrix m1 = Matrix.scale(0.5) // scale the model to fit in the view rectangle
                   .times( Matrix.rotateZ(10*i) )
                   .times( Matrix.translate(1, 0, 0) );

         scene.getPosition(0).transform(m1);

         // Render again.
         fb.clearFB();
         Pipeline.render(scene, fb);
         fb.dumpFB2File(String.format("PPM_TransformationExamples_a_Frame%02d.ppm", i));
      }

      for (int i = 0; i <= 36; ++i)
      {
         // try changing the order of these transformations
         final Matrix m2 = Matrix.scale(0.5) // scale the model to fit in the view rectangle
                   .times( Matrix.translate(1, 0, 0) )
                   .times( Matrix.rotateZ(10*i) );

         scene.getPosition(0).transform(m2);

         // Render again.
         fb.clearFB();
         Pipeline.render(scene, fb);
         fb.dumpFB2File(String.format("PPM_TransformationExamples_b_Frame%02d.ppm", i));
      }

      for (int i = 0; i <= 36; ++i)
      {
         // try changing the order of these transformations
         final Matrix m3 = Matrix.scale(0.5) // scale the model to fit in the view rectangle
                   .times( Matrix.translate(Math.cos(i*Math.PI/18), 0, 0) )
                   .times( Matrix.translate(0, Math.sin(i*Math.PI/18), 0) );

         scene.getPosition(0).transform(m3);

         // Render again.
         fb.clearFB();
         Pipeline.render(scene, fb);
         fb.dumpFB2File(String.format("PPM_TransformationExamples_c_Frame%02d.ppm", i));
      }
   }
}
