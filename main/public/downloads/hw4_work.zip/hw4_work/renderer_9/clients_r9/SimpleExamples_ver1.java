/*
 * Renderer 9. The MIT License.
 * Copyright (c) 2022 rlkraft@pnw.edu
 * See LICENSE for details.
*/

import renderer.scene.*;
import renderer.scene.primitives.LineSegment;
import renderer.scene.util.ModelShading;
import renderer.models_L.Axes2D;
import renderer.pipeline.*;
import renderer.framebuffer.*;

import java.awt.Color;

/**
   Show that a scaling and a translation in the
   x-direction do not commute, that is,
      S_x * T_x != T_x * S_x.

   Show that a rotation and a translation in the
   x-direction do not commute, that is,
      R_z * T_x != T_x * R_z.
*/
public class SimpleExamples_ver1
{
   public static void main(String[] args)
   {
      // Use orthographic projection.
      final Scene scene = new Scene("SimpleExamples_ver1",
                                    Camera.projOrtho(-4, 4, -4, 4));

      final Model axes = new Axes2D(-4, 4, -4, 4, 8, 8, Color.red);
      scene.addPosition(new Position(axes));

      final Model model = new Model();
      model.addVertex(new Vertex(0, 0, 0),
                      new Vertex(1, 0, 0));
      model.addPrimitive(new LineSegment(0, 1));
      ModelShading.setColor(model, Color.green);

      final Position position = new Position(model);
      scene.addPosition(position);

      final int fb_width  = 512;
      final int fb_height = 512;
      final FrameBuffer fb = new FrameBuffer(fb_width, fb_height, Color.black);

      fb.clearFB();
      Pipeline.render(scene, fb);
      fb.dumpFB2File("SimpleExamples_ver1_a_Model.ppm");

      // S_x * T_x
      final Matrix m1 = Matrix.scale(2, 1, 1).times(Matrix.translate(1, 0, 0));
      scene.getPosition(1).transform(m1);

      fb.clearFB();
      Pipeline.render(scene, fb);
      fb.dumpFB2File("SimpleExamples_ver1_b_ST.ppm");

      // T_x * S_x
      final Matrix m2 = Matrix.translate(1, 0, 0).times(Matrix.scale(2, 1, 1));
      scene.getPosition(1).transform(m2);

      fb.clearFB();
      Pipeline.render(scene, fb);
      fb.dumpFB2File("SimpleExamples_ver1_c_TS.ppm");

      // R_z * T_x
      final Matrix m3 = Matrix.rotateZ(45).times(Matrix.translate(1, 0, 0));
      scene.getPosition(1).transform(m3);

      fb.clearFB();
      Pipeline.render(scene, fb);
      fb.dumpFB2File("SimpleExamples_ver1_d_RT.ppm");

      // T_x * R_z
      final Matrix m4 = Matrix.translate(1, 0, 0).times(Matrix.rotateZ(45));
      scene.getPosition(1).transform(m4);

      fb.clearFB();
      Pipeline.render(scene, fb);
      fb.dumpFB2File("SimpleExamples_ver1_e_TR.ppm");
   }
}
/*
            Scene
              |
              |
           Position
           /      \
          /        \
       S * T      Model
    or T * S
    or R * T
    or T * R
*/
