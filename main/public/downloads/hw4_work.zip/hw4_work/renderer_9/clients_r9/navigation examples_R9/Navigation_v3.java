/*
 * Renderer 9. The MIT License.
 * Copyright (c) 2022 rlkraft@pnw.edu
 * See LICENSE for details.
*/

import renderer.scene.Scene;
import renderer.scene.Position;
import renderer.scene.Matrix;

/**

*/
public class Navigation_v3 extends Navigation_v0
{
   /**
      This constructor instantiates the Scene object
      and initializes it with appropriate geometry.
      Then this constructor instantiates the GUI.
   */
   public Navigation_v3()
   {
      super("Renderer 9 - Navigation Version 3");
   }


   protected void setTransformations(char c)
   {
      final Position position = scene.getPosition(0);
      if ('=' == c)
      {
         xTranslation = 0.0;
         yTranslation = 0.0;
         zTranslation = 0.0;
         xRotation = 0.0;
         yRotation = 0.0;
         zRotation = 0.0;
      }
      else if ('x' == c)
      {
         xTranslation -= 0.1;
      }
      else if ('X' == c)
      {
         xTranslation += 0.1;
      }
      else if ('y' == c)
      {
         yTranslation -= 0.1;
      }
      else if ('Y' == c)
      {
         yTranslation += 0.1;
      }
      else if ('z' == c)
      {
         zTranslation -= 0.1;
      }
      else if ('Z' == c)
      {
         zTranslation += 0.1;
      }
      else if ('u' == c)
      {
         xRotation -= 2.0;
      }
      else if ('U' == c)
      {
         xRotation += 2.0;
      }
      else if ('v' == c)
      {
         yRotation -= 2.0;
      }
      else if ('V' == c)
      {
         yRotation += 2.0;
      }
      else if ('w' == c)
      {
         zRotation -= 2.0;
      }
      else if ('W' == c)
      {
         zRotation += 2.0;
      }

      // Set the model-to-view transformation matrix.
      // The order of the transformations is very important!
      scene.getPosition(0).transform(
                    Matrix.translate(xTranslation,
                                     yTranslation,
                                     zTranslation)
            .times( Matrix.rotateX(xRotation) )
            .times( Matrix.rotateY(yRotation) )
            .times( Matrix.rotateZ(zRotation) ));
   }


   /**
      Create an instance of this class which has
      the affect of creating the GUI application.
   */
   public static void main(String[] args)
   {
      print_help_message();

      // We need to call the program's constructor in the
      // Java GUI Event Dispatch Thread, otherwise we get a
      // race condition between the constructor (running in
      // the main() thread) and the very first ComponentEvent
      // (running in the EDT).
      javax.swing.SwingUtilities.invokeLater(
         () -> new Navigation_v3()
      );
   }
}