/*
 * Renderer 9. The MIT License.
 * Copyright (c) 2022 rlkraft@pnw.edu
 * See LICENSE for details.
*/

import renderer.scene.*;
import renderer.scene.util.Assets;
import renderer.scene.util.ModelShading;
import renderer.models_L.ObjSimpleModel;
import renderer.models_L.PanelXZ;
import renderer.pipeline.*;
import renderer.framebuffer.*;

import java.awt.Color;
import javax.swing.JFrame;
import java.awt.BorderLayout;
import java.io.File;
import java.awt.event.KeyListener;
import java.awt.event.KeyEvent;
import java.awt.event.ComponentListener;
import java.awt.event.ComponentEvent;


/**
   This class holds all the client state information
   and implementations of the client's event handlers.
*/
public abstract class Navigation_v0 implements KeyListener, ComponentListener
{
   private static final String assets = Assets.getPath();

   protected boolean letterbox = false;
   protected double aspectRatio = 1.0;
   protected boolean perspective = true;
   protected double near   =  0.1;
   protected double left   = -1.0;
   protected double right  =  1.0;
   protected double bottom = -1.0;
   protected double top    =  1.0;
   protected boolean showCamera = false;
   protected boolean cameraChanged = false;
   protected boolean showFBaspectRatio = false;

   protected boolean showMatrix = false;
   protected double pushback = 2.0;
   protected double xTranslation = 0.0;  // leave these here for
   protected double yTranslation = 0.0;  // logging or debugging only
   protected double zTranslation = 0.0;
   protected double xRotation = 0.0;
   protected double yRotation = 0.0;
   protected double zRotation = 0.0;

   protected Scene scene;

   protected final JFrame jf;
   protected final FrameBufferPanel fbp;

   /**
      This constructor instantiates the Scene object
      and initializes it with appropriate geometry.
      Then this constructor instantiates the GUI.

      @param title  {@link String} title for this gui window
   */
   protected Navigation_v0(String title)
   {
      final Camera camera0 = Camera.projPerspective(left, right, bottom, top);
      final Camera camera1 = camera0.changeNear(near);
      final Camera camera2 = camera1.translate(0, 0, pushback);
      scene = new Scene("Navigation", camera2);

      // Create a Model object.
      final Model model = new ObjSimpleModel(new File(assets + "cessna.obj"));
      ModelShading.setRandomColor(model);

      // Create a Position object that holds the Model.
      scene.addPosition(new Position(model));

      // Create a floor grid.
      Model floorGrid = new PanelXZ(-25, 25 , -15, 5);
      ModelShading.setColor(floorGrid, Color.red);
      Position floorGrid_p = new Position(floorGrid,
                                          Matrix.translate(0, -5, -10));
      scene.addPosition(floorGrid_p);


      // Create a FrameBufferPanel that holds a FrameBuffer.
      final int width  = 900;
      final int height = 900;
      fbp = new FrameBufferPanel(width, height, Color.darkGray);
      fbp.getFrameBuffer().getViewport().setBackgroundColorVP(Color.black);

      // Create a JFrame that will hold the FrameBufferPanel.
      jf = new JFrame(title);
      jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      jf.getContentPane().add(fbp, BorderLayout.CENTER);
      jf.pack();
      jf.setLocationRelativeTo(null);
      jf.setVisible(true);

      // Create event handler objects for events from the JFrame.
      jf.addKeyListener(this);
      jf.addComponentListener(this);
   }


   // Implement the KeyListener interface.
   @Override public void keyPressed(KeyEvent e){}
   @Override public void keyReleased(KeyEvent e){}
   @Override public void keyTyped(KeyEvent e)
   {
      //System.out.println( e );

      final char c = e.getKeyChar();
      if ('h' == c)
      {
         print_help_message();
         return;
      }
      else if ('d' == c)
      {
         scene.getPosition(0).debug = ! scene.getPosition(0).debug;
         Clip.debug = scene.getPosition(0).debug;
      }
      else if ('D' == c)
      {
         Rasterize.debug = ! Rasterize.debug;
      }
      else if ('a' == c)
      {
         Rasterize.doAntiAliasing = ! Rasterize.doAntiAliasing;
         System.out.print("Anti-aliasing is turned ");
         System.out.println(Rasterize.doAntiAliasing ? "On" : "Off");
      }
      else if ('g' == c)
      {
         Rasterize.doGamma = ! Rasterize.doGamma;
         System.out.print("Gamma correction is turned ");
         System.out.println(Rasterize.doGamma ? "On" : "Off");
      }
      else if ('p' == c)
      {
         perspective = ! perspective;
         final String p = perspective ? "perspective" : "orthographic";
         System.out.println("Using " + p + " projection");
         cameraChanged = true;
      }
      else if ('l' == c)
      {
         letterbox = ! letterbox;
         System.out.print("Letter boxing is turned ");
         System.out.println(letterbox ? "On" : "Off");
      }
      else if ('n' == c || 'N' == c)
      {
         // Move the camera's near plane.
         if ('n' == c)
         {
            near -= 0.01;
         }
         else
         {
            near += 0.01;
         }
         cameraChanged = true;
      }
      else if ('r' == c || 'R' == c)
      {
         // Change the aspect ratio of the camera's view rectangle.
         if ('r' == c)
         {
            aspectRatio -= 0.1;
         }
         else
         {
            aspectRatio += 0.1;
         }

         // Adjust right and left.
         // (Keep the vertical field-of-view fixed.)
         right =  top * aspectRatio;
         left  = -right;
         System.out.printf("Aspect ratio (of camera's image rectangle) = %.2f\n", aspectRatio);
         cameraChanged = true;
      }
      else if ('o' == c || 'O' == c)
      {
         // Change left, right, bottom, and top.
         // (Keep the aspect ratio fixed.)
         if ('o' == c)
         {
            left   += 0.1 * aspectRatio;
            right  -= 0.1 * aspectRatio;
            bottom += 0.1;
            top    -= 0.1;
         }
         else
         {
            left   -= 0.1 * aspectRatio;
            right  += 0.1 * aspectRatio;
            bottom -= 0.1;
            top    += 0.1;
         }
         cameraChanged = true;
      }
      else if ('f' == c)
      {
         showFBaspectRatio = ! showFBaspectRatio;
         if (showFBaspectRatio)
         {
            // Get the new size of the FrameBufferPanel.
            final int w = fbp.getWidth();
            final int h = fbp.getHeight();
            System.out.printf("Aspect ratio (of framebuffer) = %.2f\n", (double)w/(double)h);
         }
      }
      else if ('c' == c)
      {
         // Change the solid random color of the current model.
         ModelShading.setRandomColor(scene.getPosition(0).getModel());
      }
      else if ('C' == c)
      {
         // Change each color in the cube to a random color.
         ModelShading.setRandomColors(scene.getPosition(0).getModel());
      }
      else if ('e' == c && e.isAltDown())
      {
         // Change the random color of each vertex of the cube.
         ModelShading.setRandomVertexColors(scene.getPosition(0).getModel());
      }
      else if ('e' == c)
      {
         // Change the solid random color of each edge of the cube.
         ModelShading.setRandomPrimitiveColors(scene.getPosition(0).getModel());
      }
      else if ('E' == c)
      {
         // Change the random color of each end of each edge of the cube.
         ModelShading.setRainbowPrimitiveColors(scene.getPosition(0).getModel());
      }
      else if ('M' == c)
      {
         showCamera = ! showCamera;
         if (showCamera) cameraChanged = true;
      }
      else if ('m' == c)
      {
         showMatrix = ! showMatrix;
      }

      if ('='==c
        ||'x'==c||'y'==c||'z'==c||'u'==c||'v'==c||'w'==c
        ||'X'==c||'Y'==c||'Z'==c||'U'==c||'V'==c||'W'==c)
      {
         setTransformations(c);
      }

      if (showMatrix &&
            ('m'==c||'='==c
           ||'x'==c||'y'==c||'z'==c||'u'==c||'v'==c||'w'==c
           ||'X'==c||'Y'==c||'Z'==c||'U'==c||'V'==c||'W'==c))
      {
         System.out.println("xRot = " + xRotation
                        + ", yRot = " + yRotation
                        + ", zRot = " + zRotation);
         System.out.println( scene.getPosition(0).getMatrix() );
      }

      // Render again.
      setupViewing();
   }


   // A client program can override how transformations are preformed.
   protected void setTransformations(char c)
   {
   }


   // Implement the ComponentListener interface.
   @Override public void componentMoved(ComponentEvent e){}
   @Override public void componentHidden(ComponentEvent e){}
   @Override public void componentShown(ComponentEvent e){}
   @Override public void componentResized(ComponentEvent e)
   {
      //System.out.println( e );

      // Get the new size of the FrameBufferPanel.
      final int w = fbp.getWidth();
      final int h = fbp.getHeight();

      // Create a new FrameBuffer that fits the FrameBufferPanel.
      final Color bg1 = fbp.getFrameBuffer().getBackgroundColorFB();
      final Color bg2 = fbp.getFrameBuffer().getViewport().getBackgroundColorVP();
      FrameBuffer fb = new FrameBuffer(w, h, bg1);
      fb.vp.setBackgroundColorVP(bg2);
      fbp.setFrameBuffer(fb);

      if (showFBaspectRatio)
         System.out.printf("Aspect ratio (of framebuffer) = %.2f\n", (double)w/(double)h);

      // Render again.
      setupViewing();
   }


   // Get in one place the code to set up the viewport and the view volume.
   protected void setupViewing()
   {
      // Set up the camera's view volume.
      final Camera camera1;
      if (perspective)
      {
         camera1 = Camera.projPerspective(left, right, bottom, top);
      }
      else
      {
         camera1 = Camera.projOrtho(left, right, bottom, top);
      }
      final Camera camera2 = camera1.changeNear(near);
      // Set up the camera's location.
      final Camera camera3 = camera2.translate(0, 0, pushback);
      // Switch cameras.
      scene = scene.changeCamera( camera3 );

      // Get the size of the FrameBuffer.
      final FrameBuffer fb = fbp.getFrameBuffer();
      final int w = fb.width;
      final int h = fb.height;
      // Create a viewport with the correct aspect ratio.
      if ( letterbox )
      {
         if ( aspectRatio <= w/(double)h )
         {
            final int width = (int)(h*aspectRatio);
            final int xOffset = (w - width)/2;
            fb.setViewport(xOffset, 0, width, h);
         }
         else
         {
            final int height = (int)(w/aspectRatio);
            final int yOffset = (h - height)/2;
            fb.setViewport(0, yOffset, w, height);
         }
         fb.clearFB();
         fb.vp.clearVP();
      }
      else // the viewport is the whole framebuffer
      {
         fb.setViewport();
         fb.vp.clearVP();
      }
      // Render again.
      Pipeline.render(scene, fb.vp);
      fbp.repaint();
   }


   protected static void print_help_message()
   {
      System.out.println("Use the 'd' key to toggle debugging information on and off for the current model.");
      System.out.println("Use the 'p' key to toggle between parallel and orthographic projection.");
      System.out.println("Use the x/X, y/Y, z/Z, keys to translate the model along the x, y, z axes.");
      System.out.println("Use the u/U, v/V, w/W, keys to rotate the model around the x, y, z axes.");
      System.out.println("Use the 'c' key to change the random solid model color.");
      System.out.println("Use the 'C' key to randomly change model's colors.");
    //System.out.println("Use the 'e' key to change the random vertex colors.");
      System.out.println("Use the 'e' key to change the random solid edge colors.");
      System.out.println("Use the 'E' key to change the random edge colors.");
      System.out.println("Use the 'a' key to toggle anti-aliasing on and off.");
      System.out.println("Use the 'g' key to toggle gamma correction on and off.");
      System.out.println("Use the n/N keys to move the camera's near plane.");
      System.out.println("Use the o/O keys to change the size of the camera's view rectangle.");
      System.out.println("Use the r/R keys to change the aspect ratio of the camera's view rectangle.");
      System.out.println("Use the 'f' key to toggle showing framebuffer aspect ratio.");
      System.out.println("Use the 'l' key to toggle letterboxing on and off.");
      System.out.println("Use the 'M' key to toggle showing the Camera normalization matrix.");
      System.out.println("Use the 'm' key to toggle showing the Model transformation matrix.");
      System.out.println("Use the '=' key to reset the Model transformation matrix to the identity.");
      System.out.println("Use the 'h' key to redisplay this help message.");
   }
}
