/*
 * Renderer 9. The MIT License.
 * Copyright (c) 2022 rlkraft@pnw.edu
 * See LICENSE for details.
*/

import renderer.scene.Scene;
import renderer.scene.Position;
import renderer.scene.Matrix;

/**

*/
public class Navigation_v1a extends Navigation_v0
{
   /**
      This constructor instantiates the Scene object
      and initializes it with appropriate geometry.
      Then this constructor instantiates the GUI.
   */
   public Navigation_v1a()
   {
      super("Renderer 9 - Navigation Version 1a");
   }


   protected void setTransformations(char c)
   {
      final Matrix matrix = scene.getPosition(0).getMatrix();
      if ('=' == c)
      {
         xTranslation = 0.0;
         yTranslation = 0.0;
         zTranslation = 0.0;
         xRotation = 0.0;
         yRotation = 0.0;
         zRotation = 0.0;
         scene.getPosition(0).transform( Matrix.identity() );
      }
      else if ('x' == c)
      {
         xTranslation -= 0.1;
         scene.getPosition(0).transform(
                     Matrix.translate(-0.1, 0.0, 0.0).times(matrix) );
      }
      else if ('X' == c)
      {
         xTranslation += 0.1;
         scene.getPosition(0).transform(
                     Matrix.translate(0.1, 0.0, 0.0).times(matrix) );
      }
      else if ('y' == c)
      {
         yTranslation -= 0.1;
         scene.getPosition(0).transform(
                     Matrix.translate(0.0, -0.1, 0.0).times(matrix) );
      }
      else if ('Y' == c)
      {
         yTranslation += 0.1;
         scene.getPosition(0).transform(
                     Matrix.translate(0.0, 0.1, 0.0).times(matrix) );
      }
      else if ('z' == c)
      {
         zTranslation -= 0.1;
         scene.getPosition(0).transform(
                     Matrix.translate(0.0, 0.0, -0.1).times(matrix) );
      }
      else if ('Z' == c)
      {
         zTranslation += 0.1;
         scene.getPosition(0).transform(
                     Matrix.translate(0.0, 0.0, 0.1).times(matrix) );
      }
      else if ('u' == c)
      {
         xRotation -= 2.0;
         scene.getPosition(0).transform(
                     Matrix.rotateX(-2).times(matrix) );
      }
      else if ('U' == c)
      {
         xRotation += 2.0;
         scene.getPosition(0).transform(
                     Matrix.rotateX(2).times(matrix) );
      }
      else if ('v' == c)
      {
         yRotation -= 2.0;
         scene.getPosition(0).transform(
                     Matrix.rotateY(-2).times(matrix) );
      }
      else if ('V' == c)
      {
         yRotation += 2.0;
         scene.getPosition(0).transform(
                     Matrix.rotateY(2).times(matrix) );
      }
      else if ('w' == c)
      {
         zRotation -= 2.0;
         scene.getPosition(0).transform(
                     Matrix.rotateZ(-2).times(matrix) );
      }
      else if ('W' == c)
      {
         zRotation += 2.0;
         scene.getPosition(0).transform(
                     Matrix.rotateZ(2).times(matrix) );
      }
   }


   /**
      Create an instance of this class which has
      the affect of creating the GUI application.
   */
   public static void main(String[] args)
   {
      print_help_message();

      // We need to call the program's constructor in the
      // Java GUI Event Dispatch Thread, otherwise we get a
      // race condition between the constructor (running in
      // the main() thread) and the very first ComponentEvent
      // (running in the EDT).
      javax.swing.SwingUtilities.invokeLater(
         () -> new Navigation_v1a()
      );
   }
}
