/*
 * Renderer 9. The MIT License.
 * Copyright (c) 2022 rlkraft@pnw.edu
 * See LICENSE for details.
*/

import renderer.scene.*;
import renderer.scene.util.Assets;
import renderer.scene.util.ModelShading;
import renderer.models_L.*;
import renderer.framebuffer.FrameBufferPanel;

import java.awt.Color;
import javax.swing.JFrame;
import java.awt.BorderLayout;
import java.awt.event.KeyEvent;
import java.io.File;

/**
   A rotation in three-dimensional space is specified by giving
   an angle of rotation {@code theta} and a unit vector
   {@code (u1, u2, u3)} which determines the rotation's axis.
<p>
   An important theorem in mathematics says that every rotation in
   three-dimensional space can also be specified by giving an angle
   {@code a1} of rotation around the x-axis, an angle {@code a2} of
   rotation around the y-axis, and an angle {@code a3} of rotation
   around the z-axis. That is, give rotation angle {@code theta} and
   unit vector {@code (u1, u2, u3)}, there are three angles {@code a1},
   {@code a2}, and {@code a3} so that
   <pre>{@code
      R(theta, u1, u2, u3) = R_z(a3) * R_y(a2) * R_x(a1).
   }</pre>
<p>
   Because of this theorem, many graphics systems do all of their
   rotations as a product of three rotations like this
   <pre>{@code
      R_z(a3) * R_y(a2) * R_x(a1)
   }</pre>
   Unfortunately, this scheme is prone to a problem called "gimbal lock".
<p>
   Suppose that we agree to always implement a rotation as three
   rotations in this specific order.
   <pre>{@code
      R_z(a3) * R_y(a2) * R_x(a1)
   }</pre>
   If the {@code y} rotation is �90 or �270, then the {@code x}
   and {@code z} rotations will be "locked" together. That is,
   the x-rotation and z-rotation parameters together only
   determine a rotation of one dimension instead of two.
<p>
   Here is a calculation that demonstrates this fact when the
   y-rotation is 90 degrees. Let {@code a1} and {@code a3} be
   arbitrary angles for the x-rotation and the z-rotation.
   <pre>{@code
   R_z(a3) * R_y(90) * R_x(a1)

   [cos(a3)  -sin(a3)  0]   [ cos(90)  0  sin(90)]   [1     0         0   ]
 = [sin(a3)   cos(a3)  0] * [    0     1     0   ] * [0  cos(a1)  -sin(a1)]
   [   0         0     1]   [-sin(90)  0  cos(90)]   [0  sin(a1)   cos(a1)]

   [cos(a3)  -sin(a3)  0]   [ 0  0  1]   [1     0         0   ]
 = [sin(a3)   cos(a3)  0] * [ 0  1  0] * [0  cos(a1)  -sin(a1)]
   [   0         0     1]   [-1  0  0]   [0  sin(a1)   cos(a1)]

   [cos(a3)  -sin(a3)  0]   [ 0  sin(a1)   cos(a1)]
 = [sin(a3)   cos(a3)  0] * [ 0  cos(a1)  -sin(a1)]
   [   0         0     1]   [-1    0          0   ]

   [ 0  sin(a1)*cos(a3)-sin(a3)*cos(a1)   cos(a1)*cos(a3)+sin(a1)*sin(a3)]
 = [ 0  cos(a1)*cos(a3)+sin(a1)*sin(a3)  -sin(a1)*cos(a3)+cos(a1)*sin(a3)]
   [-1                 0                                 0               ]

   [ 0  sin(a1 - a3)   cos(a1 - a3)]
 = [ 0  cos(a1 - a3)  -sin(a1 - a3)]
   [-1      0              0       ]
   }</pre>
<p>
   The final transformation has only one parameter, {@code a1-a3},
   so the final rotation is really a one-dimensional rotation, not
   a two-dimensional rotation.
<p>
   You can verify these calculations using this program.
   Use this program's key commands to set the y-rotation
   to 90 degrees and then change the x and z rotations.
   You can then see how changing the x and z rotations
   affect the transformation matrix.
<p>
   It is important to realize that gimbal lock is caused by
   implementing rotations as three rotations around the x,
   y, and z axes. If rotations are implemented some other way
   (using an angle and an axis vector, or using quaternions)
   then there is no gimbal lock.
<p>
   We can create a "gimbal lock" around any axis by putting that
   axis in the middle of the three rotation transformations. See
   the program {@link GimballModes}.
<p>
   See <a href="https://en.wikipedia.org/wiki/Gimbal_lock" target="_top">
                https://en.wikipedia.org/wiki/Gimbal_lock</a>
*/
public class GimbalLock extends InteractiveAbstractClient_R9
{
   private static final String assets = Assets.getPath();

   private final double deltaAngle = 1.0;

   /**
      This constructor instantiates the Scene object
      and initializes it with appropriate geometry.
      Then this constructor instantiates the GUI.
   */
   public GimbalLock()
   {
      scene = new Scene("GimbalLock",
                        Camera.projOrtho(fovy, aspectRatio));
      this.perspective = false;

      // Create several Model objects.
      scene.addPosition(new Position(new ObjSimpleModel(new File(assets + "cessna.obj"))));
      scene.addPosition(new Position(new ObjSimpleModel(new File(assets + "galleon.obj"))));
      scene.addPosition(new Position(new ObjSimpleModel(new File(assets + "cow.obj"))));
      scene.addPosition(new Position(new ObjSimpleModel(new File(assets + "horse.obj"))));

      // Give each model a random color.
      for (final Position p : scene.positionList)
      {
         ModelShading.setRandomColor(p.getModel());
      }

      // Create a set of x and y axes.
      final Model axes = new Axes2D(-1, +1, -1, +1, 20, 20);
      ModelShading.setColor(axes, Color.red);
      final Position axes_p = new Position(axes);
      scene.addPosition(axes_p);

      // Make the interactive models invisible, except for the current model.
      numberOfInteractiveModels = scene.positionList.size() - 1;
      for (int i = 0; i < numberOfInteractiveModels; ++i)
      {
         scene.getPosition(i).visible = false;
      }

      currentModel = 0; // airplane
      scene.getPosition(currentModel).visible = true;
      interactiveModelsAllVisible = false;

      showMatrix = true;


      // Create a FrameBufferPanel that holds a FrameBuffer.
      final int width  = 1024;
      final int height = 1024;
      fbp = new FrameBufferPanel(width, height, Color.darkGray);
      fbp.getFrameBuffer().getViewport().setBackgroundColorVP(Color.black);

      // Create a JFrame that will hold the FrameBufferPanel.
      jf = new JFrame("Renderer 9 - Gimbal Lock");
      jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      jf.getContentPane().add(fbp, BorderLayout.CENTER);
      jf.pack();
      jf.setLocationRelativeTo(null);
      jf.setVisible(true);

      // Create event handler objects for events from the JFrame.
      jf.addKeyListener(this);
      jf.addComponentListener(this);

      print_help_message();
   }


   @Override protected void setTransformations(final KeyEvent e)
   {
      final char c = e.getKeyChar();

      if ('=' == c)
      {
         xRotation[0] = 0.0;
         yRotation[0] = 0.0;
         zRotation[0] = 0.0;
      }
      else if ('x' == c)
      {
         xRotation[0] -= deltaAngle;
         if (-360 == xRotation[0]) xRotation[0] = 0;
      }
      else if ('X' == c)
      {
         xRotation[0] += deltaAngle;
         if (360 == xRotation[0]) xRotation[0] = 0;
      }
      else if ('y' == c)
      {
         yRotation[0] -= deltaAngle;
         if (-360 == yRotation[0]) yRotation[0] = 0;
      }
      else if ('Y' == c)
      {
         yRotation[0] += deltaAngle;
         if (360 == yRotation[0]) yRotation[0] = 0;
      }
      else if ('z' == c)
      {
         zRotation[0] -= deltaAngle;
         if (-360 == zRotation[0]) zRotation[0] = 0;
      }
      else if ('Z' == c)
      {
         zRotation[0] += deltaAngle;
         if (360 == zRotation[0]) zRotation[0] = 0;
      }

      // Set the model-to-view transformation matrix.
      // The order of the transformations is very important!
      final Matrix matrix = Matrix.rotateZ(zRotation[0])
                    .times( Matrix.rotateY(yRotation[0]) )//the "gimbal" can lock on the middle axis
                    .times( Matrix.rotateX(xRotation[0]) );

      scene.getPosition(currentModel).transform(matrix);
   }


   @Override protected void displayMatrix(final KeyEvent e)
   {
      final char c = e.getKeyChar();

      if (showMatrix && ('m'==c||'='==c
                       ||'x'==c||'y'==c||'z'==c
                       ||'X'==c||'Y'==c||'Z'==c))
      {
         System.out.println("xRot = " + xRotation[0]
                        + ", yRot = " + yRotation[0]
                        + ", zRot = " + zRotation[0]);
         System.out.println( scene.getPosition(0).getMatrix() );
      }
   }


   public void print_help_message()
   {
      System.out.println("Use the '/' key to cycle through the models.");
      System.out.println("Use the 'i' key to get information about the current model.");
      System.out.println("Use the 'p' key to toggle between parallel and orthographic projection.");
      System.out.println("Use the x/X, y/Y, z/Z, keys to translate the model along the x, y, z axes.");
      System.out.println("Use the u/U, v/V, w/W, keys to rotate the model around the x, y, z axes.");
      System.out.println("Use the s/S keys to scale the size of the model.");
      System.out.println("Use the 'm' key to toggle the display of matrix information.");
      System.out.println("Use the '=' key to reset the model matrix.");
      System.out.println("Use the 'c' key to change the random solid model color.");
      System.out.println("Use the 'C' key to randomly change model's colors.");
      System.out.println("Use the 'e' key to change the random solid edge colors.");
      System.out.println("Use the 'E' key to change the random edge colors.");
      System.out.println("Use the 'Alt-e' key combination to change the random vertex colors.");
      System.out.println("Use the 'a' key to toggle anti-aliasing on and off.");
      System.out.println("Use the 'g' key to toggle gamma correction on and off.");
      System.out.println("Use the 'b' key to toggle near plane clipping on and off.");
      System.out.println("Use the n/N keys to move the camera's near plane.");
      System.out.println("Use the f/F keys to change the camera's field-of-view (keep AR constant).");
      System.out.println("Use the r/R keys to change the camera's aspect ratio (keep fov constant).");
      System.out.println("Use the 'l' key to toggle letterboxing viewport on and off.");
      System.out.println("Use the arrow keys to translate the camera location left/right/up/down.");
      System.out.println("Use CTRL arrow keys to translate the camera forward/backward.");
      System.out.println("Use the 'M' key to toggle showing the Camera data.");
      System.out.println("Use the '*' key to show window data.");
      System.out.println("Use the 'P' key to convert the current model to a point cloud.");
      System.out.println("Use the '+' key to save a \"screenshot\" of the framebuffer.");
      System.out.println("Use the 'h' key to redisplay this help message.");
      System.out.println();
      System.out.println("Set the y-rotation to a multiple of �90 degrees to create gimbal lock.");
      System.out.println();
   }


   /**
      Create an instance of this class which has
      the affect of creating the GUI application.
   */
   public static void main(String[] args)
   {
      // We need to call the program's constructor in the
      // Java GUI Event Dispatch Thread, otherwise we get a
      // race condition between the constructor (running in
      // the main() thread) and the very first ComponentEvent
      // (running in the EDT).
      javax.swing.SwingUtilities.invokeLater(
         () -> new GimbalLock()
      );
   }
}
