/*
 * Renderer 9. The MIT License.
 * Copyright (c) 2022 rlkraft@pnw.edu
 * See LICENSE for details.
*/

import renderer.scene.*;
import renderer.scene.util.ModelShading;
import renderer.models_L.Disk;
import renderer.pipeline.*;
import renderer.framebuffer.*;

import java.awt.Color;
import javax.swing.JFrame;
import java.awt.BorderLayout;
import java.awt.event.KeyListener;
import java.awt.event.KeyEvent;
import java.awt.event.ComponentListener;
import java.awt.event.ComponentEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.Timer;

/**

*/
public class AntiAliasDemo implements ActionListener,
                                      KeyListener,
                                      ComponentListener
{
   private int fps;
   private Timer timer;
   private double pushback = -1.0;
   private double rotation = 0.0;
   private double delta = 1.0;
   private Color backGroundColor = Color.black;

   private final Scene scene;
   private final JFrame jf;
   private final FrameBufferPanel fbp;

   /**
      This constructor instantiates the Scene object
      and initializes it with appropriate geometry.
      Then this constructor instantiates the GUI.
   */
   public AntiAliasDemo()
   {
      scene = new Scene("AntiAliasDemo",
                        Camera.projOrtho());

      // Create a Model for the Scene.
      final Model disk = new Disk(1.0, 3, 8);
      ModelShading.setColor(disk, Color.yellow);
      scene.addPosition( new Position(disk) );

      // Define initial dimensions for a FrameBuffer.
      final int width  = 1024;
      final int height = 1024;

      // Create a FrameBufferPanel that holds a FrameBuffer.
      fbp = new FrameBufferPanel(width, height);
      fbp.getFrameBuffer().setBackgroundColorFB(Color.darkGray);
      fbp.getFrameBuffer().getViewport().setBackgroundColorVP(Color.black);

      // Create a JFrame that will hold the FrameBufferPanel.
      jf = new JFrame("Renderer 9 - Anti-alias Demo");
      jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      jf.getContentPane().add(fbp, BorderLayout.CENTER);
      jf.pack();
      jf.setLocationRelativeTo(null);
      jf.setVisible(true);

      // Create event handler objects for events from the JFrame.
      jf.addKeyListener(this);
      jf.addComponentListener(this);

      Rasterize.doAntiAliasing = true;
      Rasterize.doGamma = true;

      fps = 20;
      timer = new Timer(1000/fps, this); // ActionListener
      timer.start();
   }


   // Implement the ActionListener interface.
   @Override public void actionPerformed(ActionEvent e)
   {
      //System.out.println( e );

      // Rotate the disk model.
      scene.getPosition(0).transform(Matrix.rotateZ(rotation));
      rotation += delta;

      // Render again.
      final FrameBuffer fb = this.fbp.getFrameBuffer();
      fb.clearFB();
      Pipeline.render(scene, fb);
      fbp.repaint();
   }


   // Implement the KeyListener interface.
   @Override public void keyPressed(KeyEvent e){}
   @Override public void keyReleased(KeyEvent e){}
   @Override public void keyTyped(KeyEvent e)
   {
      //System.out.println( e );

      final char c = e.getKeyChar();
      if ('h' == c)
      {
         print_help_message();
         return;
      }
      else if ('a' == c)
      {
         Rasterize.doAntiAliasing = ! Rasterize.doAntiAliasing;
         System.out.print("Anti-aliasing is turned ");
         System.out.println(Rasterize.doAntiAliasing ? "On" : "Off");
      }
      else if ('g' == c)
      {
         Rasterize.doGamma = ! Rasterize.doGamma;
         System.out.print("Gamma correction is turned ");
         System.out.println(Rasterize.doGamma ? "On" : "Off");
      }
      else if ('b' == c)
      {
         // Change the FrameBuffer's background color.
         backGroundColor = ModelShading.randomColor();
      }
      else if ('c' == c)
      {
         // Change the solid random color of the disk.
         ModelShading.setRandomColor(scene.getPosition(0).getModel());
      }
      else if ('C' == c)
      {
         // Change each color in the disk to a random color.
         ModelShading.setRandomColors(scene.getPosition(0).getModel());
      }
      else if ('e' == c && e.isAltDown())
      {
         // Change the random color of each vertex of the disk.
         ModelShading.setRandomVertexColors(scene.getPosition(0).getModel());
      }
      else if ('e' == c)
      {
         // Change the solid random color of each edge of the disk.
         ModelShading.setRandomPrimitiveColors(scene.getPosition(0).getModel());
      }
      else if ('E' == c)
      {
         // Change the random color of each end of each edge of the disk.
         ModelShading.setRainbowPrimitiveColors(scene.getPosition(0).getModel());
      }
      else if ('r' == c)
      {
         delta += 1.0;
         System.out.println("delta = " + delta);
      }
      else if ('R' == c)
      {
         delta -= 1.0;
         System.out.println("delta = " + delta);
      }
      else if ('f' == c)
      {
         fps -= 1;
         if (0 == fps) fps = 1;
         setFPS();
         System.out.println("fps = " + fps);
      }
      else if ('F' == c)
      {
         fps += 1;
         setFPS();
         System.out.println("fps = " + fps);
      }
   }


   private void setFPS()
   {
      timer.stop();
      if (fps > 0)
      {
         timer = new Timer(1000/fps, this);
         timer.start();
      }
   }


   // Implement the ComponentListener interface.
   @Override public void componentMoved(ComponentEvent e){}
   @Override public void componentHidden(ComponentEvent e){}
   @Override public void componentShown(ComponentEvent e){}
   @Override public void componentResized(ComponentEvent e)
   {
      //System.out.println( e );
      /*
      System.out.printf("JFrame [w = %d, h = %d]: " +
                        "FrameBufferPanel [w = %d, h = %d].\n",
                        jf.getWidth(), jf.getHeight(),
                        fbp.getWidth(), fbp.getHeight());
      */
      // Get the new size of the FrameBufferPanel.
      final int w = fbp.getWidth();
      final int h = fbp.getHeight();

      // Create a new FrameBuffer that fits the FrameBufferPanel.
      final Color bg1 = fbp.getFrameBuffer().getBackgroundColorFB();
      final Color bg2 = fbp.getFrameBuffer().getViewport().getBackgroundColorVP();
      final FrameBuffer fb = new FrameBuffer(w, h, bg1);
      fb.vp.setBackgroundColorVP(bg2);
      fbp.setFrameBuffer(fb);

      // Render again.
      Pipeline.render(scene, fb);
      fbp.repaint();
   }


   /**
      Create an instance of this class which has
      the affect of creating the GUI application.
   */
   public static void main(String[] args)
   {
      print_help_message();

      // We need to call the program's constructor in the
      // Java GUI Event Dispatch Thread, otherwise we get a
      // race condition between the constructor (running in
      // the main() thread) and the very first ComponentEvent
      // (running in the EDT).
      javax.swing.SwingUtilities.invokeLater(
         () -> new AntiAliasDemo()
      );
   }


   private static void print_help_message()
   {
      System.out.println("Use the 'a' key to toggle antialiasing on and off.");
      System.out.println("Use the 'g' key to toggle gamma correction on and off.");
      System.out.println("Use the 'c' key to change the random solid model color.");
      System.out.println("Use the 'C' key to randomly change model's colors.");
    //System.out.println("Use the 'e' key to change the random vertex colors.");
      System.out.println("Use the 'e' key to change the random solid edge colors.");
      System.out.println("Use the 'E' key to change the random edge colors.");
      System.out.println("Use the r/R keys to change the speed of rotation.");
      System.out.println("Use the f/F keys to slow down or speed up the frame rate.");
      System.out.println("Use the 'h' key to redisplay this help message.");
   }
}
