/*
 * Renderer 9. The MIT License.
 * Copyright (c) 2022 rlkraft@pnw.edu
 * See LICENSE for details.
*/

import renderer.scene.*;
import renderer.scene.util.Assets;
import renderer.scene.util.ModelShading;
import renderer.models_L.*;
import renderer.framebuffer.FrameBufferPanel;

import java.awt.Color;
import javax.swing.JFrame;
import java.awt.BorderLayout;
import java.awt.event.KeyEvent;
import java.io.File;

/**
   A rotation in three-dimensional space is specified by giving
   an angle of rotation {@code theta} and a unit vector
   {@code (u1, u2, u3)} which determines the rotation's axis.
<p>
   An important theorem in mathematics says that every rotation in
   three-dimensional space can also be specified by giving an angle
   {@code a1} of rotation around the x-axis, an angle {@code a2} of
   rotation around the y-axis, and an angle {@code a3} of rotation
   around the z-axis. That is, give rotation angle {@code theta} and
   unit vector {@code (u1, u2, u3)}, there are three angles {@code a_1},
   {@code a_2} , and {@code a_3} so that
   <pre>{@code
      R(theta, u1, u2, u3) = R_z(a_3) * R_y(a_2) * R_x(a_1)
   }</pre>
<p>
   The three angles {@code a_1}, {@code a_2}, {@code a_3} are called
   the "Euler angles" of the rotation. There are five other orders
   in which the arbitrary rotation matrix can be factored into Euler
   angles. That is, give rotation angle {@code theta} and unit vector
   {@code (u1, u2, u3)}, there are 18 angles (six different triples
   of Euler angles) so that
   <pre>{@code
      R(theta, u1, u2, u3) = R_z(a_3_xyz) * R_y(a_2_xyz) * R_x(a_1_xyz)
                           = R_y(a_2_xzy) * R_z(a_3_xzy) * R_x(a_1_xzy)
                           = R_z(a_3_yxz) * R_x(a_1_yxz) * R_y(a_2_yxz)
                           = R_x(a_1_yzx) * R_z(a_3_yzx) * R_y(a_2_yzx)
                           = R_y(a_2_zxy) * R_x(a_1_zxy) * R_z(a_3_zxy)
                           = R_x(a_1_zyx) * R_y(a_2_zyx) * R_z(a_3_zyx)
   }</pre>

*/
public class GimbalModes extends InteractiveAbstractClient_R9
{
   private static final String assets = Assets.getPath();

   private final double deltaAngle = 1.0;

   private int eulerMode = 1;

   /**
      This constructor instantiates the Scene object
      and initializes it with appropriate geometry.
      Then this constructor instantiates the GUI.
   */
   public GimbalModes()
   {
      scene = new Scene("GimbalModes",
                        Camera.projOrtho(fovy, aspectRatio));
      this.perspective = false;

      // Create several Model objects.
      scene.addPosition(new Position(new ObjSimpleModel(new File(assets + "cessna.obj"))));
      scene.addPosition(new Position(new ObjSimpleModel(new File(assets + "galleon.obj"))));
      scene.addPosition(new Position(new ObjSimpleModel(new File(assets + "cow.obj"))));
      scene.addPosition(new Position(new ObjSimpleModel(new File(assets + "horse.obj"))));

      // Give each model a random color.
      for (final Position p : scene.positionList)
      {
         ModelShading.setRandomColor(p.getModel());
      }

      // Create a set of x and y axes.
      final Model axes = new Axes2D(-1, +1, -1, +1, 20, 20);
      ModelShading.setColor(axes, Color.red);
      final Position axes_p = new Position(axes);
      scene.addPosition(axes_p);

      // Make the interactive models invisible, except for the current model.
      numberOfInteractiveModels = scene.positionList.size() - 1;
      for (int i = 0; i < numberOfInteractiveModels; ++i)
      {
         scene.getPosition(i).visible = false;
      }

      currentModel = 0; // airplane
      scene.getPosition(currentModel).visible = true;
      interactiveModelsAllVisible = false;

      showMatrix = true;


      // Create a FrameBufferPanel that holds a FrameBuffer.
      final int width  = 1024;
      final int height = 1024;
      fbp = new FrameBufferPanel(width, height, Color.darkGray);
      fbp.getFrameBuffer().getViewport().setBackgroundColorVP(Color.black);

      // Create a JFrame that will hold the FrameBufferPanel.
      jf = new JFrame("Renderer 9 - Gimbal Modes");
      jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      jf.getContentPane().add(fbp, BorderLayout.CENTER);
      jf.pack();
      jf.setLocationRelativeTo(null);
      jf.setVisible(true);

      // Create event handler objects for events from the JFrame.
      jf.addKeyListener(this);
      jf.addComponentListener(this);

      print_help_message();
   }


   @Override protected void setTransformations(final KeyEvent e)
   {
      final char c = e.getKeyChar();

      if ('=' == c)
      {
         xRotation[0] = 0.0;
         yRotation[0] = 0.0;
         zRotation[0] = 0.0;
      }
      else if ('x' == c)
      {
         xRotation[0] -= deltaAngle;
         if (-360 == xRotation[0]) xRotation[0] = 0;
      }
      else if ('X' == c)
      {
         xRotation[0] += deltaAngle;
         if (360 == xRotation[0]) xRotation[0] = 0;
      }
      else if ('y' == c)
      {
         yRotation[0] -= deltaAngle;
         if (-360 == yRotation[0]) yRotation[0] = 0;
      }
      else if ('Y' == c)
      {
         yRotation[0] += deltaAngle;
         if (360 == yRotation[0]) yRotation[0] = 0;
      }
      else if ('z' == c)
      {
         zRotation[0] -= deltaAngle;
         if (-360 == zRotation[0]) zRotation[0] = 0;
      }
      else if ('Z' == c)
      {
         zRotation[0] += deltaAngle;
         if (360 == zRotation[0]) zRotation[0] = 0;
      }
      else if ('4' == c)
      {
         eulerMode = 1;
      }
      else if ('5' == c)
      {
         eulerMode = 2;
      }
      else if ('6' == c)
      {
         eulerMode = 3;
      }
      else if ('7' == c)
      {
         eulerMode = 4;
      }
      else if ('8' == c)
      {
         eulerMode = 5;
      }
      else if ('9' == c)
      {
         eulerMode = 6;
      }
      else if ('-' == c) // for debugging, eulerize the rotations
      {                  // with the R_z*R_y*R_x order (mode == 1)
         final Matrix m = scene.getPosition(currentModel).getMatrix();
         scene.setPosition(currentModel,
                  scene.getPosition(currentModel)
                          .transform(m.eulerize()));
      }

      if (1 == eulerMode)
      {
         final Matrix m = Matrix.rotateZ(zRotation[0])
                   .times(Matrix.rotateY(yRotation[0]))
                   .times(Matrix.rotateX(xRotation[0]));
         scene.setPosition(currentModel,
            scene.getPosition(currentModel).transform(m));
      }
      else if (2 == eulerMode)
      {
         final Matrix m = Matrix.rotateY(yRotation[0])
                   .times(Matrix.rotateZ(zRotation[0]))
                   .times(Matrix.rotateX(xRotation[0]));
         scene.setPosition(currentModel,
            scene.getPosition(currentModel).transform(m));
      }
      else if (3 == eulerMode)
      {
         final Matrix m = Matrix.rotateX(xRotation[0])
                   .times(Matrix.rotateZ(zRotation[0]))
                   .times(Matrix.rotateY(yRotation[0]));
         scene.setPosition(currentModel,
            scene.getPosition(currentModel).transform(m));
      }
      else if (4 == eulerMode)
      {
         final Matrix m = Matrix.rotateZ(zRotation[0])
                   .times(Matrix.rotateX(xRotation[0]))
                   .times(Matrix.rotateY(yRotation[0]));
         scene.setPosition(currentModel,
            scene.getPosition(currentModel).transform(m));
      }
      else if (5 == eulerMode)
      {
         final Matrix m = Matrix.rotateX(xRotation[0])
                   .times(Matrix.rotateY(yRotation[0]))
                   .times(Matrix.rotateZ(zRotation[0]));
         scene.setPosition(currentModel,
            scene.getPosition(currentModel).transform(m));
      }
      else if (6 == eulerMode)
      {
         final Matrix m = Matrix.rotateY(yRotation[0])
                   .times(Matrix.rotateX(xRotation[0]))
                   .times(Matrix.rotateZ(zRotation[0]));
         scene.setPosition(currentModel,
            scene.getPosition(currentModel).transform(m));
      }
   }


   @Override protected void displayMatrix(final KeyEvent e)
   {
      final char c = e.getKeyChar();

      if (showMatrix && ('m'==c||'='==c||'-'==c
                       ||'4'==c||'5'==c||'6'==c
                       ||'7'==c||'8'==c||'9'==c
                       ||'x'==c||'y'==c||'z'==c
                       ||'X'==c||'Y'==c||'Z'==c))
      {
         System.out.println();
         if (1 == eulerMode)
         {
            System.out.println("Euler mode 1: R_z * R_y * R_x");
         }
         else if (2 == eulerMode)
         {
            System.out.println("Euler mode 2: R_y * R_z * R_x");
         }
         else if (3 == eulerMode)
         {
            System.out.println("Euler mode 3: R_x * R_z * R_y");
         }
         else if (4 == eulerMode)
         {
            System.out.println("Euler mode 4: R_z * R_x * R_y");
         }
         else if (5 == eulerMode)
         {
            System.out.println("Euler mode 5: R_x * R_y * R_z");
         }
         else if (6 == eulerMode)
         {
            System.out.println("Euler mode 6: R_y * R_x * R_z");
         }
         System.out.println("xRot = " + xRotation[0]
                        + ", yRot = " + yRotation[0]
                        + ", zRot = " + zRotation[0]);
         final Matrix m = scene.getPosition(0).getMatrix();
         System.out.println( m );
         double[] eulerAngles = m.rot2euler();
         System.out.printf(" e_x = %f, e_y = %f, e_z = %f for R_z * R_y * R_x\n",
                            eulerAngles[0]*(180.0/Math.PI),
                            eulerAngles[1]*(180.0/Math.PI),
                            eulerAngles[2]*(180.0/Math.PI));
      }
   }


   public void print_help_message()
   {
      System.out.println("Use the '/' key to cycle through the models.");
      System.out.println("Use the 'p' key to toggle between parallel and orthographic projection.");
      System.out.println("Use the '4' - '9' keys to switch between six different sets of euler angles.");
      System.out.println("Use the x/X, y/Y, z/Z, keys to rotate the models around the x, y, z axes.");
      System.out.println("Use the 'm' key to toggle the display of matrix information.");
      System.out.println("Use the 'c' key to change the random solid model color.");
      System.out.println("Use the 'C' key to randomly change model's colors.");
    //System.out.println("Use the 'e' key to change the random vertex colors.");
      System.out.println("Use the 'e' key to change the random solid edge colors.");
      System.out.println("Use the 'E' key to change the random edge colors.");
      System.out.println("Use the 'a' key to toggle antialiasing on and off.");
      System.out.println("Use the 'g' key to toggle gamma correction on and off.");
      System.out.println("Use the '=' key to reset the Model transformation matrix to the identity.");
      System.out.println("Use the '-' key to \"eulerize\" the Model transformation matrix.");
      System.out.println("Use the '+' key to save a \"screenshot\" of the framebuffer.");
      System.out.println("Use the 'h' key to redisplay this help message.");
      System.out.println();
   }


   /**
      Create an instance of this class which has
      the affect of creating the GUI application.
   */
   public static void main(String[] args)
   {
      // We need to call the program's constructor in the
      // Java GUI Event Dispatch Thread, otherwise we get a
      // race condition between the constructor (running in
      // the main() thread) and the very first ComponentEvent
      // (running in the EDT).
      javax.swing.SwingUtilities.invokeLater(
         () -> new GimbalModes()
      );
   }
}
