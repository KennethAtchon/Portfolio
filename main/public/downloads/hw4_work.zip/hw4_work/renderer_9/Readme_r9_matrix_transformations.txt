
       Model Coordinates and Modeling Transformations


In the previous renderers we used a vector to position a model in a scene.
This limits how we can move a model. For example, we cannot easily rotate
a model.

This renderer modifies the Model2World.java stage to give us a better way to
position models in a scene. The new Model2World stage will implement a matrix
transformation from each model coordinate system to the world coordinate system.

In addition to the modified pipeline stage, this renderer defines a Matrix
class and modifies the Position class in the scene package. A Position object
now holds a reference to a Matrix object (instead of a Vector object). The
Matrix object determines the position (and orientation) of the Model object
in the world coordinate system.

The Matrix in a Position is used by the Model2World stage to compute the
model's location in world coordinates. For each Position in the Scene, the
Model2World stage transforms every vertex in the Position's Model by
multiplying the vertex by the Position's matrix.

      // Model2World pipeline stage
      for (Position position : scene.positionList)
      {
         for (Vertex v : position.model.vertexList)
         {
            newVertexList.add( modelMatrix.times(v) );
         }
      }

The matrix multiplication changes the coordinates in the vertex from
the model's own model coordinate system to the world coordinate system.
The world coordinate system is shared by all the models in the scene.
So the Position's Matrix places the Position's Model at a location in
the scene.

Here is what a Scene looks like now. Each Position object holds a
reference to a Matrix object instead of a Vector object.

               Scene
              /     \
             /       \
       Camera         List<Position>
                     /       |      \
                    /        |       \
            Position      Position    Position
            /  \            / \           /  \
           /    \          /   \         /    \
      Matrix   Model  Matrix  Model   Matrix  Model
                             /  |  \
                            /   |   \
                           /    |    \
                          /     |     \
                         /      |      \
             List<Vertex>  List<Color>  List<Primitive>
               /      \                      /        \
              /        \                    /          \
         Vertex        Vertex          LineSegment      LineSegment
         /  |  \       /  |  \          /     \          /     \
        /   |   \     /   |   \        /       \        /       \
       x    y    z   x    y    z    int[2]   int[2]  int[2]    int[2]


To read about matrices and matrix transformations, download
   "Geometry for Computer Graphics.pdf"
from the following link.
http://citeseerx.ist.psu.edu/viewdoc/download?doi=10.1.1.53.5654&rep=rep1&type=pdf
and read Chapters 1 and 2.


Here is how we think about "model coordinates", "world coordinates" and the
model-to-world transformation. Take a Model and pair it with a Matrix M in a
Position object. Let v0 = (x0, y0, z0) be a Vertex in the Model. The
coordinates (x0, y0, z0) are the coordinates of the vertex in the model's
own model coordinate system. When we multiply v0 by the Position's matrix M,
we get a new vertex v1 = (x1, y1, z1).

      v1 = M * v0

We use the new coordinates (x1, y1, z1) as the coordinates of a vertex in
the world coordinate system. We think of the Position's matrix M as "placing"
the vertex v0 at the location v1 in world space. Why is this useful? If the
model has millions of vertices (which is not uncommon) and we want to change
where the model is placed in world space, we can do that by changing just
the Position's matrix M instead of having to move the model by changing
every one of its vertices. The actual moving of the millions of vertices will
still need  to be done, but it will be done for us automatically by the
renderer's first pipeline stage. We only need to change the Position's matrix.

It's important to realize that while every model has its own model coordinate
system, there is only one world coordinate system. While every model has it
own "origin", the vertex (0, 0, 0), there is a single origin in world space.
Every model picks an origin for its model coordinates that is convenient for
that particular model. For example, for a model of a cube, the origin of model
coordinates might be the center of the cube, or it might be a corner of the
cube; both work well. For a model of a sphere, you would almost always make
the origin of the model space the center of the sphere, but you do not have
to (the south pole of the sphere might be a convenient origin for some
applications). For many models there is no obvious best place to put the
origin of model space (think of a cow), so an arbitrary choice gets made.


There are many reasons for using a model matrix to place and move models
around in world space. Placing every Model object in a Position object
with its own Matrix object makes many aspects of graphics programming
work better. For example, consider "composing transformations".

Suppose we want to implement the following transformation of every vertex in
some model,

   v = m2 * (m1 * v)

which applies matrix m2 to the result of applying matrix m1 to every vertex v
in the model (for example, m1 might be a rotation and m2 a translation). This
is what is meant by "composing" (or "concatenating") two transformations. We
can implement this transformation of a model with the following loop.

   for (Vertex v : model.vertexList)
   {
      v = m2 * (m1 * v); // two matrix-times-vector operations
   }

But

   m2 * (m1 * v) = (m2 * m1) * v   // associative law

So the loop can be rewritten this way.

   for (Vertex v : model.vertexList)
   {
      v  = (m2 * m1) * v; // one matrix-times-matrix operation & one matrix-times-vector operation
   }

Notice that m2 * m1 is a constant as far as the loop is concerned. Suppose
we let m = m2 * m1. That is, we multiply m2 and m1 before entering the loop.

   Matrix m = m2 * m1; // a single matrix-times-matrix operation
   for (Vertex v : model.vertexList)
   {
      v = m * v;       // a single matrix-times-vector operation
   }

Notice that this loop does half the work of the previous loops. We pay a
(very) small price to pre-multiply the two matrices before the loop, and
then the loop itself is twice as fast. This speedup is magnified if, as is
common, there are more than two matrix transformations to apply to the
vertices of a model. Compare

   for (Vertex v : model.vertexList)
   {
      Vertex v2 = m1 * v;
      Vertex v3 = m2 * v2;
      Vertex v4 = m3 * v3;
      Vertex v5 = m4 * v4;
             v  = m5 * v5;       // five matrix-times-vector operations
   }

with this

   Matrix m = m5 * m4 * m3 * m2 * m1;
   for (Vertex v : model.vertexList)
   {
      v = m * v;  // a single matrix-times-vector operation
   }


Remember that translation of a vertex can only be implemented as a matrix
multiplication when we use 4-dimensional homogeneous coordinates in the vertex
and 4 x 4 matrices (otherwise we have to implement translation of a vertex
using vector addition). Here is why it is a good idea to implement translation
using matrix multiplication instead of vector addition, even though matrix
multiplication of a vertex needs many more operations than vector addition
(16 multiplications and 12 additions vs. just three additions!).

Suppose we have five transformations, T1, T2, T3, T4, T5, where T1, T3 and T5
are rotations and T2 and T4 are translations. Suppose we want to apply them
as T5( T4( T3( T2( T1(v) ) ) ) ) for every vertex v in some model. If we
implement the translations as vector addition and the rotations as matrix
multiplications, then this would lead to code like the following, where vec2
and vec4 are the 3-dimensional vectors that represent T2 and T4, and m1, m3,
m5 are the 3x3 matrices that represent T1, T3, T5.

   for (Vertex v : model.vertexList)
   {
      Vertex v2 = m1 * v;     // 3x3 matrix multiplication
      Vertex v3 = vec2 + v2;  // vector addition
      Vertex v4 = m3 * v3;    // 3x3 matrix multiplication
      Vertex v5 = vec4 + v4;  // vector addition
      v = m5 * v5;            // 3x3 matrix multiplication
   }

On the other hand, if we represent all of the transformations as 4x4 matrices,
then the code can be written in this far more efficient way,

   Matrix m = m5 * m4 * m3 * m2 * m1;
   for (Vertex v : model.vertexList)
   {
      v = m * v;  // one 4x4 matrix multiplication
   }


The key ideas here are that,

   (i) all the possible transformations (translation, rotation, scaling,
       even projection) can be written as 4x4 homogeneous matrices,
  (ii) the associative law of matrix multiplication lets us pre-multiply
       successive transformations into a single matrix,
 (iii) matrix multiplication can be implemented in hardware very efficiently.

These three ideas combine together to make matrix multiplication the heart
of all graphics rendering pipelines.



It is worth pointing out that in our Java code we cannot write something like

   Matrix m = m5 * m4 * m3 * m2 * m1;

since Java does not let us overload the * operator (like C++ does). Similarly,
we cannot write

   m * v

for the product of a matrix and a vertex. And we cannot write

   v = m * v

to denote the updating of the coordinates in the vertex v since Java does not
let us overload the = operator (like C++ does).

In object-oriented Java, we should implement matrix multiplication as a method
in a Matrix class. So we will replace this matrix-times-matrix notation,
   m1 * m2
with this method call,
   m1.times(m2)  // m1 * m2
or this method call.
   m1.mult(m2)   // m1 * m2
We will in fact use both a times() method and a mult() method in our Matrix
class. The mult() method will be a method that mutates its calling object
so that it holds the resulting product matrix. The times() method will return
a new Matrix object that holds the resulting product matrix. Both the mult()
and the times() methods have their advantages and disadvantages. Some matrix
libraries have one, some have the other, and some have both.

We will implement the matrix-times-vertex operation
   m * v
with this method call,
   m.times(v)
where the (overloaded) times(Vertex) method in the Matrix class returns a new
Vertex object that holds the resulting vertex. Notice that a mutating
   m.mult(v)
method does not make sense. The matrix (the calling object) is not supposed
to be mutated. Mutating the parameter object, v, is very bad style. So how
should we implement a mutating matrix-times-vertex operation? We want an
operation that implements this idea.
   v = m * v
Think of this as similar to the following.
   x *= 5;  // x = 5 * x
So we want something like this,
   v *= m;  // v = m * v
which we can implement in the Vertex class with a (mutating) method like the
following.
   v.timesEquals(m)
We can also implement
   v = m * v
as
   v = m.times(v)
but this does not mutate v, it replaces the Vertex object that v refers to
with a new Vertex object.


In our code, we can write this informal, pseudo code, loop,

   Matrix m = m5 * m4 * m3 * m2 * m1;
   for (Vertex v : model.vertexList)
   {
      v = m * v;  // one matrix multiplication
   }

this way.

   Matrix m = m5.times(m4).times(m3).times(m2).times(m1);
   for (Vertex v : model.vertexList)
   {
      v.timesEquals(m);  // v = m * v
   }

This code is an abbreviation of the following code.

   Matrix m = m5;     // m = m5
   m = m.times(m4);   // m = m * m4
   m = m.times(m3);   // m = m * m3
   m = m.times(m2);   // m = m * m2
   m = m.times(m1);   // m = m * m1
   for (Vertex v : model.vertexList)
   {
      v.timesEquals(m);  // v = m * v
   }

We could also write our code this way, which uses mutation of
Matrix objects.

   Matrix m = Matrix.identity();
   m.mult(m5);    // m = I * m5
   m.mult(m4);    // m = m * m4
   m.mult(m3);    // m = m * m3
   m.mult(m2);    // m = m * m2
   m.mult(m1);    // m = m * m1
   for (Vertex v : model.vertexList)
   {
      v.timesEquals(m);  // v = m * v
   }

We could also write our code this way, which uses chaining of
the mult() method.

   Matrix m = Matrix.identity().mult(m5).mult(m4).mult(m3).mult(m2).mult(m1);
   for (Vertex v : model.vertexList)
   {
      v.timesEquals(m);  // v = m * v
   }


Exercise: Explain why the following loop does not move the model.

   for (Vertex v : model.vertexList)
   {
      v = m.times(v);  // v = m * v ?
   }


Notice that a line of code like this

   m = m.times(m5);

or like this

   m.mult(m5);

is implemented as matrix multiplication of m5 on the right of the matrix m.

   m = m * m5

Whenever we multiply a position's model matrix by some other matrix, we do
so by multiplying the other matrix on the right of the model matrix. So each
line in the following sequence of code

    position.getMatrix().mult(Matrix.translate(a, b, c));  // m = m * T(a,b,c)
    position.getMatrix().mult(Matrix.scale(s, t, u));      // m = m * S(s,t,u)
    position.getMatrix().mult(Matrix.rotateZ(r));          // m = m * Rz(r)

multiplies the appropriate transformation matrix on right of the position's
model matrix. The result is

    m = m * T(a,b,c) * S(s,t,u) * Rz(r)

A code sequence like the three matrix multiplications above can be written
in several ways in this renderer. Here are four other ways to write it.

    position.getMatrix().mult(Matrix.translate(a, b, c))
                        .mult(Matrix.scale(s, t, u))
                        .mult(Matrix.rotateZ(r));

    position.setMatrix( position.getMatrix().times(Matrix.translate(a, b, c)) );
    position.setMatrix( position.getMatrix().times(Matrix.scale(s, t, u)) );
    position.setMatrix( position.getMatrix().times(Matrix.rotateZ(r)) );

    position.setMatrix( position.getMatrix().times(Matrix.translate(a, b, c)
                                            .times(Matrix.scale(s, t, u)
                                            .times(Matrix.rotateZ(r)))) );

    position.setMatrix( position.getMatrix().times(Matrix.translate(a, b, c))
                                            .times(Matrix.scale(s, t, u))
                                            .times(Matrix.rotateZ(r)) );


Besides making it easier to move a model in a scene, a Position's model
matrix also helps us solve the "instancing problem" where we want to have
multiple instances of a model in a scene. Say we want three identical chairs
to be in a scene. If the chair is represented by a Chair class (that sub
classes the Model class), then we can easily get three chairs in the scene
by instantiating Chair three times, instantiating Position three times (one
Position object for each Chair object), and giving each Position object a
different model matrix.

                 Scene
                /      \
               /        \
          Camera         List<Position>
                        /      |       \
                       /       |        \
                      /        |         \
              Position      Position      Position
             /    \         /    \         /    \
            /      \       /      \       /      \
       Matrix    Chair  Matrix  Chair   Matrix  Chair

But why should we need three instances of the Chair class when the Chair
objects are identical? Why not let the three Position objects each refer
to the same Chair object?

                 Scene
                /      \
               /        \
          Camera         List<Position>
                        /      |       \
                       /       |        \
                      /        |         \
              Position     Position      Position
              /    \         /   |        /    /
             /      \       /    |       /    /
         Matrix      \  Matrix   |   Matrix  /
                      \          |          /
                       \         |         /
                        \        |        /
                         \       |       /
                          \      |      /
                           \     |     /
                            \    |    /
                               Chair

Since each Position object represents a different position in camera space,
the single Chair object will appear in three different places in the final
rendered scene. So we need only one instance of Chair in order to have three
identical chairs in the scene. Also, notice how what was a tree data structure
became a graph data structure (a directed acyclic graph (DAG)).



Changes
=======

This renderer adds one new file to the scene package,
   Matrix.java.
There are changes to
   Vertex.java,
   Renderer.java,
   Model2World.java,
and to the client programs.


Question: Why does the s/S scaling command work differently in
InteractiveCube_R7.java with this renderer than it did in
InteractiveCube_R6.java with the previous renderer?


Pipeline
========

Our pipeline has the same seven stages.

       v_0 ... v_n     A Model's list of (homogeneous) Vertex objects
          \   /
           \ /
            |
            | model coordinates (of v_0 ... v_n)
            |
        +-------+
        |       |
        |   P1  |    Model-to-world (matrix) transformation (of the vertices)
        |       |
        +-------+
            |
            | world coordinates (of v_0 ... v_n)
            |
        +-------+
        |       |
        |   P2  |    World-to-view transformation (of the vertices)
        |       |
        +-------+
            |
            | view coordinates (of v_0 ... v_n) relative to an arbitrary view volume
            |
        +-------+
        |       |
        |   P3  |    View-to-camera (normalization matrix) transformation (of the vertices)
        |       |
        +-------+
            |
            | camera coordinates (of v_0 ... v_n) relative to the standard view volume
            |
           / \
          /   \
         /     \
        |   P4  |   Near Clipping (of each line segment)
         \     /
          \   /
           \ /
            |
            | camera coordinates (of the near-clipped v_0 ... v_n)
            |
        +-------+
        |       |
        |   P5  |    Projection transformation (of the vertices)
        |       |
        +-------+
            |
            | image plane coordinates (of v_0 ... v_n)
            |
           / \
          /   \
         /     \
        |   P6  |   Clipping (of each line segment)
         \     /
          \   /
           \ /
            |
            | image plane coordinates (of the clipped vertices)
            |
        +-------+
        |       |
        |   P7  |    Viewport transformation (of the clipped vertices)
        |       |
        +-------+
            |
            | pixel-plane coordinates (of the clipped vertices)
            |
           / \
          /   \
         /     \
        |   P7  |   Rasterization & anti-aliasing (of each clipped line segment)
         \     /
          \   /
           \ /
            |
            |  shaded pixels (for each clipped, anti-aliased line segment)
            |
           \|/
    FrameBuffer.ViewPort
