/*
 * Renderer 8. The MIT License.
 * Copyright (c) 2022 rlkraft@pnw.edu
 * See LICENSE for details.
*/

package renderer.scene;

/**
   A {@code Position} data structure represents a geometric object
   in a distinct location in three-dimensional view space as part
   of a {@link Scene}.
<p>
   A {@code Position} object holds references to a {@link Model} object
   and a {@link Matrix} object. The {@link Model} represents the geometric
   object in the {@link Scene}. The {@link Matrix} determines the model's
   location and orientation in the {@link Camera}'s view coordinate system.
   The {@code Position}'s matrix helps us solve the problem of placing
   and moving a model in a scene.
<p>
   When the renderer renders this {@code Position}'s {@link Model} into
   a {@link renderer.framebuffer.FrameBuffer}, the first stage of the
   rendering pipeline, {@link renderer.pipeline.Model2World}, multiplies
   every {@link Vertex} in the {@link Model}'s vertex list by this
   {@code Position}'s {@link Matrix}, which converts the coordinates in
   each {@link Vertex} from the model's own local coordinate system to
   the world coordinate system (which is "shared" by all the other models
   in the scene). This matrix multiplication has the effect of "placing"
   the model in world space at an appropriate location (using the
   translation part of the matrix) and in the appropriate orientation
   (using the rotation part of the matrix).
*/
public final class Position
{
   private Model model;
   private Matrix matrix;
   public final String name;
   public boolean visible;
   public boolean debug;

   /**
      Construct a {@code Position} with the zero translation {@link Vector}
      and the given {@link Model} object.

      @param model  {@link Model} object to place at this {@code Position}
      @throws NullPointerException if {@code model} is {@code null}
   */
   public Position(final Model model)
   {
      this(model,
           model.name,        // default Position name
           Matrix.identity(), // default matrix
           true,              // visible
           false);            // debug
   }


   /**
      Construct a {@code Position} with the zero translation {@link Vector},
      the given {@link String} name, and the given {@link Model} object.

      @param model  {@link Model} object to place at this {@code Position}
      @param name   {@link String} name for this {@code Position}
      @throws NullPointerException if {@code model} is {@code null}
      @throws NullPointerException if {@code name} is {@code null}
   */
   public Position(final Model model, final String name)
   {
      this(model,
           name,
           Matrix.identity(), // default matrix
           true,              // visible
           false);            // debug
   }


   /**
      Construct a {@code Position} with the given translation {@link Vector},
      the given {@link String} name, and the given {@link Model} object.

      @param model   {@link Model} object to place at this {@code Position}
      @param name    {@link String} name for this {@code Position}
      @param matrix  transformation {@link Matrix} for this {@code Position}
      @throws NullPointerException if {@code model} is {@code null}
      @throws NullPointerException if {@code name} is {@code null}
      @throws NullPointerException if {@code translation} is {@code null}
   */
   public Position(final Model model,
                   final String name,
                   final Matrix matrix)
   {
      this(model,
           name,
           matrix,
           true,   // visible
           false); // debug
   }


   /**
      Construct a {@code Position} with the given translation {@link Vector}
      and the given {@link Model} object.

      @param model   {@link Model} object to place at this {@code Position}
      @param matrix  transformation {@link Matrix} for this {@code Position}
      @throws NullPointerException if {@code model} is {@code null}
      @throws NullPointerException if {@code translation} is {@code null}
   */
   public Position(final Model model,
                   final Matrix matrix)
   {
      this(model,
           model.name,  // default Position name
           matrix,
           true,        // visible
           false);      // debug
   }


   /**
      Construct a {@code Position} object with all the given data.

      @param model    {@link Model} object to place at this {@code Position}
      @param name     {@link String} name for this {@code Position}
      @param matrix   transformation {@link Matrix} for this {@code Position}
      @param visible  boolean that determines this {@code Position}'s visibility
      @param debug    boolean that determines if this {@code Position} is logged
      @throws NullPointerException if {@code model} is {@code null}
      @throws NullPointerException if {@code translation} is {@code null}
      @throws NullPointerException if {@code name} is {@code null}
   */
   public Position(final Model model,
                   final String name,
                   final Matrix matrix,
                   final boolean visible,
                   final boolean debug)
   {
      if (null == model)
         throw new NullPointerException("model must not be null");
      if (null == name)
         throw new NullPointerException("name must not be null");
      if (null == matrix)
         throw new NullPointerException("matrix must not be null");

      this.model = model;
      this.matrix = matrix;
      this.name = name;
      this.visible = visible;
      this.debug = debug;
   }


   /**
      Get a reference to this {@code Position}'s {@link Model} object.

      @return a reference to this {@code Position}'s {@link Model} object
   */
   public Model getModel()
   {
      return this.model;
   }


   /**
      Set this {@code Position}'s {@link Model} object.

      @param model  {@link Model} object to place at this {@code Position}
      @return a reference to this {@link Position} object to facilitate chaining method calls
      @throws NullPointerException if {@code model} is {@code null}
   */
   public Position setModel(final Model model)
   {
      if (null == model)
         throw new NullPointerException("model must not be null");

      this.model = model;
      return this;
   }


   /**
      Get a reference to this {@code Position}'s {@link Matrix} object.

      @return a reference to this {@code Position}'s {@link Matrix} object
   */
   public Matrix getMatrix()
   {
      return this.matrix;
   }


   /**
      Set this {@code Position}'s transformation {@link Matrix}.

      @param matrix  {@link Matrix} object to use in this {@code Position}
      @return a reference to this {@link Position} object to facilitate chaining method calls
      @throws NullPointerException if {@code matrix} is {@code null}
   */
   public Position transform(final Matrix matrix)
   {
      if (null == matrix)
         throw new NullPointerException("matrix must not be null");

      this.matrix = matrix;
      return this;
   }


   /**
      Set this {@code Position}'s translation vector within
      this {@code Position}'s {@link Matrix} object.

      @deprecated  Use the {@link Matrix} API instead of this method.
      This method is here for compatibility with renderers 1 through 8.

      @param x  translation amount in the x-direction
      @param y  translation amount in the y-direction
      @param z  translation amount in the z-direction
      @return a reference to this {@link Position} object to facilitate chaining method calls
   */
   @Deprecated
   public Position translate(final double x,
                             final double y,
                             final double z)
   {
      this.matrix = Matrix.translate(x, y, z);
      return this;
   }


   /**
      For debugging.

      @return {@link String} representation of this {@code Position} object
   */
   @Override
   public String toString()
   {
      String result = "";
      result += "Position: " + name + "\n";
      result += "This Position's visibility is: " + visible + "\n";
      result += "This Position's Matrix is\n";
      result += matrix + "\n";
      result += "This Position's Model is\n";
      result += (null == model) ? "null\n" : model;
      return result;
   }
}
