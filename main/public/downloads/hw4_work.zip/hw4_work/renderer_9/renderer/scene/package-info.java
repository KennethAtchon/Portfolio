/*
 * Renderer 9. The MIT License.
 * Copyright (c) 2022 rlkraft@pnw.edu
 * See LICENSE for details.
*/

/**
   Data structures for describing a 3D scene to the renderer.
*/
package renderer.scene;
