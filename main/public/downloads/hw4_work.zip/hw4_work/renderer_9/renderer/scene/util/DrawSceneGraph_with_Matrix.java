/*
 * Renderer 9. The MIT License.
 * Copyright (c) 2022 rlkraft@pnw.edu
 * See LICENSE for details.
*/

package renderer.scene.util;

import renderer.scene.*;

import java.io.File;
import java.io.PrintWriter;
import java.lang.Runtime;

/**
   This program converts a {@link Scene} data structure into
   a DOT description of the scene. The DOT description is
   then processed by the dot.exe program to produce a
   graphical image of the scene data structure.
<p>
   Create a <code>scene.png</code> file from a <code>scene.dot</code>
   file with the following command line.
   <pre>{@code
   > dot.exe -Tpng -O scene.dot
   }</pre>
<p>
   See
<br><a href="https://www.graphviz.org/Documentation.php" target="_top">
             https://www.graphviz.org/Documentation.php</a>
*/
public class DrawSceneGraph_with_Matrix
{
   /**
      This method converts the {@link Scene} data structure into a dot
      language description, then writes the dot code into a dot file,
      then runs the dot.exe program on the dot file to create a png
      image of the scene data structure.

      @param scene     {@link Scene} that needs to be converted to a dot description
      @param fileName  base name for the dot and png files
   */
   public static void draw(final Scene scene, final String fileName)
   {
      // Convert the scene data structure into a dot language description.
      final String dotDescription = scene2dot(scene);

      // Write the dot language description stored in dotDescription
      // into a dot file. Then use the dot.exe program to convert the
      // dot file into a png file.
      try
      {
         // Create the (empty) dot file.
         String baseName = fileName;
         java.io.PrintWriter out = new PrintWriter(
                                      new File(baseName + ".dot"));

         // Write the dot commands into the dot file.
         out.print( dotDescription );
         out.close();

         // Create a command-line for running the dot.exe program.
         final String dotExecutable = "C:\\Graphviz\\bin\\dot.exe";
         String[] cmd = {dotExecutable,
                         "-Tpng",
                         baseName + ".dot",
                         "-o",
                         baseName + ".png"};

         File dot = new File(dotExecutable);
         if(dot.exists() && !dot.isDirectory())
         {
            // Execute the command-line to create the png file.
            Runtime.getRuntime().exec(cmd);
         }
         else
         {
            System.out.println("\nPlease consider installing GraphViz:");
            System.out.println("  https://graphviz.org/download/");
            System.out.println("or upload the contents of " + baseName + ".dot to Graphviz Visual Editor:");
            System.out.println("  http://magjac.com/graphviz-visual-editor/");
         }
      }
      catch (Exception e)
      {
         System.out.println( e );
      }
   }


   /**
      This method generates a dot language description of the
      DAG rooted at {@code scene}.
      <p>
      This method generates the dot code for the forest of top-level
      positions just below the scene node. Each position node just
      below the scene node is the root of a DAG. This method calls
      the <code>position2dot()</code> method to recursively traverse
      the DAG of each top-level position. Every position has attached
      to it a {@link Model}, so every position node has attached to it
      a model node.

      @param  scene {@link Scene} that needs to be converted to a dot description
      @return a {@link String} containing the dot language description of the scene
   */
   public static String scene2dot(final Scene scene)
   {
      String result = "digraph {\n";

      // https://graphviz.org/docs/attrs/ordering/
      result += "graph [ordering=\"out\"];\n";

      // https://stackoverflow.com/questions/10879115/graphviz-change-font-for-the-whole-graph
      // https://graphviz.org/docs/attrs/fontname/
      result += "graph [fontname=\"helvetica\"];\n";
      result += "node  [fontname=\"helvetica\"];\n";
      result += "edge  [fontname=\"helvetica\"];\n";

      // Scene node.
      result += "scene [label=\"Scene: " + scene.name + "\"];\n";

      // Camera and List<Position> nodes under the Scene node.

      // Camera node and label.
      final String cameraNodeName = "Camera";
      result += cameraNodeName + " ";
      result += "[label=\"" + scene.camera + "\"];\n";
      // Camera edge.
      result += "scene -> " + cameraNodeName + ";\n";

      // List<Position> node and label.
      final String pListNodeName = "positionList";
      result += pListNodeName + " ";
      result += "[label=\"List<Position>\"];\n";
      // List<Position> edge.
      result += "scene -> " + pListNodeName + ";\n";

      // Create a node and two edges for each top-level
      // Position and its Model and its Matrix.
      for (int i = 0; i < scene.positionList.size(); ++i)
      {
         // Position node name.
         final String pNodeName = "_p" + i;

         // Position node and label.
         result += pNodeName + " ";
         result += "[label=\"Position: " + scene.getPosition(i).name + "\"];\n";

         // Position edge.
         result += pListNodeName + " -> " + pNodeName + ";\n";

         // Matrix node name.
         final String tNodeName = "_t" + i;

         // Matrix node and label.
         result += tNodeName + " ";
         result += "[label=\"Matrix:\n" + scene.getPosition(i).getMatrix() + "\"];\n";

         // Matrix edge.
         result += pNodeName + " -> " + tNodeName + ";\n";
       //result += pNodeName + " -> " + tNodeName + " [constraint=false];\n";

         // Model node name.
         // Check if the Model is being reused.
         int j;
         for (j = 0; j <= i; ++j)
         {
            if (scene.getPosition(j).getModel() == scene.getPosition(i).getModel())
            {
               break;
            }
         }
         final String mNodeName = "_m" + j;

         // Model node and label (if the Model hasn't already been used).
         if (j == i)
         {
            result += mNodeName + " ";
            result += "[label=\"Model: " + scene.getPosition(j).getModel().name + "\"];\n";
         }

         // Model edge.
         result += pNodeName + " -> " + mNodeName + ";\n";
      }

// Force the Positions to be in order (redundant with ordering="out").
// https://stackoverflow.com/questions/44274518/how-can-i-control-within-level-node-order-in-graphvizs-dot/44274606
// https://stackoverflow.com/questions/49793129/maintain-horizontal-ordering-of-nodes-in-graphviz
//      result += "{\n";
//      result += "rank = same;\n";
//      result += "edge[style=invis];\n";
//      result += "_p0";
//      for (int i = 0; i < scene.positionList.size(); ++i)
//      {
//         result += " -> _p" + i + " ";
//      }
//      result += ";\n";
//      result += "rankdir = LR;\n";
//      result += "}\n";

      result += "}\n";

      return result;
   }



   // Private default constructor to enforce noninstantiable class.
   // See Item 4 in "Effective Java", 3rd Ed, Joshua Bloch.
   private DrawSceneGraph_with_Matrix()
   {
      throw new AssertionError();
   }
}
