/*
 * Renderer 9. The MIT License.
 * Copyright (c) 2022 rlkraft@pnw.edu
 * See LICENSE for details.
*/

package renderer.pipeline;

import renderer.scene.*;

import java.util.List;
import java.util.ArrayList;

/**
   Transform each {@link Vertex} of a {@link Model} from the model's
   (private) local coordinate system to the (shared) world coordinate
   system.
<p>
   For each {@code Vertex} object in a {@code Model} object, use a
   {@link Position}'s transformation {@link Matrix} to transform the
   object's {@code Vertex} coordinates from a model's coordinate
   system to the world coordinate system.
*/
public class Model2World
{
   /**
      Use a {@link Position}'s transformation {@link Matrix} to transform
      each {@link Vertex} from a {@link Model}'s coordinate system to
      the world coordinate system.

      @param position  {@link Position} with a {@link Model} and a translation {@link Vector}
      @return a new {@link Model} with {@link Vertex} objects in the world coordinate system
   */
   public static Model model2world(final Position position)
   {
      final Model model = position.getModel();
      final Matrix modelMatrix = position.getMatrix();

      // A new vertex list to hold the translated vertices.
      final List<Vertex> newVertexList =
                            new ArrayList<>(model.vertexList.size());

      // Replace each Vertex object with one that
      // contains world coordinates.
      for (final Vertex v : model.vertexList)
      {
         newVertexList.add( modelMatrix.times(v) );
      }

      return new Model(newVertexList,
                       model.primitiveList,
                       model.colorList,
                       position.name + "::" + model.name,
                       model.visible);
   }



   // Private default constructor to enforce noninstantiable class.
   // See Item 4 in "Effective Java", 3rd Ed, Joshua Bloch.
   private Model2World() {
      throw new AssertionError();
   }
}
