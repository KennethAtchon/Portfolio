/*
 * Renderer 9. The MIT License.
 * Copyright (c) 2022 rlkraft@pnw.edu
 * See LICENSE for details.
*/

package renderer.pipeline;

import renderer.scene.*;
import renderer.scene.util.CheckModel;
import renderer.framebuffer.*;
import static renderer.pipeline.PipelineLogger.*;

import java.awt.Color;

/**
   This renderer takes as its input a {@link Scene} data structure
   and a {@link FrameBuffer.Viewport} within a {@link FrameBuffer}
   data structure. This renderer mutates the {@link FrameBuffer.Viewport}
   so that it is filled in with the rendered image of the geometric
   scene represented by the {@link Scene} object.
<p>
   This implements our seventh rendering pipeline. It converts the
   transformation stage {@link Model2World} to use {@link Matrix}
   transformations instead of just using {@link Vector} translations.
   There are still seven pipeline stages.
*/
public final class Pipeline2
{
   // Mostly for compatibility with renderers 1 through 3.
   public static Color DEFAULT_COLOR = Color.white;

   // Make all the intermediate Scene objects
   // available for special effects processing.
   public static Scene scene1 = null;
   public static Scene scene2 = null;
   public static Scene scene3 = null;
   public static Scene scene4 = null;
   public static Scene scene5 = null;
   public static Scene scene6 = null;

   /**
      Mutate the {@link FrameBuffer}'s default {@link FrameBuffer.Viewport}
      so that it holds the rendered image of the {@link Scene} object.

      @param scene  {@link Scene} object to render
      @param fb     {@link FrameBuffer} to hold rendered image of the {@link Scene}
   */
   public static void render(final Scene scene, final FrameBuffer fb)
   {
      render(scene, fb.vp); // render into the default viewport
   }


   /**
      Mutate the {@link FrameBuffer}'s given {@link FrameBuffer.Viewport}
      so that it holds the rendered image of the {@link Scene} object.

      @param scene  {@link Scene} object to render
      @param vp     {@link FrameBuffer.Viewport} to hold rendered image of the {@link Scene}
   */
   public static void render(final Scene scene, final FrameBuffer.Viewport vp)
   {
      PipelineLogger.debugScene = scene.debug;

      logMessage("\n= Begin Rendering of Scene (Pipeline 2): " + scene.name + " =");

      logMessage("- Current Camera:\n" + scene.camera);

      scene1 = new Scene(scene.name, scene.camera);

      logMessage("== 1. Begin model-to-world transformation of Scene ====");
      for (final Position position : scene.positionList)
      {
         PipelineLogger.debugPosition = position.debug;

         if ( position.visible )
         {
            logMessage("==== 1. Render position: "
                             + position.name + " ====");

            logMessage("---- Transformation matrix:\n" + position.getMatrix());

            if ( position.getModel().visible )
            {
               logMessage("==== 1. Model-to-world transform of: "
                                + position.getModel().name + " ====");

               CheckModel.check(position.getModel());

               // Mostly for compatibility with renderers 1 through 3.
               if (  position.getModel().colorList.isEmpty()
                 && !position.getModel().vertexList.isEmpty())
               {
                  for (int i = 0; i < position.getModel().vertexList.size(); ++i)
                  {
                     position.getModel().addColor( DEFAULT_COLOR );
                  }
                  System.err.println("***WARNING: Added default color to model: "
                                    + position.getModel().name + ".");
               }

               logVertexList("0. Model    ", position.getModel());

               final Model tempModel = Model2World.model2world(position);

               logVertexList("1. World     ", tempModel);

               scene1.addPosition( new Position(tempModel) );

               logMessage("==== 1. End Model: "
                                + tempModel.name + " ====");
            }
            else
            {
               logMessage("==== 1. Hidden model: "
                                + position.getModel().name + " ====");
            }

            logMessage("==== 1. End position: "
                             + position.name + " ====");
         }
         else
         {
            logMessage("==== 1. Hidden position: "
                             + position.name + " ====");
         }
      }
      logMessage("== 1. End model-to-world transformation of Scene ====");

      scene2 = new Scene(scene.name, scene.camera);

      logMessage("== 2. Begin world-to-view transformation of Scene ====");
      for (final Position position : scene1.positionList)
      {
         logMessage("==== 2. Transform model: "
                          + position.getModel().name + " ====");

         final Model tempModel = World2View.world2view(position.getModel(),
                                                       scene.camera);

         logVertexList("2. View   ", tempModel);

         scene2.addPosition( new Position(tempModel) );

         logMessage("==== 2. End Model: " + tempModel.name + " ====");
      }
      logMessage("== 2. End view-to-camera transformation of Scene ====");

      scene3 = new Scene(scene.name, scene.camera);

      logMessage("== 3. Begin view-to-camera transformation of Scene ====");
      for (final Position position : scene2.positionList)
      {
         logMessage("==== 3. Transform model: "
                          + position.getModel().name + " ====");

         final Model tempModel = View2Camera.view2camera(position.getModel(),
                                                         scene.camera);

         logVertexList("3. Camera   ", tempModel);
         logColorList("3. Camera   ", tempModel);
         logPrimitiveList("3. Camera   ", tempModel);

         scene3.addPosition( new Position(tempModel) );

         logMessage("==== 3. End Model: " + tempModel.name + " ====");
      }
      logMessage("== 3. End view-to-camera transformation of Scene ====");

      scene4 = new Scene(scene.name, scene.camera);

      logMessage("== 4. Begin near-plane clipping of Scene ====");
      for (final Position position : scene3.positionList)
      {
         logMessage("==== 4. Near_Clip model: "
                          + position.getModel().name + " ====");

         final Model tempModel = NearClip.clip(position.getModel(),
                                               scene.camera);

         logVertexList("4.  Near_Clipped  ", tempModel);
         logColorList("4.  Near_Clipped  ", tempModel);
         logPrimitiveList("4.  Near_Clipped  ", tempModel);

         scene4.addPosition( new Position(tempModel) );

         logMessage("==== 4. End Model: " + tempModel.name + " ====");
      }
      logMessage("== 4. End near-plane clipping of Scene ====");

      scene5 = new Scene(scene.name, scene.camera);

      logMessage("== 5. Begin projection transformation of Scene ====");
      for (final Position position : scene4.positionList)
      {
         logMessage("==== 5. Project model: "
                          + position.getModel().name + " ====");

         final Model tempModel = Projection.project(position.getModel(),
                                                    scene.camera);

         logVertexList("5. Projected", tempModel);
       //logPrimitiveList("5. Projected  ", tempModel);

         scene5.addPosition( new Position(tempModel) );

         logMessage("==== 5. End Model: " + tempModel.name + " ====");
      }
      logMessage("== 5. End projection transformation of Scene ====");

      scene6 = new Scene(scene.name, scene.camera);

      logMessage("== 6. Begin clipping of Scene ====");
      for (final Position position : scene5.positionList)
      {
         logMessage("==== 6. Clip model: "
                          + position.getModel().name + " ====");

         final Model tempModel = Clip.clip(position.getModel());

         logVertexList("6. Clipped  ", tempModel);
         logColorList("6. Clipped  ", tempModel);
         logPrimitiveList("6. Clipped  ", tempModel);

         scene6.addPosition( new Position(tempModel) );

         logMessage("==== 6. End Model: " + tempModel.name + " ====");
      }
      logMessage("== 6. End clipping of Scene ====");

      logMessage("== 7. Begin rasterization of Scene ====");
      for (final Position position : scene6.positionList)
      {
         logMessage("==== 7. Rasterize model: "
                          + position.getModel().name + " ====");

         Rasterize.rasterize(position.getModel(), vp);

         logMessage("==== 7. End Model: "
                          + position.getModel().name + " ====");
      }
      logMessage("== 7. End rasterization of Scene ====");

      logMessage("= End Rendering of Scene (Pipeline 2) =");
   }



   // Private default constructor to enforce noninstantiable class.
   // See Item 4 in "Effective Java", 3rd Ed, Joshua Bloch.
   private Pipeline2() {
      throw new AssertionError();
   }
}
