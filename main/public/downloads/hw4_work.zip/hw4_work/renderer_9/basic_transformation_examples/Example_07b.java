/*
 * Renderer 9. The MIT License.
 * Copyright (c) 2022 rlkraft@pnw.edu
 * See LICENSE for details.
*/

import renderer.scene.*;
import renderer.scene.primitives.*;
import renderer.scene.util.ModelShading;
import renderer.models_L.*;
import renderer.pipeline.*;
import renderer.framebuffer.*;

import java.awt.Color;

/**
   Rotate the unit square around its upper right hand corner.
   <pre>{@code
            y                             y

            |                             |
            |                             |
          1 +---------+                  1+        +
            |         |                   |       / \
            |         |                   |     /     \
            |         |                   |   /         \
            |         |                   |  <           >
            |         |                   |   \         /
    --------+---------+---> x     --------+-----\--+--/----> x
            |         1                   |       \1/
            |                             |
            |                             |
            |                             |
   }</pre>
<p>
   See the animation <a href="../Example_07.gif">Example_07.gif</a>.
<p>
   <a href="../Example_07.gif"><img src="../Example_07.gif" alt="Example_07.gif"></a>
<p>
   Do this by "accumulating" rotations (even though the rotations are
   sandwiched between two translations).
<p>
   In the last animation, for each new frame we always "go back" to the
   original coordinate system and then translate, rotate, and translate.
   This example shows that we don't need to go back to the original
   coordinate system. We can "save" the rotated coordinate system, then
   translate it, then draw, then "return" to the rotated coordinate
   system, accumulate another rotation (on the right), save it again,
   translate it again, then draw, etc.
   <pre>{@code
      M = T(1, 1, 0) * Rz(5*i) * T(-1, -1, 0)
        = T(1, 1, 0) * Rz(5*(i-1)) * Rz(5) * T(-1, -1, 0).
          \______________________________/
           save this product for the next iteration
   }</pre>
<p>
   This is not a better way to create the animation since it is harder to
   read. But sometimes this idea of "saving" and "restoring" a coordinate
   system can be useful.
*/
public class Example_07b
{
   public static void main(String[] args)
   {
      // Since this is a 2D example, we can use an orthographic camera.
      final double right  = 2.0;
      final double left   = -right;
      final double top    = right;
      final double bottom = -top;
      final Scene scene = new Scene("Example_07b",
                                 Camera.projOrtho(left, right, bottom, top));

      // Create a FrameBuffer to render our scene into.
      final int width  = 512;
      final int height = 512;
      final FrameBuffer fb = new FrameBuffer(width, height, Color.black);

      // Create a set of x and y axes.
      final Model axes = new Axes2D(-2, +2, -2, +2, 8, 8);
      ModelShading.setColor(axes, Color.red);
      final Position axes_p = new Position(axes);
      scene.addPosition(axes_p);

      // Add a square to the Scene.
      final Model square = new Square("Example_07b");
      final Position square_p = new Position(square);
      scene.addPosition(square_p);

      //  Rotate the square around its upper right hand corner.
      //  Do this by "accumulating" rotations (on the right).
      Matrix save = Matrix.translate(1.0, 1.0, 0);
      for (int i = 0; i < 72; ++i)
      {
         square_p.transform( save.times( Matrix.translate(-1.0, -1.0, 0) ) );

         // Render again.
         fb.clearFB(Color.darkGray);
         Pipeline.render(scene, fb);
         fb.dumpFB2File(String.format("PPM_Example_07b_Frame%03d.ppm", i));

         save = save.times(Matrix.rotateZ(5)); // accumulate a rotation (on the right)
      }
   }
}
