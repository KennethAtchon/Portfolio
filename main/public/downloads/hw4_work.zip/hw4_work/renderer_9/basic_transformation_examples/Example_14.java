/*
 * Renderer 9. The MIT License.
 * Copyright (c) 2022 rlkraft@pnw.edu
 * See LICENSE for details.
*/

import renderer.scene.*;
import renderer.scene.primitives.*;
import renderer.scene.util.ModelShading;
import renderer.models_L.*;
import renderer.pipeline.*;
import renderer.framebuffer.*;

import java.awt.Color;

/**
   Rotate the letter {@link P} around the perimeter of a circle.
<p>
   See the animation <a href="../Example_14.gif">Example_14.gif</a>.
<p>
   <a href="../Example_14.gif"><img src="../Example_14.gif" alt="Example_14.gif"></a>
*/
public class Example_14
{
   public static void main(String[] args)
   {
      // Since this is a 2D example, we can use an orthographic camera.
      final double right  = 2.0;
      final double left   = -right;
      final double top    = right;
      final double bottom = -top;
      final Scene scene = new Scene("Example_14",
                                 Camera.projOrtho(left, right, bottom, top));

      // Create a FrameBuffer to render our scene into.
      final int width  = 512;
      final int height = 512;
      final FrameBuffer fb = new FrameBuffer(width, height, Color.black);

      // Create a set of x and y axes.
      final Model axes = new Axes2D(-2, +2, -2, +2, 8, 8);
      ModelShading.setColor(axes, Color.red);
      final Position axes_p = new Position(axes);
      scene.addPosition(axes_p);

      // Create a circle of radius 1.
      final Model circle = new Circle(1.0, 32);
      ModelShading.setColor(circle, Color.green);
      final Position circle_p = new Position(circle);
      scene.addPosition(circle_p);

      // Create a Model of the letter P.
      final Model modelP = new P();
      ModelShading.setColor(modelP, new Color(50, 150, 170));
      Position modelP_p = new Position(modelP);
      scene.addPosition(modelP_p);


      // Rotate the letter P around the perimeter of the circle.
      for (int i = 0; i < 72; ++i)
      {
         // Translate the letter P to the perimeter of the circle at
         // the point 6*i degrees counter-clockwise from the point (1, 0).
         modelP_p.transform( Matrix.translate(Math.cos(5*i*Math.PI/180),
                                              Math.sin(5*i*Math.PI/180),
                                              0) );

         // Render again.
         fb.clearFB();
         Pipeline.render(scene, fb);
         fb.dumpFB2File(String.format("PPM_Example_14_Frame%03d.ppm", i));
      }
   }
}
