/*
 * Renderer 9. The MIT License.
 * Copyright (c) 2022 rlkraft@pnw.edu
 * See LICENSE for details.
*/

import renderer.scene.*;
import renderer.scene.primitives.*;
import renderer.scene.util.ModelShading;
import renderer.models_L.*;
import renderer.pipeline.*;
import renderer.framebuffer.*;

import java.awt.Color;

/**
   Rotate the letter {@link P} while scaling it twice as large for each rotation.
<p>
   See the animation <a href="../Example_31.gif">Example_31.gif</a>.
<p>
   <a href="../Example_31.gif"><img src="../Example_31.gif" alt="Example_31.gif"></a>
*/
public class Example_31
{
   public static void main(String[] args)
   {
      final Scene scene = new Scene("Example_31");

      // Create a FrameBuffer to render our scene into.
      final int width  = 512;
      final int height = 512;
      final FrameBuffer fb = new FrameBuffer(width, height);

      // Create a set of x and y axes.
      final Model axes = new Axes2D(-4, +4, -4, +4, 16, 16);
      // Color them red.
      ModelShading.setColor(axes, Color.red);
      // Push the axes away from where the camera is.
      final Position axes_p = new Position(axes);
      axes_p.setMatrix( Matrix.translate(0, 0, -4) );
      // Add the axes to the Scene.
      scene.addPosition(axes_p);

      // Create a Model of the letter P.
      final P modelP = new P();
      // Color the P blue.
      ModelShading.setColor(modelP, Color.blue);
      // Add the model to the Scene.
      final Position modelP_p = new Position(modelP);
      scene.addPosition(modelP_p);


      // Rotate the letter P while scaling it
      // twice as large for each rotation.
      for (int i = 0; i <= 120; ++i)
      {
         // Push the model away from where the camera is.
         modelP_p.setMatrix( Matrix.translate(0, 0, -4) );

         modelP_p.getMatrix().mult( Matrix.rotate(i*6, 0,0,1) );
         double scale = Math.pow(2, i/60.0);
         modelP_p.getMatrix().mult( Matrix.scale(scale, scale, 1) );

         // Render again.
         fb.clearFB(Color.darkGray);
         Pipeline.render(scene, fb);
         fb.dumpFB2File(String.format("PPM_Example_31_Frame%03d.ppm", i));
      }
   }
}
