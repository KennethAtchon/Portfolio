/*
 * Renderer 9. The MIT License.
 * Copyright (c) 2022 rlkraft@pnw.edu
 * See LICENSE for details.
*/

import renderer.scene.*;
import renderer.scene.primitives.*;
import renderer.scene.util.ModelShading;
import renderer.models_L.*;
import renderer.pipeline.*;
import renderer.framebuffer.*;

import java.awt.Color;

/**
   Translate the letter {@link P} along the y-axis while
   rotating around the letter's vertical center line (y=0.5).
<p>
   See the animation <a href="../Example_25.gif">Example_25.gif</a>.
<p>
   <a href="../Example_25.gif"><img src="../Example_25.gif" alt="Example_25.gif"></a>
<p>
   For the i'th frame of the animation, the model matrix is
   <pre>{@code
      M =  Tx(0.5) * Ry(18*i) * Tx(-0.5) * Ty(0.05*i)
   }</pre>
   Where {@code Ry} is rotation around the y-axis, {@code Ty} is
   translation in the y-direction, and {@code Tx} is translation
   in the x-direction.
*/
public class Example_25
{
   public static void main(String[] args)
   {
      // Set up a perspective camera.
      final double right  = 2.0;
      final double left   = -right;
      final double top    = 5.0;
      final double bottom = -1.0;
      final Scene scene = new Scene("Example_25",
                             Camera.projPerspective(left, right, bottom, top));

      // Create a FrameBuffer to render our scene into.
      final int width  = 400;
      final int height = 600;
      final FrameBuffer fb = new FrameBuffer(width, height);

      // Create a set of x and y axes.
      final Model axes = new Axes2D(left, right, bottom, top, 8, 12);
      // Color them red.
      ModelShading.setColor(axes, Color.red);
      // Add the axes to the Scene.
      final Position axes_p = new Position(axes);
      scene.addPosition(axes_p);
      // Push the axes away from where the camera is.
      axes_p.setMatrix( Matrix.translate(0, 0, -near) );

      // Create a Model of the letter P.
      final P modelP = new P();
      // Color the P blue.
      ModelShading.setColor(modelP, Color.blue);
      // Add the model to the Scene.
      final Position modelP_p = new Position(modelP);
      scene.addPosition(modelP_p);

      // Translate along the y-axis while rotating around
      // the letter's vertical center line (y=0.5).
      for (int i = 0; i <= 100; ++i)
      {
         // Push the model P away from where the camera is.
         modelP_p.setMatrix( Matrix.translate(0, 0, -near) );

         // Rotate P around its center axis.
         modelP_p.getMatrix().mult( Matrix.translate(0.5, 0, 0) );
         modelP_p.getMatrix().mult( Matrix.rotateY(i*18) );
         modelP_p.getMatrix().mult( Matrix.translate(-0.5, 0, 0) );
         // Translate P along the y-axis.
         modelP_p.getMatrix().mult( Matrix.translate(0, i*0.05, 0) );

         // Render again.
         fb.clearFB(Color.darkGray);
         Pipeline.render(scene, fb);
         fb.dumpFB2File(String.format("PPM_Example_25_Frame%03d.ppm", i));
      }
   }
}
