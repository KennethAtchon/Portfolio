/*
 * Renderer 9. The MIT License.
 * Copyright (c) 2022 rlkraft@pnw.edu
 * See LICENSE for details.
*/

import renderer.scene.*;
import renderer.scene.primitives.*;
import renderer.scene.util.ModelShading;
import renderer.models_L.*;
import renderer.pipeline.*;
import renderer.framebuffer.*;

import java.awt.Color;

/**
   Rotate the unit square around its lower left-hand corner
   placed on the circumference of the unit circle.
<p>
   Demonstrate the transformations of the coordinate system.
<p>
   In the last example file, we said that this code
   <pre>{@code
      square_p.setMatrix( Matrix.identity() );
      square_p.getMatrix().mult( Matrix.translate(
                                           Math.cos(5*i*Math.PI/180),
                                           Math.sin(5*i*Math.PI/180),
                                           0) );
      square_p.getMatrix().mult( Matrix.rotateZ(5*i) );
   }</pre>
   when read from the top down, should be read as a sequence of
   transformations of the coordinate system. (When it is read from
   the bottom up, it should be read as a sequence of transformations
   of vertices.) This program draws a visualization of the coordinate
   systems being transformed.
<p>
   In this animation, each frame of the last example animation is turned
   into four frames  The first frame represents this line of code
   <pre>{@code
      square_p.setMatrix( Matrix.identity() );
   }</pre>
   which restores the coordinates system to the original one. The second
   frame represents this line of code
   <pre>{@code
      square_p.getMatrix().mult( Matrix.translate(
                                           Math.cos(5*i*Math.PI/180),
                                           Math.sin(5*i*Math.PI/180),
                                           0) );
   }</pre>
   which translates the coordinate system. The third frame represents this
   line of code
   <pre>{@code
      square_p.getMatrix().mult( Matrix.rotateZ(5*i) );
   }</pre>
   which rotates the translated coordinate system. The last frame then
   draws the square model in the last coordinate system.
*/
public class Example_15d
{
   public static void main(String[] args)
   {
      // Since this is a 2D example, we can use an orthographic camera.
      final double right  = 2.0;
      final double left   = -right;
      final double top    = right;
      final double bottom = -top;
      final Scene scene = new Scene("Example_15d",
                                 Camera.projOrtho(left, right, bottom, top));

      // Create a FrameBuffer to render our scene into.
      final int width  = 512;
      final int height = 512;
      final FrameBuffer fb = new FrameBuffer(width, height, Color.black);

      // Create a set of x and y axes.
      final Model axes = new Axes2D(-2, +2, -2, +2, 8, 8);
      // Color them red.
      ModelShading.setColor(axes, Color.red);
      // Add the axes to the Scene.
      final Position axes_p = new Position(axes);
      scene.addPosition(axes_p);

      // Create two sets of x and y axes with different colors.
      final Model sAxes1 = new Axes2D(-2, +2, -2, +2, 8, 8);
      final Model sAxes2 = new Axes2D(-1.5, +1.5, -1.5, +1.5, 6, 6);
      ModelShading.setColor(sAxes1, Color.white);
      ModelShading.setColor(sAxes2, Color.blue);
      final Position sAxes1_p = new Position(sAxes1);
      final Position sAxes2_p = new Position(sAxes2);
      // Add the shorter axes to the Scene.
      scene.addPosition(sAxes1_p, sAxes2_p);

      // Add a square to the Scene.
      final Model square = new Square("Example_15d");
      final Position square_p = new Position(square);
      scene.addPosition(square_p);

      // Rotate the square around its center, with its center at the origin.
      for (int i = 0; i < 72; ++i)
      {
         sAxes1_p.transform( Matrix.translate(
                                     Math.cos(5*i*Math.PI/180),
                                     Math.sin(5*i*Math.PI/180),
                                     0) );

         sAxes2_p.transform( Matrix.translate(
                                     Math.cos(5*i*Math.PI/180),
                                     Math.sin(5*i*Math.PI/180),
                                     0)
                     .times( Matrix.rotateZ(5*i) ) );

         square_p.transform( Matrix.translate(
                                     Math.cos(5*i*Math.PI/180),
                                     Math.sin(5*i*Math.PI/180),
                                     0)
                     .times( Matrix.rotateZ(5*i) ) );

         sAxes1.visible = false;
         sAxes2.visible = false;
         square.visible = false;
         fb.clearFB(Color.darkGray);
         Pipeline.render(scene, fb);
         fb.dumpFB2File(String.format("PPM_Example_15d_Frame%03da.ppm", i));

         sAxes1.visible = true;
         fb.clearFB(Color.darkGray);
         Pipeline.render(scene, fb);
         fb.dumpFB2File(String.format("PPM_Example_15d_Frame%03db.ppm", i));

         sAxes2.visible = true;
         fb.clearFB(Color.darkGray);
         Pipeline.render(scene, fb);
         fb.dumpFB2File(String.format("PPM_Example_15d_Frame%03dc.ppm", i));

         square.visible = true;
         fb.clearFB(Color.darkGray);
         Pipeline.render(scene, fb);
         fb.dumpFB2File(String.format("PPM_Example_15d_Frame%03dd.ppm", i));
      }
   }
}
