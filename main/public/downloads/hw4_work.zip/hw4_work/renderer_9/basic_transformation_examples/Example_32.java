/*
 * Renderer 9. The MIT License.
 * Copyright (c) 2022 rlkraft@pnw.edu
 * See LICENSE for details.
*/

import renderer.scene.*;
import renderer.scene.primitives.*;
import renderer.scene.util.ModelShading;
import renderer.models_L.*;
import renderer.pipeline.*;
import renderer.framebuffer.*;

import java.awt.Color;

/**
   Rotate the letter {@link P} around the top of the {@link P}
   while scaling it twice as large for each rotation.
<p>
   The top of {@link P} should always be at the point (0, 1).
<p>
   See the animation <a href="../Example_32a.gif">Example_32a.gif</a>.
<p>
   <a href="../Example_32a.gif"><img src="../Example_32a.gif" alt="Example_32a.gif"></a>
*/
public class Example_32
{
   public static void main(String[] args)
   {
      final Scene scene = new Scene("Example_32");

      // Create a FrameBuffer to render our scene into.
      final int width  = 512;
      final int height = 512;
      final FrameBuffer fb = new FrameBuffer(width, height);

      // Create a set of x and y axes.
      final Model axes = new Axes2D(-4, +4, -4, +4, 16, 16);
      // Color them red.
      ModelShading.setColor(axes, Color.red);
      // Push the axes away from where the camera is.
      final Position axes_p = new Position(axes);
      axes_p.setMatrix( Matrix.translate(0, 0, -4) );
      // Add the axes to the Scene.
      scene.addPosition(axes_p);

      // Create a Model of the letter P.
      final P modelP = new P();
      // Color the P blue.
      ModelShading.setColor(modelP, Color.blue);
      // Add the model to the Scene.
      final Position modelP_p = new Position(modelP);
      scene.addPosition(modelP_p);


      // Rotate the letter P around the top of the P
      // while scaling it twice as large for each rotation.
      // The top of P should always be at the point (0, 1).
      for (int i = 0; i <= 120; i++)
      {
         // Push the model away from where the camera is.
         modelP_p.setMatrix( Matrix.translate(0, 0, -4) );

         modelP_p.getMatrix().mult( Matrix.translate(0, 1, 0) );
         modelP_p.getMatrix().mult( Matrix.rotate(i*6, 0,0,1) );
         double scale = Math.pow(2, i/60.0);
         modelP_p.getMatrix().mult( Matrix.scale(scale, scale, 1) );
         modelP_p.getMatrix().mult( Matrix.translate(0, -1, 0) );

         // Render again.
         fb.clearFB(Color.darkGray);
         Pipeline.render(scene, fb);
         fb.dumpFB2File(String.format("PPM_Example_32_Frame%03d.ppm", i));
      }


      // Why does this animation act different than the one just above?
      for (int i = 0; i <= 120; ++i)
      {
         // Push the model away from where the camera is.
         modelP_p.setMatrix( Matrix.translate(0, 0, -4) );

         modelP_p.getMatrix().mult( Matrix.translate(0, 1, 0) );
         modelP_p.getMatrix().mult( Matrix.rotate(i*6, 0,0,1) );
         modelP_p.getMatrix().mult( Matrix.translate(0, -1, 0) );
         double scale = Math.pow(2, i/60.0);
         modelP_p.getMatrix().mult( Matrix.scale(scale, scale, 1) );

         // Render again.
         fb.clearFB(Color.darkGray.brighter());
         Pipeline.render(scene, fb);
         fb.dumpFB2File(String.format("PPM_Example_32_Frame%03d.ppm", i+200));
      }


      // Why is this animation the same as the first one?
      for (int i = 0; i <= 120; ++i)
      {
         // Push the model away from where the camera is.
         modelP_p.setMatrix( Matrix.translate(0, 0, -4) );

         modelP_p.getMatrix().mult( Matrix.translate(0, 1, 0) );
         modelP_p.getMatrix().mult( Matrix.rotate(i*6, 0,0,1) );
         double scale = Math.pow(2, i/60.0);
         modelP_p.getMatrix().mult( Matrix.translate(0, -scale, 0) );
         modelP_p.getMatrix().mult( Matrix.scale(scale, scale, 1) );

         // Render again.
         fb.clearFB(Color.darkGray.darker());
         Pipeline.render(scene, fb);
         fb.dumpFB2File(String.format("PPM_Example_32_Frame%03d.ppm", i+400));
      }


      // Try to do this animation with the transformations
      // in the following order (from top to bottom).
      // scale, translate, rotate, translate
      for (int i = 0; i <= 120; ++i)
      {
         // Push the model away from where the camera is.
         modelP_p.setMatrix( Matrix.translate(0, 0, -4) );

         double scale = Math.pow(2, i/60.0);
         // do scale, translate, rotate, translate






         // Render again.
         fb.clearFB(Color.darkGray.brighter());
         Pipeline.render(scene, fb);
         fb.dumpFB2File(String.format("PPM_Example_32_Frame%03d.ppm", i+600));
      }


   }
}
