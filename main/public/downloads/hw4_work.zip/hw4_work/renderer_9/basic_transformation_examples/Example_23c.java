/*
 * Renderer 9. The MIT License.
 * Copyright (c) 2022 rlkraft@pnw.edu
 * See LICENSE for details.
*/

import renderer.scene.*;
import renderer.scene.primitives.*;
import renderer.scene.util.ModelShading;
import renderer.models_L.*;
import renderer.pipeline.*;
import renderer.framebuffer.*;

import java.awt.Color;

/**
   Translate the letter {@link P} along the x-axis while
   rotating around the y-axis.
 <p>
   This is another way to solve this problem.
<p>
   For the i'th frame of the animation, the model matrix is
   <pre>{@code
      M = Tx(0.05*i) * Ry(18*i)
        = Tx(0.05) * Tx(0.05*(i-1)) * Ry(18*(i-1)) * Ry(18)
   }</pre>
   Where {@code Ry} is rotation around the y-axis and {@code Tx} is
   translation in the x-direction. Notice how new rotations can be
   accumulated on the right end of the matrix product and new
   translations can be accumulated on the left end of the product.
<p>
   In the for-loop that creates the animation frames, we use the
   following code to accumulate a translation on the left of the
   model matrix in the position object, and to accumulate a rotation
   on the right of the model matrix.
   <pre>{@code
      modelP_p.transform( Matrix.translate(0.05, 0, 0)
                  .times( modelP_p.getMatrix() )
                  .times( Matrix.rotateY(18) ) );
   }</pre>
*/
public class Example_23c
{
   public static void main(String[] args)
   {
      // Set up a orthographic camera.
      final double right  = 5.0;
      final double left   = -1.0;
      final double top    = 2.0;
      final double bottom = -top;
      final Scene scene = new Scene("Example_23c",
                             Camera.projOrtho(left, right, bottom, top));

      // Create a FrameBuffer to render our scene into.
      final int width  = 600;
      final int height = 400;
      final FrameBuffer fb = new FrameBuffer(width, height, Color.black);

      // Create a set of x and y axes.
      final Model axes = new Axes2D(left, right, bottom, top, 12, 8);
      // Color them red.
      ModelShading.setColor(axes, Color.red);
      // Add the axes to the Scene.
      final Position axes_p = new Position(axes);
      scene.addPosition(axes_p);

      // Create a Model of the letter P.
      final P modelP = new P();
      // Color the P blue.
      ModelShading.setColor(modelP, Color.blue);
      // Add the model to the Scene.
      final Position modelP_p = new Position(modelP);
      scene.addPosition(modelP_p);

      // Translate along the x-axis while rotating around the y-axis.
      // (This is harder. In fact, this code doesnt work, since it
      // assumes that these rotations and translations commute.)
      for (int i = 0; i <= 100; ++i)
      {
         // Render again.
         fb.clearFB();
         Pipeline.render(scene, fb);
         fb.dumpFB2File(String.format("PPM_Example_23c_Frame%03d.ppm", i));

         // Rotate around the y-axis and translate down the x-axis.
         modelP_p.transform( Matrix.translate(0.05, 0, 0)  // Accumulate a translation on the left.
                     .times( modelP_p.getMatrix() )
                     .times( Matrix.rotateY(18) ) );       // Accumulate a rotation on the right.
      }
   }
}
