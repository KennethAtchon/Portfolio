/*
 * Renderer 9. The MIT License.
 * Copyright (c) 2022 rlkraft@pnw.edu
 * See LICENSE for details.
*/

import renderer.scene.*;
import renderer.scene.primitives.*;
import renderer.scene.util.ModelShading;
import renderer.models_L.*;
import renderer.pipeline.*;
import renderer.framebuffer.*;

import java.awt.Color;

/**
   Move the letter {@link P} counter clockwise around the perimeter
   of the unit circle with {@link P}'s lower left-hand corner on the
   circle and while rotating {@link P} clockwise around its lower
   left-hand corner.
<p>
   See the animation <a href="../Example_16_puzzle.gif">Example_16_puzzle.gif</a>.
<p>
   <a href="../Example_16_puzzle.gif"><img src="../Example_16_puzzle.gif" alt="Example_15.gif"></a>
*/
public class Example_16
{
   public static void main(String[] args)
   {
      // Since this is a 2D example, we can use an orthographic camera.
      final double right  = 2.0;
      final double left   = -right;
      final double top    = right;
      final double bottom = -top;
      final Scene scene = new Scene("Example_16",
                                 Camera.projOrtho(left, right, bottom, top));

      // Create a FrameBuffer to render our scene into.
      final int width  = 512;
      final int height = 512;
      final FrameBuffer fb = new FrameBuffer(width, height, Color.black);

      // Create a set of x and y axes.
      final Model axes = new Axes2D(-2, +2, -2, +2, 8, 8);
      ModelShading.setColor(axes, Color.red);
      final Position axes_p = new Position(axes);
      scene.addPosition(axes_p);

      // Create a circle of radius 1.
      final Model circle = new Circle(1.0, 32);
      ModelShading.setColor(circle, Color.green);
      final Position circle_p = new Position(circle);
      scene.addPosition(circle_p);

      // Create a Model of the letter P.
      final Model modelP = new P();
      ModelShading.setColor(modelP, new Color(50, 150, 170));
      final Position modelP_p = new Position(modelP);
      scene.addPosition(modelP_p);


      // Move the letter P counter clockwise around the perimeter
      // of the unit circle with P's lower left-hand corner on the
      // circle and while rotating P clockwise around its lower
      // left-hand corner.
      for (int i = 0; i < 72; ++i)
      {
         // Transform the model.






         // Render again.
         fb.clearFB();
         Pipeline.render(scene, fb);
         fb.dumpFB2File(String.format("PPM_Example_16_Frame%03d.ppm", i));
      }
   }
}
