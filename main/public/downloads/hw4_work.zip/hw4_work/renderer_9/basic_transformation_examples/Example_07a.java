/*
 * Renderer 9. The MIT License.
 * Copyright (c) 2022 rlkraft@pnw.edu
 * See LICENSE for details.
*/

import renderer.scene.*;
import renderer.scene.primitives.*;
import renderer.scene.util.ModelShading;
import renderer.models_L.*;
import renderer.pipeline.*;
import renderer.framebuffer.*;

import java.awt.Color;

/**
   Rotate the unit square around its upper right-hand corner.
   <pre>{@code
            y                             y

            |                             |
            |                             |
          1 +---------+                  1+        +
            |         |                   |       / \
            |         |                   |     /     \
            |         |                   |   /         \
            |         |                   |  <           >
            |         |                   |   \         /
    --------+---------+---> x     --------+-----\--+--/----> x
            |         1                   |       \1/
            |                             |
            |                             |
            |                             |
   }</pre>
<p>
   See the animation <a href="../Example_07.gif">Example_07.gif</a>.
<p>
   <a href="../Example_07.gif"><img src="../Example_07.gif" alt="Example_07.gif"></a>
<p>
   For the i'th frame of the animation, the square's model matrix is
   <pre>{@code
      M = T(1, 1, 0) * Rz(5*i) * T(-1, -1, 0).
   }</pre>
   As in the previous example, new rotations are being accumulated between
   two translations.
<p>
   Here is the scene tree that this program builds for the i'th frame
   of the animation. There is only one Matrix object in the scene. All
   of the transformation information needs to be in that single matrix.
   Notice how the additional transformation needed by each new frame, a
   rotation by 5 degrees, is accumulated in the middle of the position's
   matrix expression.
   <pre>{@code
             Scene
            /     \
           /       \
     Camera         List<Position>
                          |
                          |
                      Position
                     /        \
                    /          \
              Matrix            Square
        T(1,1)*Rz(5i)*T(-1,-1)
   }</pre>
*/
public class Example_07a
{
   public static void main(String[] args)
   {
      // Since this is a 2D example, we can use an orthographic camera.
      final double right  = 2.0;
      final double left   = -right;
      final double top    = right;
      final double bottom = -top;
      final Scene scene = new Scene("Example_07a",
                                 Camera.projOrtho(left, right, bottom, top));

      // Create a FrameBuffer to render our scene into.
      final int width  = 512;
      final int height = 512;
      final FrameBuffer fb = new FrameBuffer(width, height, Color.black);

      // Create a set of x and y axes.
      final Model axes = new Axes2D(-2, +2, -2, +2, 8, 8);
      ModelShading.setColor(axes, Color.red);
      final Position axes_p = new Position(axes);
      scene.addPosition(axes_p);

      // Add a square to the Scene.
      final Model square = new Square("Example_07a");
      final Position square_p = new Position(square);
      scene.addPosition(square_p);

      // Rotate the square around its upper right hand corner.
      for (int i = 0; i < 72; ++i)
      {
         // Rotate the square.
         square_p.transform( Matrix.translate(1, 1, 0)
                     .times( Matrix.rotateZ(5 * i) )
                     .times( Matrix.translate(-1, -1, 0) ) );

         // Render again.
         fb.clearFB();
         Pipeline.render(scene, fb);
         fb.dumpFB2File(String.format("PPM_Example_07a_Frame%03d.ppm", i));
      }
   }
}
