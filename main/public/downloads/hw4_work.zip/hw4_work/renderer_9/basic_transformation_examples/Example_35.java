/*
 * Renderer 9. The MIT License.
 * Copyright (c) 2022 rlkraft@pnw.edu
 * See LICENSE for details.
*/

import renderer.scene.*;
import renderer.scene.primitives.*;
import renderer.scene.util.ModelShading;
import renderer.models_L.*;
import renderer.pipeline.*;
import renderer.framebuffer.*;

import java.awt.Color;

/**
   Scale the letter {@link P} larger as its left edge
   forms a 45 degree diagonal from the positive
   y-axis to the positive x-axis.
<p>
   See the animation <a href="../Example_35.gif">Example_35.gif</a>.
<p>
   <a href="../Example_35.gif"><img src="../Example_35.gif" alt="Example_35.gif"></a>
*/
public class Example_35
{
   public static void main(String[] args)
   {
      final Scene scene = new Scene("Example_35");

      // Create a FrameBuffer to render our scene into.
      final int width  = 512;
      final int height = 512;
      final FrameBuffer fb = new FrameBuffer(width, height);

      // Create a set of x and y axes.
      final Model axes = new Axes2D(-4, +4, -4, +4, 16, 16);
      // Color them red.
      ModelShading.setColor(axes, Color.red);
      // Push the axes away from where the camera is.
      final Position axes_p = new Position(axes);
      axes_p.setMatrix( Matrix.translate(0, 0, -4) );
      // Add the axes to the Scene.
      scene.addPosition(axes_p);

      // Create a Model of the letter P.
      final P modelP = new P();
      // Color the P blue.
      ModelShading.setColor(modelP, Color.blue);
      // Add the model to the Scene.
      final Position modelP_p = new Position(modelP);
      scene.addPosition(modelP_p);


      // Scale the letter P larger as its left edge
      // forms a 45 degree diagonal from the positive
      // y-axis to the positive x-axis.
      for (int i = 2; i <= 64; i++)
      {
         // Push the model away from where the camera is.
         modelP_p.setMatrix( Matrix.translate(0, 0, -4) );

         double scale = Math.pow(i/2.0, 0.5);
         modelP_p.getMatrix().mult( Matrix.scale(scale, scale, 1) );
         modelP_p.getMatrix().mult( Matrix.translate(1/Math.pow(2, 0.5), 0, 0) );
         modelP_p.getMatrix().mult( Matrix.rotate(180, 0,1,0) );
         modelP_p.getMatrix().mult( Matrix.rotate(-45, 0,0,1) );
/*
         modelP_p.getMatrix().mult( Matrix.rotate( 45, 0,0,1) );
         modelP_p.getMatrix().mult( Matrix.rotate(180, 0,1,0) );
         double scale = Math.pow(i/2.0, 0.5);
         modelP_p.getMatrix().mult( Matrix.scale(scale, scale, 1) );
         modelP_p.getMatrix().mult( Matrix.translate(-0.5, -0.5, 0) );
*/
         // Render again.
         fb.clearFB(Color.darkGray);
         Pipeline.render(scene, fb);
         fb.dumpFB2File(String.format("PPM_Example_35_Frame%03d.ppm", i));
      }
   }
}
