/*
 * Renderer 9. The MIT License.
 * Copyright (c) 2022 rlkraft@pnw.edu
 * See LICENSE for details.
*/

import renderer.scene.*;
import renderer.scene.primitives.*;
import renderer.scene.util.ModelShading;
import renderer.models_L.*;
import renderer.pipeline.*;
import renderer.framebuffer.*;

import java.awt.Color;

/**
   Translate the letter {@link P} along the x-axis while
   rotating around the x-axis.
<p>
   See the animation <a href="../Example_22.gif">Example_22.gif</a>.
<p>
   <a href="../Example_22.gif"><img src="../Example_22.gif" alt="Example_22.gif"></a>
<p>
   For the i'th frame of the animation, the model matrix is
   <pre>{@code
      M = Tx(0.05*i) * Rx(18*i)
        = Tx(0.05) * Tx(0.05*(i-1)) * Rx(18*(i-1)) * Rx(18)
   }</pre>
   Where {@code Rx} is rotation around the x-axis and {@code Tx} is
   translation in the x-direction. Notice how new rotations can be
   accumulated on the right end of the matrix product and new
   translations can be accumulated on the left end of the product.
<p>
   When we are rotate and translate along the same axis, the rotation
   and translation matrices commute with each other. That is,
   <pre>{@code
      Rx(18) * Tx(0.05) = Tx(0.05) * Rx(18)
   }</pre>
   So in this case, it doesn't matter in what order we do the rotations
   and translations. We could put all the translations on the right and
   all the rotations on the left.
   <pre>{@code
      M = Rx(18*i) * Tx(0.05*i)
        = Rx(18) * Rx(18*(i-1)) * Tx(0.05*(i-1)) * Tx(0.05)
   }</pre>
   Or we could alternate a rotation with a translation.
   <pre>{@code
      M = Rx(18) * Tx(0.05) * Rx(18) * Tx(0.05) * ... * Rx(18) * Tx(0.05)
          \_____________________________________________________________/
                            i products of Rx(18) * Tx(0.05)
   }</pre>
   This last matrix product is easy to implement. For each new animation
   frame we accumulate one new rotation and one new translation on the
   right of the model matrix in the position object.
*/
public class Example_22
{
   public static void main(String[] args)
   {
      // Set up a orthographic camera.
      final double right  = 5.0;
      final double left   = -1.0;
      final double top    = 2.0;
      final double bottom = -top;
      final Scene scene = new Scene("Example_22",
                             Camera.projOrtho(left, right, bottom, top));

      // Create a FrameBuffer to render our scene into.
      final int width  = 600;
      final int height = 400;
      final FrameBuffer fb = new FrameBuffer(width, height, Color.black);

      // Create a set of x and y axes.
      final Model axes = new Axes2D(left, right, bottom, top, 12, 8);
      // Color them red.
      ModelShading.setColor(axes, Color.red);
      // Add the axes to the Scene.
      final Position axes_p = new Position(axes);
      scene.addPosition(axes_p);

      // Create a Model of the letter P.
      final P modelP = new P();
      // Color the P blue.
      ModelShading.setColor(modelP, Color.blue);
      // Add the model to the Scene.
      final Position modelP_p = new Position(modelP);
      scene.addPosition(modelP_p);

      // Translate along the x-axis while rotating around the x-axis.
      // (This is deceptively easy.)
      for (int i = 0; i <= 100; ++i)
      {
         // Render again.
         fb.clearFB();
         Pipeline.render(scene, fb);
         fb.dumpFB2File(String.format("PPM_Example_22_Frame%03d.ppm", i));

         // Translate down the x-axis and rotate around the x-axis.
         // The order of these transformations does not matter.
         modelP_p.transform( modelP_p.getMatrix()
                                 .times( Matrix.translate(0.05, 0, 0) ) // Accumulate the translation.
                                 .times( Matrix.rotateX(18) ) );        // Accumulate the rotation.
      }
   }
}
