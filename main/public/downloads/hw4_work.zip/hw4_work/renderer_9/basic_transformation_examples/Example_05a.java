/*
 * Renderer 9. The MIT License.
 * Copyright (c) 2022 rlkraft@pnw.edu
 * See LICENSE for details.
*/

import renderer.scene.*;
import renderer.scene.primitives.*;
import renderer.scene.util.ModelShading;
import renderer.models_L.*;
import renderer.pipeline.*;
import renderer.framebuffer.*;

import java.awt.Color;

/**
   Rotate the unit square around its center,
   with its center at the origin, (0, 0).
   <pre>{@code
       y                           y                           y

       |                           |                           |
       |                           |                           |
     1 +---------+               1 +                         1 +
       |         |                 |                           |
       |         |                 |                           |
       |    +    |            +----|----+                     /|\
       |         |            |    |    |                   /  |  \
       |         |            |    |    |                 /    |    \
  -----+---------+--> x    ---+----+----+----+--> x    --<-----+----->----+-> x
       |         1            |    |    |    1            \    |    /     1
       |                      |    |    |                   \  |  /
       |                      +----+----+                     \|/
       |                           |                           |
   }</pre>
<p>
   See the animation <a href="../Example_05.gif">Example_05.gif</a>.
<p>
   <a href="../Example_05.gif"><img src="../Example_05.gif" alt="Example_05.gif"></a>
<p>
   For the i'th frame of the animation, the square's model matrix is
   <pre>{@code
      M = Rz(5*i) * T(-0.5, -0.5, 0)
        = Rz(5) * Rz(5*(i-1)) * T(-0.5, -0.5, 0).  // acumulate a rotation on the left
   }</pre>
   Notice how each new rotation can be accumulated on the left end of
   the matrix product.
<p>
   In this example, we need to take the square model and translate it down
   1/2 unit and to the left 1/2 unit and then rotate counter-clockwise.
   <pre>{@code
       y                           y                           y

       |                           |                           |
       |                           |                           |
     1 +---------+               1 +                         1 +
       |         |                 |                           |
       |         |                 |                           |
       |    +    |            +----|----+                     /|\
       |         |            |    |    |                   /  |  \
       |         |            |    |    |                 /    |    \
  -----+---------+--> x    ---+----+----+----+--> x    --<-----+----->----+-> x
       |         1            |    |    |    1            \    |    /     1
       |                      |    |    |                   \  |  /
       |                      +----+----+                     \|/
       |                           |                           |
   }</pre>
<p>
   Let us analyze how we use matrix transformations to implement
   this animation.
<p>
   Let {@code M} denote the model matrix for the square. Initially,
   {@code M} is the identity matrix.
   <pre>{@code
               M = [ 1  0  0  0 ]
                   [ 0  1  0  0 ]
                   [ 0  0  1  0 ]
                   [ 0  0  0  1 ]
   }</pre>
<p>
   Let {@code Rz(a)} denote the 4x4 homogeneous matrix that rotates the
   xy-plane around the z-axis by angle {@code a} degrees counter-clockwise.
   <pre>{@code
           Rz(a) = [ cos(a * (pi/180))   -sin(a * (pi/180))   0   0 ]
                   [ sin(a * (pi/180))    cos(a * (pi/180))   0   0 ]
                   [       0                    0             1   0 ]
                   [       0                    0             0   1 ]
   }</pre>
<p>
   Let {@code T(a, b, c)} denote the 4x4 homogeneous matrix that translate
   by the amount {@code a} in the x-direction, the amount {@code b} in the
   y-direction, and the amount {@code c} in the z-direction.
   <pre>{@code
        T(a,b,c) = [ 1  0  0  a ]
                   [ 0  1  0  b ]
                   [ 0  0  1  c ]
                   [ 0  0  0  1 ]
   }</pre>
<p>
   To create the first frame of the animation, we want the square's model
   matrix to translate the square down half a unit and to the left half a
   unit.
   <pre>{@code
       M = T(-0.5, -0.5, 0)
   }</pre>
<p>
   To create the second frame of the animation, we want the square's model
   matrix to translate the square down and to the left and then rotate by
   5 degrees.
   <pre>{@code
       M = Rz(5) * T(-0.5, -0.5, 0)
   }</pre>
   Notice how the rotation matrix is on the left of the translation matrix.
   We want each vertex of the square model to be first translated and then
   rotated. That is, if {@code v} is a vertex from the square model we want
   <pre>{@code
      M * v = Rz(5) * T(-0.5, -0.5, 0) * v
   }</pre>
<p>
   For the third frame of the animation, we want the square's model matrix
   to first translate and then rotate by 10 degree.
   <pre>{@code
       M = Rz(5) * Rz(5) * T(-0.5, -0.5, 0)
         = Rz(10) * T(-0.5, -0.5, 0)
   }</pre>
   Notice again that the additional rotation matrix is multiplied on the left.
<p>
   For the {@code i}'th frame of the animation we want the square's model
   matrix to first translate and then rotate by {@code 5*1} degrees.
   <pre>{@code
       M = Rz(5*i) * T(-0.5, -0.5, 0)
   }</pre>
   Notice how the rotations are accumulating on the left of the square's
   model matrix. This might make you think that the loop for this animation
   would look like this.
   <pre>{@code
      for (int i = 0; i <= 72; i++)
      {
         square_p.transform( Matrix.translate(-0.5, -0.5, 0)
                     .times( Matrix.rotateZ(5*i) ) );

         fb.clearFB();
         Pipeline.render(scene, fb);
         fb.dumpFB2File(String.format("PPM_Example_05a_Frame%03d.ppm", i));
      }
   }</pre>
   This code seems to say, "set the model matrix to be translate, then rotate".
   But let us read the code very carefully. The first line in the body of the loop.
   <pre>{@code
         square_p.transform( Matrix.translate(-0.5, -0.5, 0)
   }</pre>
   means
   <pre>{@code
      M = T(-0.5, -0.5, 0)
   }</pre>
   The next line of code,
   <pre>{@code
                     .times( Matrix.rotateZ(5*i) ) );
   }</pre>
   means
   <pre>{@code
      M = T(-0.5, -0.5, 0) * R(5*i)
   }</pre>
   with the rotation matrix multiplied on the right. But this is the opposite
   of what we want. Above we said that the model matrix should translate then
   rotate, which has the formula
   <pre>{@code
      M = Rz(5*i) * T(-0.5, -0.5, 0)
   }</pre>
   Here is what the loop for creating the animation should look like.
   <pre>{@code
      for (int i = 0; i <= 72; i++)
      {
         square_p.transform( Matrix.rotateZ(5*i)
                     .times( Matrix.translate(-0.5, -0.5, 0) ) );

         fb.clearFB();
         Pipeline.render(scene, fb);
         fb.dumpFB2File(String.format("PPM_Example_05a_Frame%03d.ppm", i));
      }
   }</pre>
   If you read the code "backwards", from the bottom up, it says "translate
   and then rotate", which is what we want (when we read the formula from
   right-to-left). But if you read the code forwards, from the top down, it
   seems to say "rotate then translate". There is a way to make sense of
   both of these ways of reading the code and the second way of reading the
   code, from the top down, is actually the preferred way to read it once
   you understand how to interpret it.
<p>
   We know that the code
   <pre>{@code
      square_p.transform( Matrix.rotateZ(5*i)
                  .times( Matrix.translate(-0.5, -0.5, 0) ) );
   }</pre>
   creates the following model matrix.
   <pre>{@code
      M = Rz(5*i) * T(-0.5, -0.5, 0)
   }</pre>
   Notice how, if you read the code from the bottom up, you are reading
   the formula from right-to-left. But if you read the code from the top
   down, you are reading the formula from left-to-right. Let {@code v} be
   a vertex from the square model. When we apply the model matrix to the
   vertex, we get this formula,
   <pre>{@code
      M * v = ( Rz(5*i) * T(-0.5, -0.5, 0) ) * v
            = Rz(5*i) * ( T(-0.5, -0.5, 0) * v )    // use the associative law
   }</pre>
   which says that the vertex is first multiplied by the translation, then
   the result of the translation is multiplied by the rotation. In other
   words, "translate then rotate". So the "bottom up" (or right-to-left)
   way of reading the code tells us what the code does to each vertex.
<p>
   Here is how to read the code from the top down (or, how to read the
   formula from left-to-right). When read from the top down, we interpret
   each transformation as transforming the coordinate system. So
   <pre>{@code
      square_p.transform( Matrix.rotateZ(5*i)
   }</pre>
   means rotate the coordinate system. And
   <pre>{@code
      square_p.transform( Matrix.rotateZ(5*i)
                  .times( Matrix.translate(-0.5, -0.5, 0) ) );
   }</pre>
   means, translate the <em>rotated</em> coordinate system. And then
   the vertices of the square get plotted in the translated version
   of the rotated coordinate system.
<p>
   The next example program visualizes these transformations of the
   coordinate system.
<p>
   Here is the scene tree that this program builds for the i'th frame
   of the animation. There is only one Matrix object in the scene. All
   of the transformation information needs to be in that single matrix.
   Notice how the additional transformation needed by each new frame, a
   rotation by 5 degrees, is accumulated on the left of the position's
   matrix. Since multiplication "on the left" is not the way matrix
   multilication is implemented in most graphics libraries, this
   example is a bit more complicated than the previous example.
   <pre>{@code
             Scene
            /     \
           /       \
     Camera         List<Position>
                          |
                          |
                      Position
                     /        \
                    /          \
              Matrix            Square
         Rz(5i)*T(-1/2,-1/2)
   }</pre>
*/
public class Example_05a
{
   public static void main(String[] args)
   {
      // Since this is a 2D example, we can use an orthographic camera.
      final double right  = 2.0;
      final double left   = -right;
      final double top    = right;
      final double bottom = -top;
      final Scene scene = new Scene("Example_05a",
                                 Camera.projOrtho(left, right, bottom, top));

      // Create a FrameBuffer to render our scene into.
      final int width  = 512;
      final int height = 512;
      final FrameBuffer fb = new FrameBuffer(width, height, Color.black);

      // Create a set of x and y axes.
      final Model axes = new Axes2D(-2, +2, -2, +2, 8, 8);
      // Color them red.
      ModelShading.setColor(axes, Color.red);
      // Add the axes to the Scene.
      final Position axes_p = new Position(axes);
      scene.addPosition(axes_p);

      // Add a square to the Scene.
      final Model square = new Square("Example_05a");
      final Position square_p = new Position(square);
      scene.addPosition(square_p);

      // Rotate the square around its center,
      // with its center at the origin.
      for (int i = 0; i < 72; ++i)
      {
         square_p.transform( Matrix.rotateZ(5*i)
                     .times( Matrix.translate(-0.5, -0.5, 0) ) );

         // Render again.
         fb.clearFB();
         Pipeline.render(scene, fb);
         fb.dumpFB2File(String.format("PPM_Example_05a_Frame%03d.ppm", i));
      }
   }
}
