/*
 * Renderer 9. The MIT License.
 * Copyright (c) 2022 rlkraft@pnw.edu
 * See LICENSE for details.
*/

import renderer.scene.*;
import renderer.scene.primitives.*;

import java.awt.Color;

/**
   Create a wireframe model of a decorated square in the xy-plane
   with it lower left-hand corner at the origin. The decorations
   are meant to break up the square's symmetry, so that we can
   distinguish each corner, no matter what is square's orientation.
<p>
   Here is a picture showing how the decorated square's vertices
   are labeled.
<pre>{@code
        y
        |
        |
        |         v5
     v1 +--------+---------+ v2
        | \      |         |
        |   \    |         |
        |     \  |         |
        |       \|         |
     v4 +        +---------+ v6
        |       / v8       |
        |     /            |
        |   /              |
        | /                |
        +--------+---------+------> x

}</pre>
*/
public class Square extends Model
{
   /**
      Create a decorated square in the xy-plane with corners {@code (�1, �1, 0)}.

      @param name  a {link String} that is a name for this {@link Model}
   */
   public Square(final String name)
   {
      this(name, 1);
   }


   /**
      Create a decorated square in the xy-plane with its lower left-hand corner
      at {@code (0, 0, 0)} and its upper right-hand corner at{@code (r, r, 0)}.

      @param name  a {link String} that is a name for this {@link Model}
      @param r     determines the corners of the square
   */
   public Square(final String name, double r)
   {
      super(name);

      r = Math.abs(r);

      // Create the square's perimeter.
      addVertex(new Vertex(0, 0, 0),
                new Vertex(0, r, 0),
                new Vertex(r, r, 0),
                new Vertex(r, 0, 0));

      addPrimitive(new LineSegment(0, 1),
                   new LineSegment(1, 2),
                   new LineSegment(2, 3),
                   new LineSegment(3, 0));

      addColor(Color.blue,
               Color.yellow,
               Color.magenta,
               Color.green);

      // Create the square's "decorations".
      addVertex(new Vertex( 0,  r/2, 0),  // center left edge
                new Vertex(r/2,  r,  0),  // center top edge
                new Vertex( r,  r/2, 0),  // center right edge
                new Vertex(r/2,  0,  0),  // center bottom edge
                new Vertex(r/2, r/2, 0)); // center of square

      addPrimitive(new LineSegment(8, 0),
                   new LineSegment(8, 1),
                   new LineSegment(8, 5),
                   new LineSegment(8, 6));

      addColor(new Color(0.5f, 0.5f, 0.5f),
               new Color(1.0f, 0.5f, 0.5f),
               new Color(0.5f, 0.5f, 0.5f),
               new Color(0.0f, 0.5f, 0.5f),
               Color.red);
   }


   public static void main(String[] args)
   {
      final double right  = 2.0;
      final double left   = -right;
      final double top    = right;
      final double bottom = -top;
      final Scene scene = new Scene("Square",
                                 Camera.projOrtho(left, right, bottom, top));

      final renderer.framebuffer.FrameBuffer fb
                = new renderer.framebuffer.FrameBuffer(512, 512, Color.black);

      final Model axes = new renderer.models_L.Axes2D(-2, +2, -2, +2, 8, 8);
      renderer.scene.util.ModelShading.setColor(axes, Color.red);
      scene.addPosition(new Position(axes));

      scene.addPosition(new Position(new Square("Square")));

      renderer.pipeline.Pipeline.render(scene, fb);
      fb.dumpFB2File("Square.ppm");
   }
}
