/*
 * Renderer 9. The MIT License.
 * Copyright (c) 2022 rlkraft@pnw.edu
 * See LICENSE for details.
*/

import renderer.scene.*;
import renderer.scene.primitives.*;
import renderer.scene.util.ModelShading;
import renderer.models_L.*;
import renderer.pipeline.*;
import renderer.framebuffer.*;

import java.awt.Color;

/**
   Rotate the unit square around its lower left-hand corner
   placed at the point (-1, 0).
   <pre>{@code
            y                                    y

            |                                    |
            |                          / \       |
          1 +---------+              /     \   1 +
            |         |            /         \   |
            |         |           <           >  |
            |         |            \         /   |
            |         |              \     /     |
            |         |                \ /       |
    --------+---------+---> x     ------+--------+--------+------> x
            |         1                -1        |        1
            |                                    |
            |                                    |
   }</pre>
<p>
   See the animation <a href="../Example_03.gif">Example_03.gif</a>.
<p>
   <a href="../Example_03.gif"><img src="../Example_03.gif" alt="Example_03.gif"></a>
<p>
   For the i'th frame of the animation, the square's model matrix is
   <pre>{@code
      M = T(-1, 0, 0) * Rz(5*i)
        = T(-1, 0, 0) * Rz(5*(i-1)) * Rz(5).  // acumulate a rotation on the right
   }</pre>
   Notice how each new rotation can be accumulated on the right end of
   the matrix product.
<p>
   In the code below, the main loop for creating the animation frames
   looks like this.
   <pre>{@code
      for (int i = 0; i < 72; ++i)
      {
         square_p.transform( Matrix.translate(-1, 0, 0)
                     .times( Matrix.rotateZ(5 * i) ) );

         fb.clearFB();
         Pipeline.render(scene, fb);
         fb.dumpFB2File(String.format("PPM_Example_03a_Frame%03d.ppm", i));
      }
   }</pre>
<p>
   A second, alternative, loop for creating the animation looks like this.
   <pre>{@code
      square_p.transform( Matrix.translate(-1, 0, 0) );
      for (int i = 0; i < 72; ++i)
      {
         fb.clearFB();
         Pipeline.render(scene, fb);
         fb.dumpFB2File(String.format("PPM_Example_03b_Frame%03d.ppm", i));

         square_p.transform( square_p.getMatrix().times(Matrix.rotateZ(5)) );
      }
   }</pre>
<p>
   As in the previous loop, each frame of the animation rotates the
   square another 5 degrees from the previous frame. The difference in
   this loop is the single translation of the model before the loop.
   The rotations are being accumulated "after" the translation if you
   read this code from top to bottom (or you read the tranformation
   formula from left-to-right). On the other hand, the rotations are
   being accumulated "before" the translation if you read this code
   from the bottom up (or you read the tranformation formula from
   right-to-left).
<p>
   Here is the scene tree that this program builds for the i'th frame
   of the animation. There is only one Matrix object in the scene. All
   of the transformation information needs to be in that single matrix.
   Notice how the additional transformation needed by each new frame, a
   rotation by 5 degrees, is accumulated on the right of the position's
   matrix.
   <pre>{@code
             Scene
            /     \
           /       \
     Camera         List<Position>
                          |
                          |
                      Position
                     /        \
                    /          \
              Matrix            Square
         T(-1,0)*Rz(5i)
   }</pre>
*/
public class Example_03
{
   public static void main(String[] args)
   {
      // Since this is a 2D example, we can use an orthographic camera.
      final double right  = 2.0;
      final double left   = -right;
      final double top    = right;
      final double bottom = -top;
      final Scene scene = new Scene("Example_03",
                                 Camera.projOrtho(left, right, bottom, top));

      // Create a FrameBuffer to render our scene into.
      final int width  = 512;
      final int height = 512;
      final FrameBuffer fb = new FrameBuffer(width, height, Color.black);

      // Create a set of x and y axes.
      final Model axes = new Axes2D(-2, +2, -2, +2, 8, 8);
      ModelShading.setColor(axes, Color.red);
      final Position axes_p = new Position(axes);
      scene.addPosition(axes_p);

      // Add a square to the Scene.
      final Model square = new Square("Example_03");
      final Position square_p = new Position(square);
      scene.addPosition(square_p);

      // Rotate the square around its lower left-hand corner
      // placed at the point (1,0).
      for (int i = 0; i < 72; ++i)
      {
         // Translate the square's lower left-hand corner to the point (1,0,0)
         // and then rotate the square.
         square_p.transform( Matrix.translate(-1, 0, 0)
                     .times( Matrix.rotateZ(5 * i) ) );

         // Render again.
         fb.clearFB();
         Pipeline.render(scene, fb);
         fb.dumpFB2File(String.format("PPM_Example_03a_Frame%03d.ppm", i));
      }


      // Second version.
      // Translate the square's lower left-hand corner to the point (1, 0).
      square_p.transform( Matrix.translate(-1, 0, 0) );
      //Rotate the square around its lower left-hand corner.
      for (int i = 0; i < 72; ++i)
      {
         // Render again.
         fb.clearFB(Color.darkGray);
         Pipeline.render(scene, fb);
         fb.dumpFB2File(String.format("PPM_Example_03b_Frame%03d.ppm", i));

         // Accumulate a rotation of the square in the Position's matrix.
         square_p.transform( square_p.getMatrix().times(Matrix.rotateZ(5)) );
      }
   }
}
