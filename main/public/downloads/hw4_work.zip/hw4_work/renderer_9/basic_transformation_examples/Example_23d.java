/*
 * Renderer 9. The MIT License.
 * Copyright (c) 2022 rlkraft@pnw.edu
 * See LICENSE for details.
*/

import renderer.scene.*;
import renderer.scene.primitives.*;
import renderer.scene.util.ModelShading;
import renderer.models_L.*;
import renderer.pipeline.*;
import renderer.framebuffer.*;

import java.awt.Color;

/**
   Translate the letter {@link P} along the x-axis while
   rotating around the y-axis.
 <p>
   This is one way to solve this problem, but it is not the best way.
<p>
   For the i'th frame of the animation, the model matrix is
   <pre>{@code
      M = Tx(0.05*i) * Ry(18*i)
        = Tx(0.05*(i-1)) * Tx(0.05) * Ry(18*(i-1)) * Ry(18)
          \_______________________/   \___________________/
             save this product          save this product
   }</pre>
   Where {@code Ry} is rotation around the y-axis and {@code Tx} is
   translation in the x-direction. Notice how a new rotation can be
   accumulated on the right end of the matrix product and a new
   translation can be accumulated on the right end of the translation
   product. But we cannot accumulate matrix products in the middle of
   a larger matrix product. So the only way to implement this solution
   is to save each of the rotation and translation products, accumulate
   a new transformation on each saved product, and then multiply the
   two saved products to create the model matrix in the position object.
*/
public class Example_23d
{
   public static void main(String[] args)
   {
      // Set up a orthographic camera.
      final double right  = 5.0;
      final double left   = -1.0;
      final double top    = 2.0;
      final double bottom = -top;
      final Scene scene = new Scene("Example_23d",
                             Camera.projOrtho(left, right, bottom, top));

      // Create a FrameBuffer to render our scene into.
      final int width  = 600;
      final int height = 400;
      final FrameBuffer fb = new FrameBuffer(width, height, Color.black);

      // Create a set of x and y axes.
      final Model axes = new Axes2D(left, right, bottom, top, 12, 8);
      // Color them red.
      ModelShading.setColor(axes, Color.red);
      // Add the axes to the Scene.
      final Position axes_p = new Position(axes);
      scene.addPosition(axes_p);

      // Create a Model of the letter P.
      final P modelP = new P();
      // Color the P blue.
      ModelShading.setColor(modelP, Color.blue);
      // Add the model to the Scene.
      final Position modelP_p = new Position(modelP);
      scene.addPosition(modelP_p);

      Matrix accumulateR = Matrix.identity(); // Use this to accumulate rotations.

      // Translate along the x-axis while rotating around the y-axis.
      for (int i = 0; i <= 100; ++i)
      {
         Matrix saveT = modelP_p.getMatrix(); // Save the translation.

         // Combine the translations and rotations.
         modelP_p.transform( modelP_p.getMatrix().times( accumulateR ) );

         // Render again.
         fb.clearFB();
         Pipeline.render(scene, fb);
         fb.dumpFB2File(String.format("PPM_Example_23d_Frame%03d.ppm", i));

         modelP_p.transform( saveT                              // Undo the rotation,
                     .times( Matrix.translate(0.05, 0, 0) ) );  // and accumulate a translation.
         accumulateR = accumulateR.times( Matrix.rotateY(18) ); // Accumulate a rotation.
      }
   }
}
