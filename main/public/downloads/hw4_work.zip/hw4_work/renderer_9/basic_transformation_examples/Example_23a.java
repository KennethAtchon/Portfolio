/*
 * Renderer 9. The MIT License.
 * Copyright (c) 2022 rlkraft@pnw.edu
 * See LICENSE for details.
*/

import renderer.scene.*;
import renderer.scene.primitives.*;
import renderer.scene.util.ModelShading;
import renderer.models_L.*;
import renderer.pipeline.*;
import renderer.framebuffer.*;

import java.awt.Color;

/**
   Translate the letter {@link P} along the x-axis while
   rotating around the y-axis.
<p>
   See the animation <a href="../Example_23.gif">Example_23.gif</a>.
<p>
   <a href="../Example_23.gif"><img src="../Example_23.gif" alt="Example_23.gif"></a>
 <p>
   This is a harder problem, and this is a wrong way to try to solve
   the problem. This code assumes that rotation around the y-axis
   commutes with translation along the x-axis. But rotations and
   translations only commute when they are along the same axis.
*/
public class Example_23a
{
   public static void main(String[] args)
   {
      // Set up a orthographic camera.
      final double right  = 5.0;
      final double left   = -1.0;
      final double top    = 2.0;
      final double bottom = -top;
      final Scene scene = new Scene("Example_23a",
                             Camera.projOrtho(left, right, bottom, top));

      // Create a FrameBuffer to render our scene into.
      final int width  = 600;
      final int height = 400;
      final FrameBuffer fb = new FrameBuffer(width, height, Color.black);

      // Create a set of x and y axes.
      final Model axes = new Axes2D(left, right, bottom, top, 12, 8);
      // Color them red.
      ModelShading.setColor(axes, Color.red);
      // Add the axes to the Scene.
      final Position axes_p = new Position(axes);
      scene.addPosition(axes_p);

      // Create a Model of the letter P.
      final P modelP = new P();
      // Color the P blue.
      ModelShading.setColor(modelP, Color.blue);
      // Add the model to the Scene.
      final Position modelP_p = new Position(modelP);
      scene.addPosition(modelP_p);

      // Translate along the x-axis while rotating around the y-axis.
      // (This is harder. In fact, this code doesnt work, since it
      // assumes that these rotations and translations commute.)
      for (int i = 0; i <= 100; ++i)
      {
         // Render again.
         fb.clearFB();
         Pipeline.render(scene, fb);
         fb.dumpFB2File(String.format("PPM_Example_23a_Frame%03d.ppm", i));

         // Translate down the x-axis and then rotate around the y-axis.
         // This does not do what we want.
         modelP_p.transform( modelP_p.getMatrix()
                     .times( Matrix.translate(0.05, 0, 0) ) // Accumulate the translation.
                     .times( Matrix.rotateY(18) ) );        // Accumulate the rotation.
      }
   }
}
