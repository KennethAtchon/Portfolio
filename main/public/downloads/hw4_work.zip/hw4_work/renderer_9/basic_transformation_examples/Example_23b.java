/*
 * Renderer 9. The MIT License.
 * Copyright (c) 2022 rlkraft@pnw.edu
 * See LICENSE for details.
*/

import renderer.scene.*;
import renderer.scene.primitives.*;
import renderer.scene.util.ModelShading;
import renderer.models_L.*;
import renderer.pipeline.*;
import renderer.framebuffer.*;

import java.awt.Color;

/**
   Translate the letter {@link P} along the x-axis while
   rotating around the y-axis.
 <p>
   This is another way to solve this problem.
<p>
   For the i'th frame of the animation, the model matrix is
   <pre>{@code
      M = Tx(0.05*i) * Ry(18*i)
   }</pre>
   Where {@code Ry} is rotation around the y-axis and {@code Tx} is
   translation in the x-direction. This solution does not try to
   accumulate matrix products. For each frame of the animation, this
   solution builds the model matrix as the product of a translation
   and a rotation.
*/
public class Example_23b
{
   public static void main(String[] args)
   {
      // Set up a orthographic camera.
      final double right  = 5.0;
      final double left   = -1.0;
      final double top    = 2.0;
      final double bottom = -top;
      final Scene scene = new Scene("Example_23b",
                             Camera.projOrtho(left, right, bottom, top));

      // Create a FrameBuffer to render our scene into.
      final int width  = 600;
      final int height = 400;
      final FrameBuffer fb = new FrameBuffer(width, height, Color.black);

      // Create a set of x and y axes.
      final Model axes = new Axes2D(left, right, bottom, top, 12, 8);
      // Color them red.
      ModelShading.setColor(axes, Color.red);
      // Add the axes to the Scene.
      final Position axes_p = new Position(axes);
      scene.addPosition(axes_p);

      // Create a Model of the letter P.
      final P modelP = new P();
      // Color the P blue.
      ModelShading.setColor(modelP, Color.blue);
      // Add the model to the Scene.
      final Position modelP_p = new Position(modelP);
      scene.addPosition(modelP_p);

      // Translate along the x-axis while rotating around the y-axis.
      for (int i = 0; i <= 100; ++i)
      {
         // Translate down the x-axis and then rotate around the y-axis.
         // The order of these transformations does matter.
         modelP_p.transform( Matrix.translate(i*0.05, 0, 0)
                     .times( Matrix.rotateY(i*18) ) );

         // Render again.
         fb.clearFB();
         Pipeline.render(scene, fb);
         fb.dumpFB2File(String.format("PPM_Example_23b_Frame%03d.ppm", i));
      }
   }
}
