/*
 * Renderer 9. The MIT License.
 * Copyright (c) 2022 rlkraft@pnw.edu
 * See LICENSE for details.
*/

import renderer.scene.*;
import renderer.scene.primitives.*;
import renderer.scene.util.ModelShading;
import renderer.models_L.*;
import renderer.pipeline.*;
import renderer.framebuffer.*;

import java.awt.Color;

/**
   Rotate the unit square around its lower left-hand corner
   placed on the circumference of the unit circle.
<p>
   See the animation <a href="../Example_15.gif">Example_15.gif</a>.
<p>
   <a href="../Example_15.gif"><img src="../Example_15.gif" alt="Example_15.gif"></a>
<p>
   For the i'th frame of the animation, the square's model matrix is
   <pre>{@code
      M = Rz(5*i) * T(1, 0, 0)
        = Rz(5) * Rz(5*(i-1)) * T(1, 0, 0).
   }</pre>
   Notice how new rotations can be accumulated on the left end of the
   matrix product. Also notice that, compared to the previous example,
   the translation matrix has been moved from the left end of the product
   to the right end. Having the translation on the right and accumulating
   the rotations on the left make this example a bit more complicated
   than the previous example.
<p>
   Let us analyze how we use matrix transformations to implement
   this animation.
<p>
   Let {@code M} denote the model matrix for the square. Initially,
   {@code M} is the identity matrix.
   <pre>{@code
               M = [ 1  0  0  0 ]
                   [ 0  1  0  0 ]
                   [ 0  0  1  0 ]
                   [ 0  0  0  1 ]
   }</pre>
<p>
   Let {@code Rz(a)} denote the 4x4 homogeneous matrix that rotates the
   xy-plane around the z-axis by angle {@code a} degrees counter-clockwise.
   <pre>{@code
           Rz(a) = [ cos(a * (pi/180))   -sin(a * (pi/180))   0   0 ]
                   [ sin(a * (pi/180))    cos(a * (pi/180))   0   0 ]
                   [       0                    0             1   0 ]
                   [       0                    0             0   1 ]
   }</pre>
<p>
   Let {@code T(a,b,c)} denote the 4x4 homogeneous matrix that translate by
   the amount {@code a} in the x-direction, the amount {@code b} in the
   y-direction, and the amount {@code c} in the z-direction.
   <pre>{@code
        T(a,b,c) = [ 1  0  0  a ]
                   [ 0  1  0  b ]
                   [ 0  0  1  c ]
                   [ 0  0  0  1 ]
   }</pre>
<p>
   To create the first frame of the animation, we want the square's model
   matrix to translate the square one unit to the right.
   <pre>{@code
       M = T(1, 0, 0)
   }</pre>
<p>
   To create the second frame of the animation, we want the square's model
   matrix to translate the square one unti to the right and then rotate by
   5 degrees.
   <pre>{@code
       M = Rz(5) * T(1, 0, 0)
   }</pre>
   Notice how the rotation matrix is on the left of the translation matrix.
   We want each vertex of the square model to be first translated and then
   rotated. That is, if {@code v} is a vertex from the square model we want
   <pre>{@code
      M * v = Rz(5) * T(1, 0, 0) * v
   }</pre>
<p>
   For the third frame of the animation, we want the square's model matrix
   to first translate and then rotate by 10 degree.
   <pre>{@code
       M = Rz(5) * Rz(5) * T(1, 0, 0)
         = Rz(10) * T(1, 0, 0)
   }</pre>
   Notice again that the rotation matrix is multiplied on the left.
<p>
   For the {@code i}'th frame of the animation we want the square's model
   matrix to first translate and then rotate by {@code 5*1} degrees.
   <pre>{@code
       M = Rz(5*i) * T(1, 0, 0)
   }</pre>
   Notice how the rotations are accumulating on the left of the square's
   model matrix. This might make you think that the loop for this animation
   would look like this.
   <pre>{@code
      for (int i = 0; i <= 72; ++i)
      {
         square_p.setMatrix( Matrix.identity() );
         square_p.getMatrix().mult( Matix.translate(1, 0, 0) );
         square_p.getMatrix().mult( Matix.rotateZ(5*i) );

         fb.clearFB(Color.darkGray);
         Pipeline.render(scene, fb);
         fb.dumpFB2File(String.format("PPM_Example_10a_Frame%03d.ppm", i));
      }
   }</pre>
   This code seems to say, "set the model matrix to the identity matrix,
   then translate, then rotate". But let us read the code very carefully.
   The first line in the body of the loop.
   <pre>{@code
      square_p.setMatrix( Matrix.identity() );
   }</pre>
   means
   <pre>{@code
      M = I
   }</pre>
   Recall that the second line of code
   <pre>{@code
      square_p.getMatrix().mult( Matix.translate(1, 0, 0) );
   }</pre>
   means the following formula (with the translation matrix multiplied on
   the right).
   <pre>{@code
      M = M * T(1, 0, 0)
        = I * T(1, 0, 0)
        = T(1, 0, 0)
   }</pre>
   The next line of code,
   <pre>{@code
      square_p.getMatrix().mult( Matix.rotateZ(5*i) );
   }</pre>
   then means (with the rotation matrix multiplied on the right)
   <pre>{@code
      M = M * Rz(5*i)
        = T(1, 0, 0) * Rz(5*i)
   }</pre>
   But this is the opposite of what we want. Above we said that the
   model matrix should translate then rotate (when we read the formula
   from right-to-left), which has the formula
   <pre>{@code
      M = Rz(5*i) * T(1, 0, 0)
   }</pre>
   Here is what the loop for creating the animation should look like.
   <pre>{@code
      for (int i = 0; i <= 72; i++)
      {
         square_p.setMatrix( Matrix.identity() );
         square_p.getMatrix().mult( Matix.rotateZ(5*i) );
         square_p.getMatrix().mult( Matix.translate(1, 0, 0) );

         fb.clearFB(Color.darkGray);
         Pipeline.render(scene, fb);
         fb.dumpFB2File(String.format("PPM_Example_10a_Frame%03d.ppm", i));
      }
   }</pre>
   If you read the code "backwards", from the bottom up, it says "translate
   and then rotate", which is what we want (when we read the formula from
   right-to-left). But if you read the code forwards, from the top down, it
   seems to say "rotate then translate". There is a way to make sense of
   both of these ways of reading the code and the second way of reading the
   code, from the top down, is actually the preferred way to read it once
   you understand how to interpret it.
<p>
   We know that the code
   <pre>{@code
      square_p.setMatrix( Matrix.identity() );
      square_p.getMatrix().mult( Matix.rotateZ(5*i) );
      square_p.getMatrix().mult( Matix.translate(1, 0, 0) );
   }</pre>
   creates the following model matrix because of the rule about multiplying
   matrices on the right.
   <pre>{@code
      M = I * Rz(5*i) * T(1, 0, 0)
   }</pre>
   Notice how, if you read the code from the bottom up, you are reading
   the formula from right-to-left. But if you read the code from the top
   down, you are reading the formula from left-to-right. Let {@code v} be
   a vertex from the square model. When we apply the model matrix to the
   vertex, we get this formula,
   <pre>{@code
      M * v = I * Rz(5*i) * T(1, 0, 0) * v
            = Rz(5*i) * ( T(1, 0, 0) * v )
   }</pre>
   which says that the vertex is first multiplied by the translation, then
   the result of the translation is multiplied by the rotation. In other
   words, "translate then rotate". So the "bottom up" (or right-to-left)
   way of reading the code tells us what the code does to each vertex.
<p>
   Here is how to read the code from the top down (or, how to read the
   formula from left-to-right). When read from the top down, we interpret
   each transformation as transforming the coordinate system. So
   <pre>{@code
      square_p.getMatrix().mult( Matix.rotateZ(5*i) );
   }</pre>
   means rotate the coordinate system {@code 5i} degrees. And
   <pre>{@code
      square_p.getMatrix().mult( Matix.translate(1, 0, 0) );
   }</pre>
   means, translate the <em>rotated</em> coordinate system. And then the
   vertices of the square get plotted in the translated version of the
   rotated coordinate system.
<p>
   Here is the scene tree that this program builds for the i'th frame
   of the animation. There is only one Matrix object in the scene. All
   of the transformation information needs to be in that single matrix.
   <pre>{@code
             Scene
            /     \
           /       \
      Camera       List<Position>
                         |
                         |
                      Position
                      /      \
                     /        \
                Matrix         Square
            Rz(5i)*T(1,0)
   }</pre>
<p>
   (The code below does show a way to "force" the matrix
   multiplcation to be on the left of the position's matrix.)
*/
public class Example_15a
{
   public static void main(String[] args)
   {
      // Since this is a 2D example, we can use an orthographic camera.
      final double right  = 2.0;
      final double left   = -right;
      final double top    = right;
      final double bottom = -top;
      final Scene scene = new Scene("Example_15a",
                                 Camera.projOrtho(left, right, bottom, top));

      // Create a FrameBuffer to render our scene into.
      final int width  = 512;
      final int height = 512;
      final FrameBuffer fb = new FrameBuffer(width, height, Color.black);

      // Create a set of x and y axes.
      final Model axes = new Axes2D(-2, +2, -2, +2, 8, 8);
      ModelShading.setColor(axes, Color.red);
      final Position axes_p = new Position(axes);
      scene.addPosition(axes_p);

      // Add a square to the Scene.
      final Model square = new Square("Example_15a");
      final Position square_p = new Position(square);
      scene.addPosition(square_p);

      // Rotate the square around its lower left-hand corner
      // placed on the circumference of the unit circle.
      for (int i = 0; i < 72; ++i)
      {
         // Rotate the coordinate system and then
         // translate the square's lower left-hand corner to the point (1,0).
         square_p.transform( Matrix.rotateZ(5*i)
                     .times( Matrix.translate(1, 0, 0) ) );

         // Render again.
         fb.clearFB();
         Pipeline.render(scene, fb);
         fb.dumpFB2File(String.format("PPM_Example_15a_Frame%03d.ppm", i));
      }
   }
}
