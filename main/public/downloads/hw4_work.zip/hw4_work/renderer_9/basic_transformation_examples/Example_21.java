/*
 * Renderer 9. The MIT License.
 * Copyright (c) 2022 rlkraft@pnw.edu
 * See LICENSE for details.
*/

import renderer.scene.*;
import renderer.scene.primitives.*;
import renderer.scene.util.ModelShading;
import renderer.models_L.*;
import renderer.pipeline.*;
import renderer.framebuffer.*;

import java.awt.Color;

/**
   Translate the letter {@link P} along the y-axis while
   rotating around the y-axis.
<p>
   See the animation <a href="../Example_21.gif">Example_21.gif</a>.
<p>
   <a href="../Example_21.gif"><img src="../Example_21.gif" alt="Example_21.gif"></a>
<p>
   For the i'th frame of the animation, the model matrix is
   <pre>{@code
      M = Ty(0.05*i) * Ry(18*i)
        = Ty(0.05) * Ty(0.05*(i-1)) * Ry(18*(i-1)) * Ry(18)
   }</pre>
   Where {@code Ry} is rotation around the y-axis and {@code Ty} is
   translation in the y-direction. Notice how new rotations can be
   accumulated on the right end of the matrix product and new
   translations can be accumulated on the left end of the product.
<p>
   When we are rotate and translate along the same axis, the rotation
   and translation matrices commute with each other. That is,
   <pre>{@code
      Ry(18) * Ty(0.05) = Ty(0.05) * Ry(18)
   }</pre>
   So in this case, it doesn't matter in what order we do the rotations
   and translations. We could put all the translations on the right and
   all the rotations on the left.
   <pre>{@code
      M = Ry(18*i) * Ty(0.05*i)
        = Ry(18) * Ry(18*(i-1)) * Ty(0.05*(i-1)) * Ty(0.05)
   }</pre>
   Or we could alternate a rotation with a translation.
   <pre>{@code
      M = Ry(18) * Ty(0.05) * Ry(18) * Ty(0.05) * ... * Ry(18) * Ty(0.05)
          \_____________________________________________________________/
                            i products of Ry(18) * Ty(0.05)
   }</pre>
   This last matrix product is easy to implement. For each new animation
   frame we accumulate one new rotation and one new translation on the
   right of the model matrix in the position object.
*/
public class Example_21
{
   public static void main(String[] args)
   {
      // Set up an orthographic camera.
      final double right  = 2.0;
      final double left   = -right;
      final double top    = 5.0;
      final double bottom = -1.0;
      final Scene scene = new Scene("Example_21",
                             Camera.projOrtho(left, right, bottom, top));

      // Create a FrameBuffer to render our scene into.
      final int width  = 400;
      final int height = 600;
      final FrameBuffer fb = new FrameBuffer(width, height, Color.black);

      // Create a set of x and y axes.
      final Model axes = new Axes2D(left, right, bottom, top, 8, 12);
      // Color them red.
      ModelShading.setColor(axes, Color.red);
      // Add the axes to the Scene.
      final Position axes_p = new Position(axes);
      scene.addPosition(axes_p);

      // Create a Model of the letter P.
      final P modelP = new P();
      // Color the P blue.
      ModelShading.setColor(modelP, Color.blue);
      // Add the model to the Scene.
      final Position modelP_p = new Position(modelP);
      scene.addPosition(modelP_p);

      // Translate along the y-axis while rotating around the y-axis.
      // (This is deceptively easy.)
      for (int i = 0; i <= 100; ++i)
      {
         // Render again.
         fb.clearFB();
         Pipeline.render(scene, fb);
         fb.dumpFB2File(String.format("PPM_Example_21_Frame%03d.ppm", i));

         // Translate up the y-axis and rotate around the y-axis.
         // The order of these transformations does not matter.
         modelP_p.transform( modelP_p.getMatrix()
                                 .times( Matrix.translate(0, 0.05, 0) ) // Accumulate the translation.
                                 .times( Matrix.rotateY(18) ) );        // Accumulate the rotation.
      }
   }
}
