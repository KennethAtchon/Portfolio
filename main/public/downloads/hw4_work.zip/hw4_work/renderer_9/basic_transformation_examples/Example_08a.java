/*
 * Renderer 9. The MIT License.
 * Copyright (c) 2022 rlkraft@pnw.edu
 * See LICENSE for details.
*/

import renderer.scene.*;
import renderer.scene.primitives.*;
import renderer.scene.util.ModelShading;
import renderer.models_L.*;
import renderer.pipeline.*;
import renderer.framebuffer.*;

import java.awt.Color;

/**
   Rotate the unit square around the point (3/4, 3/4) in the
   square's model coordinate system, but with the center of
   rotation at the point (1/4, 1/4) in the world coordinate
   system.
<p>
   See the animation <a href="../Example_08.gif">Example_08.gif</a>.
<p>
   <a href="../Example_08.gif"><img src="../Example_08.gif" alt="Example_08.gif"></a>
<p>
   For the i'th frame of the animation, the square's model matrix is
   <pre>{@code
      M = T(1/4, 1/4, 0) * Rz(5*i) * T(-3/4, -3/4, 0).
   }</pre>
   Notice how new rotations are being accumulated between two translations.
<p>
   In general, if we want to rotate the unit square around the point (a, b)
   in the square's model coordinate system, but with the center of rotation
   at the point (c, d) in the world coordinate system, then in the i'th
   frame of the animation, the square's model matrix is
   <pre>{@code
      M = T(c, d, 0) * Rz(5*i) * T(-a, -b, 0)
   }</pre>
*/
public class Example_08a
{
   public static void main(String[] args)
   {
      // Since this is a 2D example, we can use an orthographic camera.
      final double right  = 2.0;
      final double left   = -right;
      final double top    = right;
      final double bottom = -top;
      final Scene scene = new Scene("Example_08a",
                                 Camera.projOrtho(left, right, bottom, top));

      // Create a FrameBuffer to render our scene into.
      final int width  = 512;
      final int height = 512;
      final FrameBuffer fb = new FrameBuffer(width, height, Color.black);

      // Create a set of x and y axes.
      final Model axes = new Axes2D(-2, +2, -2, +2, 8, 8);
      ModelShading.setColor(axes, Color.red);
      final Position axes_p = new Position(axes);
      scene.addPosition(axes_p);

      // Add a square to the Scene.
      final Model square = new Square("Example_08a");
      final Position square_p = new Position(square);
      scene.addPosition(square_p);

      // Rotate the square around the point (3/4, 3/4) in the
      // square's model coordinate system, but with the center
      // of rotation at the point (1/4, 1/4) in the world
      // coordinate system.
      for (int i = 0; i < 72; ++i)
      {
         // Rotate the square.
         square_p.transform( Matrix.translate(0.25, 0.25, 0)
                     .times( Matrix.rotateZ(5*i) )
                     .times( Matrix.translate(-0.75, -0.75, 0) ) );

         // Render again.
         fb.clearFB();
         Pipeline.render(scene, fb);
         fb.dumpFB2File(String.format("PPM_Example_08a_Frame%03d.ppm", i));
      }
   }
}
