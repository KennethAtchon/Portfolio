/*

*/

import renderer.scene.*;
import renderer.models_L.Disk;
import renderer.pipeline.*;
import renderer.framebuffer.*;

import java.awt.Color;

/**
   Distort the source image if either the width or height of the
   framebuffer is < SIZE (the initial size for the framebuffer).

   Letterbox the source image, without scaling, if either the width
   or height of the framebuffer is > SIZE. The maximum dimension
   of the viewport is SIZE (the initial size for the framebuffer).

   This has the affect of "squeezing" the source image when
   the width or height of the frambuffer is smaller than SIZE.
*/
@SuppressWarnings("serial")
public class Circle_Puzzle_4 extends Circle_Abstract
{
   /**
      This constructor instantiates the Scene object
      and initializes it with appropriate geometry.
      Then this constructor instantiates the GUI.
   */
   public Circle_Puzzle_4()
   {
      super("Renderer 7 - Circle Puzzle 4");
      print_help_message();
   }


   /**
      Get in one place the code to set up the viewport and the view volume.
   */
   @Override protected void setupViewing()
   {
      // Get the size of the FrameBuffer.
      final FrameBuffer fb = fbp.getFrameBuffer();
      final int wFB = fb.width;
      final int hFB = fb.height;

      final int wVP = Math.min(512, wFB);
      final int hVP = Math.min(512, hFB);

      final int hOffset = (wVP < wFB) ? (wFB - wVP) / 2 : 0;
      final int vOffset = (hVP < hFB) ? (hFB - hVP) / 2 : 0;

      // If the framebuffer strictly smaller than SIZE x SIZE,
      // then distort the source image to fill the framebuffer.
      // If the framebuffer is strictly larger than SIZE x SIZE,
      // then letterbox a square viewport within the framebuffer.
      // Otherwise, letterbox the viewport, with maximum dimension
      // of SIZE, and distort the source image into the viewport.
      if (mode == 1)
      {
         // 1. upper left-hand corner
         fb.setViewport(0, 0, wVP, hVP);
      }
      else if (mode == 2)
      {
         // 2. center of the top edge
         fb.setViewport(hOffset, 0, wVP, hVP);
      }
      else if (mode == 3)
      {
         // 3. upper right-hand corner
         fb.setViewport(wFB - wVP, 0, wVP, hVP);
      }
      else if (mode == 4)
      {
         // 4. center of the right edge
         fb.setViewport(wFB - wVP, vOffset, wVP, hVP);
      }
      else if (mode == 5)
      {
         // 5. lower right-hand corner
         fb.setViewport(wFB - wVP, hFB - hVP, wVP, hVP);
      }
      else if (mode == 6)
      {
         // 6. center of the bottom edge
         fb.setViewport(hOffset, hFB - hVP, wVP, hVP);
      }
      else if (mode == 7)
      {
         // 7. lower left-hand corner
         fb.setViewport(0, hFB - hVP, wVP, hVP);
      }
      else if (mode == 8)
      {
         // 8. center of the left edge
         fb.setViewport(0, vOffset, wVP, hVP);
      }
      else if (mode == 9)
      {
         // 9. center of the framebuffer
         fb.setViewport(hOffset, vOffset, wVP, hVP);
      }

      super.setupViewing();
   }


   /**
      Create an instance of this class which has
      the affect of creating the GUI application.
   */
   public static void main(String[] args)
   {
      // We need to call the program's constructor in the
      // Java GUI Event Dispatch Thread, otherwise we get a
      // race condition between the constructor (running in
      // the main() thread) and the very first ComponentEvent
      // (running in the EDT).
      javax.swing.SwingUtilities.invokeLater(
         () -> new Circle_Puzzle_4()
      );
   }
}
