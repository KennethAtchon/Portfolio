/*

*/

import renderer.scene.*;
import renderer.models_L.Disk;
import renderer.pipeline.*;
import renderer.framebuffer.*;

import java.awt.Color;

/**
   Crop the source image if either the width or height of the
   framebuffer is < SIZE (the initial size for the framebuffer).

   Letterbox the source image, without scaling, if either the width
   or height of the framebuffer is > SIZE (the initial size for the
   framebuffer).

   This has the affect of "gluing" the source image to
   a spot on the framebuffer.
*/
@SuppressWarnings("serial")
public class Circle_Puzzle_2_weird extends Circle_Abstract
{
   /**
      This constructor instantiates the Scene object
      and initializes it with appropriate geometry.
      Then this constructor instantiates the GUI.
   */
   public Circle_Puzzle_2_weird()
   {
      super("Renderer 7 - Circle Puzzle 2_weird");
      print_help_message();
   }


   /**
      Get in one place the code to set up the viewport and the view volume.
   */
   @Override protected void setupViewing()
   {
      // Get the size of the FrameBuffer.
      final FrameBuffer fb = fbp.getFrameBuffer();
      final int wFB = fb.width;
      final int hFB = fb.height;

      // Set the size of the viewport. (SIZE is
      // the initial size of the framebuffer.)
      final int wVP = Math.min(SIZE, wFB);
      final int hVP = Math.min(SIZE, hFB);

      // Compute a displacement for the viewport within the framebuffer.
      final int hOffset = (wVP < wFB) ? (wFB - wVP) / 2 : 0;
      final int vOffset = (hVP < hFB) ? (hFB - hVP) / 2 : 0;

      // When the framebuffer is smaller than SIZE x SIZE,
      // compute the width and height of the largest possible
      // sub-rectangle of the unit square,
      //     -1 <= x <= 1, -1 <= y <= 1,
      // with the same aspect ratio as the viewport, wVP/hVP.
      final double w;
      final double h;
      // Compute the view rectangle's width and height.
      if (wFB >= SIZE || hFB >= SIZE)
      {
         w = 2.0;
         h = 2.0;
      }
      else
      {
         if ( (double)wVP / (double)hVP >= 1 )
         {
            w = 2.0;                 //  w/h = wVP/hVP
            h = (2.0 * hVP) / wVP;
         }
         else
         {
            w = (2.0 * wVP) / hVP;  //  w/h = wVP/hVP
            h = 2.0;
         }
      }

      // If the framebuffer is smaller than SIZE x SIZE, then
      // crop the view rectangle to match the framebuffer.
      // If the framebuffer is larger than SIZE x SIZE, then
      // letterbox the viewport within the framebuffer.
      if (mode == 1)
      {
         // 1. upper left-hand corner
         fb.setViewport(0, 0, wVP, hVP);
         scene = scene.changeCamera(
                     Camera.projOrtho(
                             -1.0,     // left
                             -1.0 + w, // right
                              1.0 - h, // bottom
                              1.0));   // top
      }
      else if (mode == 2)
      {
         // 2. center of the top edge
         fb.setViewport(hOffset, 0, wVP, hVP);
         scene = scene.changeCamera(
                     Camera.projOrtho(
                             -w / 2.0, // left
                              w / 2.0, // right
                              1.0 - h, // bottom
                              1.0));   // top
      }
      else if (mode == 3)
      {
         // 3. upper right-hand corner
         fb.setViewport(wFB - wVP, 0, wVP, hVP);
         scene = scene.changeCamera(
                     Camera.projOrtho(
                              1.0 - w, // left
                              1.0,     // right
                              1.0 - h, // bottom
                              1.0));   // top
      }
      else if (mode == 4)
      {
         // 4. center of the right edge
         fb.setViewport(wFB - wVP, vOffset, wVP, hVP);
         scene = scene.changeCamera(
                     Camera.projOrtho(
                              1.0 - w,   // left
                              1.0,       // right
                             -h / 2.0,   // bottom
                              h / 2.0)); // top
      }
      else if (mode == 5)
      {
         // 5. lower right-hand corner
         fb.setViewport(wFB - wVP, hFB - hVP, wVP, hVP);
         scene = scene.changeCamera(
                     Camera.projOrtho(
                              1.0 - w,   // left
                              1.0,       // right
                             -1.0,       // bottom
                             -1.0 + h)); // top
      }
      else if (mode == 6)
      {
         // 6. center of the bottom edge
         fb.setViewport(hOffset, hFB - hVP, wVP, hVP);
         scene = scene.changeCamera(
                     Camera.projOrtho(
                             -w / 2.0,   // left
                              w / 2.0,   // right
                             -1.0,       // bottom
                             -1.0 + h)); // top
      }
      else if (mode == 7)
      {
         // 7. lower left-hand corner
         fb.setViewport(0, hFB - hVP, wVP, hVP);
         scene = scene.changeCamera(
                     Camera.projOrtho(
                             -1.0,       // left
                             -1.0 + w,   // right
                             -1.0,       // bottom
                             -1.0 + h)); // top
      }
      else if (mode == 8)
      {
         // 8. center of the left edge
         fb.setViewport(0, vOffset, wVP, hVP);
         scene = scene.changeCamera(
                     Camera.projOrtho(
                             -1.0,       // left
                             -1.0 + w,   // right
                             -h / 2.0,   // bottom
                              h / 2.0)); // top
      }
      else if (mode == 9)
      {
         // 9. center of the framebuffer
         fb.setViewport(hOffset, vOffset, wVP, hVP);
         scene = scene.changeCamera(
                     Camera.projOrtho(
                             -w / 2.0,   // left
                              w / 2.0,   // right
                             -h / 2.0,   // bottom
                              h / 2.0)); // top
      }

      super.setupViewing();
   }


   /**
      Create an instance of this class which has
      the affect of creating the GUI application.
   */
   public static void main(String[] args)
   {
      // We need to call the program's constructor in the
      // Java GUI Event Dispatch Thread, otherwise we get a
      // race condition between the constructor (running in
      // the main() thread) and the very first ComponentEvent
      // (running in the EDT).
      javax.swing.SwingUtilities.invokeLater(
         () -> new Circle_Puzzle_2_weird()
      );
   }
}
