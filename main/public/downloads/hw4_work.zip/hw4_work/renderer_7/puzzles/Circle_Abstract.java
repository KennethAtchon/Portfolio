/*

*/

import renderer.scene.*;
import renderer.scene.util.ModelShading;
import renderer.models_L.Disk;
import renderer.pipeline.*;
import renderer.framebuffer.*;

import java.awt.Color;
import javax.swing.JFrame;
import java.awt.BorderLayout;
import java.awt.event.KeyListener;
import java.awt.event.KeyEvent;
import java.awt.event.ComponentListener;
import java.awt.event.ComponentEvent;
import javax.swing.Timer;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

/**
   This abstract class sets up the basic geometry, the GUI,
   and the event handlers.
   <p>
   Subclasses should override the {@code setupViewing()} method
   and use that method to define the camera's view volume and
   the framebuffer's viewport.
   <p>
   This class sets the view volume and the viewport so that the
   standard view volume is distorted onto the whole framebuffer.
*/
@SuppressWarnings("serial")
public abstract class Circle_Abstract extends JFrame
       implements KeyListener, ComponentListener, ActionListener
{
   protected final int SIZE = 512;

   protected boolean show_Camera = false;
   protected boolean show_FB_AspectRatio = false;
   protected int mode = 1;

   protected Scene scene;
   protected final FrameBufferPanel fbp;

   protected Position modelToRotate = null;
   protected final Timer timer;

   /**
      This constructor instantiates the Scene object
      and initializes it with appropriate geometry.
      Then this constructor instantiates the GUI.
   */
   protected Circle_Abstract(String title)
   {
      super(title);

      // Create the Scene object that we shall render.
      scene = new Scene( Camera.projOrtho() );

      // Create a model of a circle.
      final Model model = new Disk(1.0, 10, 40);
      final Position position = new Position(model);
      modelToRotate = position;
      ModelShading.setRandomColor(model);
      // Add the Model to the Scene.
      scene.addPosition(position);


      // Create a FrameBufferPanel that holds a FrameBuffer.
      final int width  = SIZE;
      final int height = SIZE;
      fbp = new FrameBufferPanel(width, height);
      fbp.getFrameBuffer().setBackgroundColorFB(Color.darkGray);
      fbp.getFrameBuffer().getViewport().setBackgroundColorVP(Color.black);

      this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

      // Place the FrameBufferPanel in this JFrame.
      this.getContentPane().add(fbp, BorderLayout.CENTER);
      this.pack();
      this.setLocationRelativeTo(null);
      this.setVisible(true);

      // Create event handler objects for events from this JFrame.
      this.addKeyListener(this);
      this.addComponentListener(this);

      // Create a Timer object that will generate ActionEvent
      // objects for the ActionListener handler to respond to.
      final int fps = 30;
      timer = new Timer(1000/fps, this);
      timer.start();
   }


   /**
      Get in one place the code to set up the viewport and the view volume.
   */
   protected void setupViewing()
   {
      // Render again.
      final FrameBuffer fb = fbp.getFrameBuffer();
      fb.clearFB();
      fb.vp.clearVP();
      Pipeline.render(scene, fb);
      fbp.repaint();
   }


   // Implement the KeyListener interface.
   @Override public void keyPressed(KeyEvent e){}
   @Override public void keyReleased(KeyEvent e){}
   @Override public void keyTyped(KeyEvent e)
   {
      //System.out.println( e );

      final char c = e.getKeyChar();
      if ('h' == c)
      {
         print_help_message();
         return;
      }
      else if ('d' == c)
      {
         final Position p = scene.getPosition(0);
         p.debug = ! p.debug;
         Clip.debug = p.debug;
      }
      else if ('D' == c)
      {
         Rasterize.debug = ! Rasterize.debug;
      }
      else if ('a' == c)
      {
         Rasterize.doAntiAliasing = ! Rasterize.doAntiAliasing;
         System.out.print("Anti-aliasing is turned ");
         System.out.println(Rasterize.doAntiAliasing ? "On" : "Off");
      }
      else if ('g' == c)
      {
         Rasterize.doGamma = ! Rasterize.doGamma;
         System.out.print("Gamma correction is turned ");
         System.out.println(Rasterize.doGamma ? "On" : "Off");
      }
      else if ('m'==c || 'M' == c)
      {
         show_Camera = ! show_Camera;
         if (show_Camera)
         {
            System.out.print( scene.camera );
         }
      }
      else if ('f' == c)
      {
         show_FB_AspectRatio = ! show_FB_AspectRatio;
         if (show_FB_AspectRatio)
         {
            // Get the new size of the FrameBufferPanel.
            final int w = fbp.getWidth();
            final int h = fbp.getHeight();
            System.out.printf(
              "Aspect ratio (of framebuffer) = %.2f\n", (double)w/(double)h);
         }
      }
      else if ('c' == c)
      {
         // Change the solid random color of the disk.
         ModelShading.setRandomColor(scene.getPosition(0).getModel());
      }
      else if ('C' == c)
      {
         // Change each color in the disk to a random color.
         ModelShading.setRandomColors(scene.getPosition(0).getModel());
      }
      else if ('e' == c && e.isAltDown())
      {
         // Change the random color of each vertex of the disk.
         ModelShading.setRandomVertexColors(scene.getPosition(0).getModel());
      }
      else if ('e' == c)
      {
         // Change the solid random color of each edge of the disk.
         ModelShading.setRandomPrimitiveColors(scene.getPosition(0).getModel());
      }
      else if ('E' == c)
      {
         // Change the random color of each end of each edge of the disk.
         ModelShading.setRainbowPrimitiveColors(scene.getPosition(0).getModel());
      }
      else if ('s' == c)
      {
         // Stop the rotation.
         timer.stop();
      }
      else if ('S' == c)
      {
         // Start the rotation.
         timer.start();
      }
      else if ('1' == c)
      {
         mode = 1;
      }
      else if ('2' == c)
      {
         mode = 2;
      }
      else if ('3' == c)
      {
         mode = 3;
      }
      else if ('4' == c)
      {
         mode = 4;
      }
      else if ('5' == c)
      {
         mode = 5;
      }
      else if ('6' == c)
      {
         mode = 6;
      }
      else if ('7' == c)
      {
         mode = 7;
      }
      else if ('8' == c)
      {
         mode = 8;
      }
      else if ('9' == c)
      {
         mode = 9;
      }

      setupViewing();
   }


   // Implement the ComponentListener interface.
   @Override public void componentMoved(ComponentEvent e){}
   @Override public void componentHidden(ComponentEvent e){}
   @Override public void componentShown(ComponentEvent e){}
   @Override public void componentResized(ComponentEvent e)
   {
    //System.out.println( e );

      // Get the new size of the FrameBufferPanel.
      final int wFB = fbp.getWidth();
      final int hFB = fbp.getHeight();

      if (show_FB_AspectRatio)
      {
         System.out.printf(
           "Aspect ratio (of framebuffer) = %.2f\n", (double)wFB/(double)hFB);
      }

      if (show_Camera)
      {
         System.out.print( scene.camera );
      }

      if (0 == hFB) return; // there is no window to draw

      // Create a new FrameBuffer that fits the FrameBufferPanel.
      final Color bg1 = fbp.getFrameBuffer().getBackgroundColorFB();
      final Color bg2 = fbp.getFrameBuffer().getViewport()
                                            .getBackgroundColorVP();
      final FrameBuffer fb = new FrameBuffer(wFB, hFB, bg1);
      fb.vp.setBackgroundColorVP(bg2);
      fbp.setFrameBuffer(fb);

      setupViewing();
   }


   // Implement the ActionListener interface (for the timer).
   @Override public void actionPerformed(ActionEvent e)
   {
      rotateModel(modelToRotate, 10); // 10 degrees
      setupViewing();
   }


   protected void rotateModel(final Position p,
                              final double angle) // angle in degrees
   {
      final Model m = p.getModel();

      final double angleRad = angle * Math.PI / 180.0; // convert to radians

      for (int i = 0; i < m.vertexList.size(); ++i)
      {
         final Vertex v = m.vertexList.get(i);
         m.vertexList.set(i, new Vertex(
                               v.x * Math.cos(angleRad) - v.y * Math.sin(angleRad),
                               v.x * Math.sin(angleRad) + v.y * Math.cos(angleRad),
                               v.z));
      }
   }


   protected void print_help_message()
   {
      System.out.println("Use the 'd/D' key to toggle debugging information on and off.");
      System.out.println("Use the 'a' key to toggle anti-aliasing on and off.");
      System.out.println("Use the 'g' key to toggle gamma correction on and off.");
      System.out.println("Use the 'f' key to toggle showing framebuffer aspect ratio.");
      System.out.println("Use the 'm' key to toggle showing the Camera data.");
      System.out.println("Use the 's/S' key to stop/Start the rotation.");
      System.out.println("Use the '1' through '9' keys to choose a letterbox/crop/window mode.");
      System.out.println("Use the 'h' key to redisplay this help message.");
   }
}
