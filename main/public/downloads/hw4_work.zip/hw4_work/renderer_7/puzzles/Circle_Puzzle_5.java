/*

*/

import renderer.scene.*;
import renderer.models_L.Disk;
import renderer.pipeline.*;
import renderer.framebuffer.*;

import java.awt.Color;

/**
   If BOTH the width and height of the framebuffer are < SIZE,
   then distort the source image to fill the framebuffer.

   If BOTH the width and height of the framebuffer are > SIZE,
   then scale the source image to fill the longer edge of the
   framebuffer and crop the source image on the shorter edge
   of the framebuffer. Maintain the aspect ratio of the source
   image.

   Otherwise, ???.

   The viewport is always the whole framebuffer.
*/
@SuppressWarnings("serial")
public class Circle_Puzzle_5 extends Circle_Abstract
{
   /**
      This constructor instantiates the Scene object
      and initializes it with appropriate geometry.
      Then this constructor instantiates the GUI.
   */
   public Circle_Puzzle_5()
   {
      super("Renderer 6: Circle Puzzle 5");
      print_help_message();
   }


   /**
      Get in one place the code to set up the viewport and the view volume.
   */
   @Override protected void setupViewing()
   {
      // Get the size of the FrameBuffer.
      final FrameBuffer fb = fbp.getFrameBuffer();
      final int wFB = fb.width;
      final int hFB = fb.height;

      // The viewport is the whole framebuffer.
      fb.setViewport(0, 0, wFB, hFB);

      // If the framebuffer is strictly smaller than SIZE x SIZE,
      // then distort the source image to fill the framebuffer.
      // If the framebuffer is strictly larger than SIZE x SIZE,
      // then scale the source image along the longer edge of the
      // framebuffer and crop the source image along the shorter
      // edge of the framebuffer.
      // Otherwise, ...
      final double w;
      final double h;
      if (wFB <= SIZE && hFB <= SIZE)
      {
         w = 2.0;
         h = 2.0;
      }
      else if (wFB > SIZE && hFB > SIZE)
      {
         if (wFB >= hFB) // aspect ratio >= 1
         {
            w = 2.0;
            h = 2.0 * ((double)hFB / (double)wFB);
         }
         else // aspect ratio < 1
         {
            w = 2.0 * ((double)wFB / (double)hFB);
            h = 2.0;
         }
      }
      else if (wFB > SIZE && hFB <= SIZE)
      {
         w = 2.0;
         h = 2.0 * (1.0 + ((double)hFB)*(SIZE - wFB)/(wFB*SIZE));
      }
      else//if (wFB <= SIZE && hFB > SIZE)
      {
         w = 2.0 * (1.0 + ((double)wFB)*(SIZE - hFB)/(hFB*SIZE));
         h = 2.0;
      }

      if (mode == 1)
      {
         // 1. upper left-hand corner
         scene = scene.changeCamera(
                     Camera.projOrtho(
                             -1.0,     // left
                             -1.0 + w, // right
                              1.0 - h, // bottom
                              1.0));   // top
      }
      else if (mode == 2)
      {
         // 2. center of the top edge
         scene = scene.changeCamera(
                     Camera.projOrtho(
                             -w / 2.0, // left
                              w / 2.0, // right
                              1.0 - h, // bottom
                              1.0));   // top
      }
      else if (mode == 3)
      {
         // 3. upper right-hand corner
         scene = scene.changeCamera(
                     Camera.projOrtho(
                              1.0 - w, // left
                              1.0,     // right
                              1.0 - h, // bottom
                              1.0));   // top
      }
      else if (mode == 4)
      {
         // 4. center of the right edge
         scene = scene.changeCamera(
                     Camera.projOrtho(
                              1.0 - w,   // left
                              1.0,       // right
                             -h / 2.0,   // bottom
                              h / 2.0)); // top
      }
      else if (mode == 5)
      {
         // 5. lower right-hand corner
         scene = scene.changeCamera(
                     Camera.projOrtho(
                              1.0 - w,   // left
                              1.0,       // right
                             -1.0,       // bottom
                             -1.0 + h)); // top
      }
      else if (mode == 6)
      {
         // 6. center of the bottom edge
         scene = scene.changeCamera(
                     Camera.projOrtho(
                             -w / 2.0,   // left
                              w / 2.0,   // right
                             -1.0,       // bottom
                             -1.0 + h)); // top
      }
      else if (mode == 7)
      {
         // 7. lower left-hand corner
         scene = scene.changeCamera(
                     Camera.projOrtho(
                             -1.0,       // left
                             -1.0 + w,   // right
                             -1.0,       // bottom
                             -1.0 + h)); // top
      }
      else if (mode == 8)
      {
         // 8. center of the left edge
         scene = scene.changeCamera(
                     Camera.projOrtho(
                             -1.0,       // left
                             -1.0 + w,   // right
                             -h / 2.0,   // bottom
                              h / 2.0)); // top
      }
      else if (mode == 9)
      {
         // 9. center of the framebuffer
         scene = scene.changeCamera(
                     Camera.projOrtho(
                             -w / 2.0,   // left
                              w / 2.0,   // right
                             -h / 2.0,   // bottom
                              h / 2.0)); // top
      }

      super.setupViewing();
   }


   /**
      Create an instance of this class which has
      the affect of creating the GUI application.
   */
   public static void main(String[] args)
   {
      // We need to call the program's constructor in the
      // Java GUI Event Dispatch Thread, otherwise we get a
      // race condition between the constructor (running in
      // the main() thread) and the very first ComponentEvent
      // (running in the EDT).
      javax.swing.SwingUtilities.invokeLater(
         () -> new Circle_Puzzle_5()
      );
   }
}
