/*
 * Renderer 7. The MIT License.
 * Copyright (c) 2022 rlkraft@pnw.edu
 * See LICENSE for details.
*/

package renderer.scene.util;

import renderer.scene.*;
import renderer.scene.primitives.Primitive;

import java.io.File;
import java.io.PrintWriter;
import java.lang.Runtime;
import java.awt.Color;

/**
   This program converts a {@link Scene} data structure into
   a DOT description of the scene. The DOT description is
   then processed by the dot.exe program to produce a
   graphical image of the scene data structure.
<p>
   Create a <code>scene.png</code> file from a <code>scene.dot</code>
   file with the following command line.
   <pre>{@code
   > dot.exe -Tpng -O scene.dot
   }</pre>
<p>
   See
<br><a href="https://www.graphviz.org/Documentation.php" target="_top">
             https://www.graphviz.org/Documentation.php</a>
*/
public class DrawSceneGraph_with_Vertices_Colors
{
   /**
      This method converts the {@link Scene} data structure into a dot
      language description, then writes the dot code into a dot file,
      then runs the dot.exe program on the dot file to create a png
      image of the scene data structure.

      @param scene     {@link Scene} that needs to be converted to a dot description
      @param fileName  base name for the dot and png files
   */
   public static void draw(final Scene scene, final String fileName)
   {
      // Convert the scene data structure into a dot language description.
      final String dotDescription = scene2dot(scene);

      // Write the dot language description stored in dotDescription
      // into a dot file. Then use the dot.exe program to convert the
      // dot file into a png file.
      try
      {
         // Create the (empty) dot file.
         String baseName = fileName;
         java.io.PrintWriter out = new PrintWriter(
                                      new File(baseName + ".dot"));

         // Write the dot commands into the dot file.
         out.print( dotDescription );
         out.close();

         // Create a command-line for running the dot.exe program.
         final String dotExecutable = "C:\\Graphviz\\bin\\dot.exe";
         String[] cmd = {dotExecutable,
                         "-Tpng",
                         baseName + ".dot",
                         "-o",
                         baseName + ".png"};

         File dot = new File(dotExecutable);
         if(dot.exists() && !dot.isDirectory())
         {
            // Execute the command-line to create the png file.
            Runtime.getRuntime().exec(cmd);
         }
         else
         {
            System.out.println("\nPlease consider installing GraphViz:");
            System.out.println("  https://graphviz.org/download/");
            System.out.println("or upload the contents of " + baseName + ".dot to Graphviz Visual Editor:");
            System.out.println("  http://magjac.com/graphviz-visual-editor/");
         }
      }
      catch (Exception e)
      {
         System.out.println( e );
      }
   }


   /**
      This method generates a dot language description of the
      DAG rooted at {@code scene}.
      <p>
      This method generates the dot code for the forest of top-level
      positions just below the scene node. Each position node just
      below the scene node is the root of a DAG. This method calls
      the <code>position2dot()</code> method to recursively traverse
      the DAG of each top-level position. Every position has attached
      to it a {@link Model}, so every position node has attached to it
      a model node.

      @param  scene {@link Scene} that needs to be converted to a dot description
      @return a {@link String} containing the dot language description of the scene
   */
   public static String scene2dot(final Scene scene)
   {
      String result = "digraph {\n";

      // https://graphviz.org/docs/attrs/ordering/
      result += "graph [ordering=\"out\"];\n";

      // https://stackoverflow.com/questions/10879115/graphviz-change-font-for-the-whole-graph
      // https://graphviz.org/docs/attrs/fontname/
      result += "graph [fontname=\"helvetica\"];\n";
      result += "node  [fontname=\"helvetica\"];\n";
      result += "edge  [fontname=\"helvetica\"];\n";

      // Scene node.
      result += "scene [label=\"Scene: " + scene.name + "\"];\n";

      // Camera and List<Position> nodes under the Scene node.

      // Camera node and label.
      final String cameraNodeName = "Camera";
      result += cameraNodeName + " ";
      result += "[label=\"" + scene.camera + "\"];\n";
      // Camera edge.
      result += "scene -> " + cameraNodeName + ";\n";

      // List<Position> node and label.
      final String pListNodeName = "positionList";
      result += pListNodeName + " ";
      result += "[label=\"List<Position>\"];\n";
      // List<Position> edge.
      result += "scene -> " + pListNodeName + ";\n";

      // Create a node and two edges for each top-level
      // Position and its Model and its Vector.
      for (int i = 0; i < scene.positionList.size(); ++i)
      {
         // Position node name.
         final String pNodeName = "_p" + i;

         // Position node and label.
         result += pNodeName + " ";
         result += "[label=\"Position: " + scene.getPosition(i).name + "\"];\n";

         // Position edge.
         result += pListNodeName + " -> " + pNodeName + ";\n";

         // Vector node name.
         final String vNodeName = "_v" + i;

         // Vector node and label.
         result += vNodeName + " ";
         result += "[label=\"Vector: " + scene.getPosition(i).getTranslation() + "\"];\n";

         // Vector edge.
         result += pNodeName + " -> " + vNodeName + ";\n";

         // Model node name.
         // Check if the Model is being reused.
         int j;
         for (j = 0; j <= i; ++j)
         {
            if (scene.getPosition(j).getModel() == scene.getPosition(i).getModel())
            {
               break;
            }
         }
         final String mNodeName = "_m" + j;

         // Model node and label (if the Model hasn't already been used).
         if (j == i)
         {
            result += mNodeName + " ";
            result += "[label=\"Model: " + scene.getPosition(j).getModel().name + "\"];\n";

            // List<Vertex> node and label.
            final String vertexListNodeName = "vertexList_" + i;
            result += vertexListNodeName + " ";
            result += "[label=\"List<Vertex>\"];\n";
            // List<Vertex> edge.
            result += mNodeName + " -> " + vertexListNodeName + ";\n";
            // List<Vertex> children.
            int vertexCounter = 0;
            String lastVertexNodeName = vertexListNodeName;
            for (Vertex v : scene.getPosition(i).getModel().vertexList)
            {
               // Vertex node name.
               final String vertexNodeName = mNodeName + "_v" + vertexCounter;

               // Vertex node and label.
               result += vertexNodeName + " ";
               result += "[label=\"Vertex: " + v + "\"];\n";

               // Vertex edge.
               result += lastVertexNodeName + " -> " + vertexNodeName + ";\n";

               lastVertexNodeName = vertexNodeName;
               ++vertexCounter;
            }


            // List<Color> node and label.
            final String colorListNodeName = "colorList_" + i;
            result += colorListNodeName + " ";
            result += "[label=\"List<Color>\"];\n";
            // List<Color> edge.
            result += mNodeName + " -> " + colorListNodeName + ";\n";
            // List<Color> children.
            int colorCounter = 0;
            String lastColorNodeName = colorListNodeName;
            for (Color c : scene.getPosition(i).getModel().colorList)
            {
               // Color node name.
               final String colorNodeName = mNodeName + "_c" + colorCounter;

               // Color node and label.
               result += colorNodeName + " ";
               result += "[label=\"" + c + "\"];\n";

               // Color edge.
               result += lastColorNodeName + " -> " + colorNodeName + ";\n";

               lastColorNodeName = colorNodeName;
               ++colorCounter;
            }


            // List<Primmitive> node and label.
            final String primitiveListNodeName = "primitiveList_" + i;
            result += primitiveListNodeName + " ";
            result += "[label=\"List<Primitive>\"];\n";
            // List<Primitive> edge.
            result += mNodeName + " -> " + primitiveListNodeName + ";\n";
            // List<Primitive> children.
            int primitiveCounter = 0;
            String lastPrimitiveNodeName = primitiveListNodeName;
            for (Primitive p : scene.getPosition(i).getModel().primitiveList)
            {
               // Primitive node name.
               final String primitiveNodeName = mNodeName + "_p" + primitiveCounter;

               // Primitive node and label.
               result += primitiveNodeName + " ";
               result += "[label=\"" + p + "\"];\n";

               // Primitive edge.
               result += lastPrimitiveNodeName + " -> " + primitiveNodeName + ";\n";

               lastPrimitiveNodeName = primitiveNodeName;
               ++primitiveCounter;
            }
         }

         // Model edge.
         result += pNodeName + " -> " + mNodeName + ";\n";
      }

      result += "}\n";

      return result;
   }



   // Private default constructor to enforce noninstantiable class.
   // See Item 4 in "Effective Java", 3rd Ed, Joshua Bloch.
   private DrawSceneGraph_with_Vertices_Colors()
   {
      throw new AssertionError();
   }
}
