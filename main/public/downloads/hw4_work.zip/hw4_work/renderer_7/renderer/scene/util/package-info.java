/*
 * Renderer 7. The MIT License.
 * Copyright (c) 2022 rlkraft@pnw.edu
 * See LICENSE for details.
*/

/**
   Utility classes and methods for working with scenes and models.
*/
package renderer.scene.util;
