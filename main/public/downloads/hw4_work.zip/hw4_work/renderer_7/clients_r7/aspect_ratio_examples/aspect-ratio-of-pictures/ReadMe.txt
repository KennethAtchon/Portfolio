
Do the following experiments.

1) Open the image tp.png using the IrfanView program. Resize I
   rfanView's screen window a lot. How does it behave?

2) Open the image tp.png using "Windows Photo Viewer" (either by
   double clicking on the image or by right clicking on the image
   and choosing the "Open with" sub-menu). Resize Photo Viewer's
   screen window a lot. How does it behave? How does it behave
   differently from IrfanView?

3) Open the image tp.png using Chrome or Firefox (or some other
   browser) by dragging the image onto an empty tab. Resize browser's
   tab a lot. How does it behave? How does it behave differently from
   IrfanView or Photo Viewer?

4) Double click on the file page1.html to open it in a browser.
   Cycle through the five pages and notice how the image display
   changes. Also, try resizing the browser window.


Look for the following. When does the program
  a) distort,
  b) letterbox,
  c) scale,
  d) crop,
  e) pan,
  f) something else?
