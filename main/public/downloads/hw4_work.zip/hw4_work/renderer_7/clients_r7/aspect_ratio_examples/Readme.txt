
   Aspect ratios, cropping, letterboxing, and scaling

The demo programs demonstrate several ways that a graphics program
can react to a user changing the shape of the program's window. Each
demo program is displaying a rotating wheel. The rotating wheel image
has an aspect ratio of 1 and it starts out with dimensions 512 pixels
by 512 pixels. When the user changes the dimension of the program's
window (which is the same thing as changing the dimensions of the program's
framebuffer) the issue is how the program should display the 512-by-512
wheel image in the new window. The new window might be larger or smaller
than the original 512 pixels by 512 pixels. Should the wheel be magnified,
or maybe letterboxed, into a larger window? Should the original image be
scaled down, or maybe cropped, into a smaller window? If you crop the
original image, which part of it is cropped off? If the image is letterboxed,
where in the framebuffer is the letterboxing viewport placed (that is, where
should the "empty" spaces go)?

To see some important answers to the last few questions, look at the source
code to the examples Circle_v2_Letterbox.java and Circle_v3_Crop.java. In
particular, notice that when we crop a source image, the part that we keep
can be placed at nine different locations within the source image (think of
a tic-tack-toe grid placed on the source image). Similarly, if we letterbox
the viewport within the framebuffer, there are nine locations in the
framebuffer where we can place the viewport (think of the same tic-tac-toe
grid but placed this time on the framebuffer). If we are both cropping and
letterboxing, then we could even choose different grid locations for the
cropping of the source image and the letterboxing of the viewport.


In general, cropping of the source image is implemented by changing
the camera's view rectangle using the
   projOrtho(double left, double right, double bottom, double top)
method in the renderer's Camera class.

Letterboxing an image into the framebuffer is implemented using the
   setViewport(int x, int y, int wVP, int hVP)
method of the renderer's FrameBuffer class.

Scaling an image is done automatically by the renderer when it maps
the whole of the camera's view-rectangle onto the framebuffer's
viewport. If the aspect ratios of the camera's view-rectangle and
the framebuffer's viewport do not agree, then the renderer will
distort the final image in the viewport.

There are two illustrations in this folder that try to visualize the
relationship between cropping, letterboxing, and the parameters to the
projOrtho() and setViewport() methods.

