/*
 * Renderer 7. The MIT License.
 * Copyright (c) 2022 rlkraft@pnw.edu
 * See LICENSE for details.
*/

import renderer.scene.*;
import renderer.scene.util.ModelShading;
import renderer.models_L.Disk;
import renderer.pipeline.*;
import renderer.framebuffer.*;

import java.awt.Color;
import javax.swing.JFrame;
import java.awt.BorderLayout;
import java.awt.event.KeyListener;
import java.awt.event.KeyEvent;
import java.awt.event.ComponentListener;
import java.awt.event.ComponentEvent;
import javax.swing.Timer;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

/**
   Crop the source image if either the width or height of the
   framebuffer is < SIZE (the initial size for the framebuffer).
<p>
   Letterbox the viewport, without scaling, if either the width
   or height of the framebuffer is > SIZE (the initial size for the
   framebuffer).
<p>
   This program has nine modes for how it places the viewport within
   the framebuffer (that is, nine letterboxing modes).
<p>
  This program has nine modes for how it anchors the circle within the
  camera's view rectangle (that is, nine cropping modes).
*/
@SuppressWarnings("serial")
public class Circle_v6_CropAndLetterbox extends JFrame
       implements KeyListener, ComponentListener, ActionListener
{
   private final int SIZE = 512;

   private boolean show_Camera = false;
   private boolean show_FB_AspectRatio = false;

   private boolean chooseCropMode = true;
   private int cropMode = 1;
   private int letterboxMode = 1;

   private Scene scene;
   private final FrameBufferPanel fbp;

   private Position modelToRotate = null;
   private final Timer timer;

   /**
      This constructor instantiates the Scene object
      and initializes it with appropriate geometry.
      Then this constructor instantiates the GUI.
   */
   private Circle_v6_CropAndLetterbox(String title)
   {
      super(title);

      // Create the Scene object that we shall render.
      scene = new Scene();

      // Create a model of a circle.
      final Model model = new Disk(1.0, 10, 40);
      final Position position = new Position(model);
      modelToRotate = position;
      ModelShading.setRandomColor(model);
      // Add the Model to the Scene.
      scene.addPosition(position);


      // Create a FrameBufferPanel that will hold a FrameBuffer.
      final int width  = SIZE;
      final int height = SIZE;
      fbp = new FrameBufferPanel(width, height);
      fbp.getFrameBuffer().setBackgroundColorFB(Color.darkGray);
      fbp.getFrameBuffer().getViewport().setBackgroundColorVP(Color.black);

      this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

      // Place the FrameBufferPanel in this JFrame.
      this.getContentPane().add(fbp, BorderLayout.CENTER);
      this.pack();
      this.setLocationRelativeTo(null);
      this.setVisible(true);

      // Create event handler objects for events from this JFrame.
      this.addKeyListener(this);
      this.addComponentListener(this);

      // Create a Timer object that will generate ActionEvent
      // objects for the ActionListener handler to respond to.
      final int fps = 30;
      timer = new Timer(1000/fps, this);
      timer.start();

      print_help_message();
   }


   /**
      Get in one place the code to set up the viewport and the view volume.
   */
   private void setupViewing()
   {
      // Get the size of the FrameBuffer.
      final FrameBuffer fb = fbp.getFrameBuffer();
      final int wFB = fb.width;
      final int hFB = fb.height;

      // Set the size of the viewport. (SIZE is
      // the initial size of the framebuffer.)
      final int wVP = Math.min(SIZE, wFB);
      final int hVP = Math.min(SIZE, hFB);

      // Compute a displacement for the viewport within the framebuffer.
      final int hOffset = (wVP < wFB) ? (wFB - wVP) / 2 : 0;
      final int vOffset = (hVP < hFB) ? (hFB - hVP) / 2 : 0;

      // When the framebuffer is smaller than SIZE x SIZE,
      // compute the width and height of the largest possible
      // sub-rectangle of the unit square,
      //     -1 <= x <= 1, -1 <= y <= 1,
      // with the same aspect ratio as the viewport, wVP/hVP.
      final double w;
      final double h;
      // Compute the view rectangle's width.
      if (wVP < SIZE) // crop on the left and/or right
      {
         w = 2.0 * ((double)wVP / (double)SIZE);
      }
      else // don't crop horizontally
      {
         w = 2.0;
      }
      // Compute the view rectangle's height.
      if (hVP < SIZE) // crop on the top and/or bottom
      {
         h = 2.0 * ((double)hVP / (double)SIZE);
      }
      else // don't crop vertically
      {
         h = 2.0;
      }

      // If the framebuffer is smaller than SIZE x SIZE, then
      // crop the view rectangle to match the framebuffer.
      if (cropMode == 1)
      {
         // 1. upper left-hand corner
         scene = scene.changeCamera(
                     Camera.projOrtho(
                             -1.0,     // left
                             -1.0 + w, // right
                              1.0 - h, // bottom
                              1.0));   // top
      }
      else if (cropMode == 2)
      {
         // 2. center of the top edge
         scene = scene.changeCamera(
                     Camera.projOrtho(
                             -w / 2.0, // left
                              w / 2.0, // right
                              1.0 - h, // bottom
                              1.0));   // top
      }
      else if (cropMode == 3)
      {
         // 3. upper right-hand corner
         scene = scene.changeCamera(
                     Camera.projOrtho(
                              1.0 - w, // left
                              1.0,     // right
                              1.0 - h, // bottom
                              1.0));   // top
      }
      else if (cropMode == 4)
      {
         // 4. center of the right edge
         scene = scene.changeCamera(
                     Camera.projOrtho(
                              1.0 - w,   // left
                              1.0,       // right
                             -h / 2.0,   // bottom
                              h / 2.0)); // top
      }
      else if (cropMode == 5)
      {
         // 5. lower right-hand corner
         scene = scene.changeCamera(
                     Camera.projOrtho(
                              1.0 - w,   // left
                              1.0,       // right
                             -1.0,       // bottom
                             -1.0 + h)); // top
      }
      else if (cropMode == 6)
      {
         // 6. center of the bottom edge
         scene = scene.changeCamera(
                     Camera.projOrtho(
                             -w / 2.0,   // left
                              w / 2.0,   // right
                             -1.0,       // bottom
                             -1.0 + h)); // top
      }
      else if (cropMode == 7)
      {
         // 7. lower left-hand corner
         scene = scene.changeCamera(
                     Camera.projOrtho(
                             -1.0,       // left
                             -1.0 + w,   // right
                             -1.0,       // bottom
                             -1.0 + h)); // top
      }
      else if (cropMode == 8)
      {
         // 8. center of the left edge
         scene = scene.changeCamera(
                     Camera.projOrtho(
                             -1.0,       // left
                             -1.0 + w,   // right
                             -h / 2.0,   // bottom
                              h / 2.0)); // top
      }
      else if (cropMode == 9)
      {
         // 9. center of the framebuffer
         scene = scene.changeCamera(
                     Camera.projOrtho(
                             -w / 2.0,   // left
                              w / 2.0,   // right
                             -h / 2.0,   // bottom
                              h / 2.0)); // top
      }

      // If the framebuffer is larger than SIZE x SIZE, then
      // letterbox the viewport within the framebuffer.
      if (letterboxMode == 1)
      {
         // 1. upper left-hand corner
         fb.setViewport(0, 0, wVP, hVP);
      }
      else if (letterboxMode == 2)
      {
         // 2. center of the top edge
         fb.setViewport(hOffset, 0, wVP, hVP);
      }
      else if (letterboxMode == 3)
      {
         // 3. upper right-hand corner
         fb.setViewport(wFB - wVP, 0, wVP, hVP);
      }
      else if (letterboxMode == 4)
      {
         // 4. center of the right edge
         fb.setViewport(wFB - wVP, vOffset, wVP, hVP);
      }
      else if (letterboxMode == 5)
      {
         // 5. lower right-hand corner
         fb.setViewport(wFB - wVP, hFB - hVP, wVP, hVP);
      }
      else if (letterboxMode == 6)
      {
         // 6. center of the bottom edge
         fb.setViewport(hOffset, hFB - hVP, wVP, hVP);
      }
      else if (letterboxMode == 7)
      {
         // 7. lower left-hand corner
         fb.setViewport(0, hFB - hVP, wVP, hVP);
      }
      else if (letterboxMode == 8)
      {
         // 8. center of the left edge
         fb.setViewport(0, vOffset, wVP, hVP);
      }
      else if (letterboxMode == 9)
      {
         // 9. center of the framebuffer
         fb.setViewport(hOffset, vOffset, wVP, hVP);
      }

      // Render again.
      fb.clearFB();
      fb.vp.clearVP();
      Pipeline.render(scene, fb);
      fbp.repaint();
   }


   // Implement the KeyListener interface.
   @Override public void keyPressed(KeyEvent e){}
   @Override public void keyReleased(KeyEvent e){}
   @Override public void keyTyped(KeyEvent e)
   {
      //System.out.println( e );

      final char c = e.getKeyChar();
      if ('h' == c)
      {
         print_help_message();
         return;
      }
      else if ('d' == c)
      {
         final Position p = scene.getPosition(0);
         p.debug = ! p.debug;
         Clip.debug = p.debug;
      }
      else if ('D' == c)
      {
         Rasterize.debug = ! Rasterize.debug;
      }
      else if ('a' == c)
      {
         Rasterize.doAntiAliasing = ! Rasterize.doAntiAliasing;
         System.out.print("Anti-aliasing is turned ");
         System.out.println(Rasterize.doAntiAliasing ? "On" : "Off");
      }
      else if ('g' == c)
      {
         Rasterize.doGamma = ! Rasterize.doGamma;
         System.out.print("Gamma correction is turned ");
         System.out.println(Rasterize.doGamma ? "On" : "Off");
      }
      else if ('m'==c || 'M' == c)
      {
         show_Camera = ! show_Camera;
         if (show_Camera)
         {
            System.out.print( scene.camera );
         }
      }
      else if ('f' == c)
      {
         show_FB_AspectRatio = ! show_FB_AspectRatio;
         if (show_FB_AspectRatio)
         {
            // Get the new size of the FrameBufferPanel.
            final int w = fbp.getWidth();
            final int h = fbp.getHeight();
            System.out.printf(
              "Aspect ratio (of framebuffer) = %.2f\n", (double)w/(double)h);
         }
      }
      else if ('c' == c)
      {
         // Change the solid random color of the disk.
         ModelShading.setRandomColor(scene.getPosition(0).getModel());
      }
      else if ('C' == c)
      {
         // Change each color in the disk to a random color.
         ModelShading.setRandomColors(scene.getPosition(0).getModel());
      }
      else if ('e' == c && e.isAltDown())
      {
         // Change the random color of each vertex of the disk.
         ModelShading.setRandomVertexColors(scene.getPosition(0).getModel());
      }
      else if ('e' == c)
      {
         // Change the solid random color of each edge of the disk.
         ModelShading.setRandomPrimitiveColors(scene.getPosition(0).getModel());
      }
      else if ('E' == c)
      {
         // Change the random color of each end of each edge of the disk.
         ModelShading.setRainbowPrimitiveColors(scene.getPosition(0).getModel());
      }
      else if ('s' == c)
      {
         // Stop the rotation.
         timer.stop();
      }
      else if ('S' == c)
      {
         // Start the rotation.
         timer.start();
      }
      else if ('0' == c)
      {
         chooseCropMode = ! chooseCropMode;
         System.out.println("letterboxMode = " + letterboxMode);
         System.out.println("cropMode = " + cropMode);
         System.out.println("Choosing "
                          + (chooseCropMode ? "crop" : "letterbox")
                          + " mode.");
      }
      else if ('1' == c)
      {
         if (chooseCropMode)
            cropMode = 1;
         else
            letterboxMode = 1;
      }
      else if ('2' == c)
      {
         if (chooseCropMode)
            cropMode = 2;
         else
            letterboxMode = 2;
      }
      else if ('3' == c)
      {
         if (chooseCropMode)
            cropMode = 3;
         else
            letterboxMode = 3;
      }
      else if ('4' == c)
      {
         if (chooseCropMode)
            cropMode = 4;
         else
            letterboxMode = 4;
      }
      else if ('5' == c)
      {
         if (chooseCropMode)
            cropMode = 5;
         else
            letterboxMode = 5;
      }
      else if ('6' == c)
      {
         if (chooseCropMode)
            cropMode = 6;
         else
            letterboxMode = 6;
      }
      else if ('7' == c)
      {
         if (chooseCropMode)
            cropMode = 7;
         else
            letterboxMode = 7;
      }
      else if ('8' == c)
      {
         if (chooseCropMode)
            cropMode = 8;
         else
            letterboxMode = 8;
      }
      else if ('9' == c)
      {
         if (chooseCropMode)
            cropMode = 9;
         else
            letterboxMode = 9;
      }

      setupViewing();
   }


   // Implement the ComponentListener interface.
   @Override public void componentMoved(ComponentEvent e){}
   @Override public void componentHidden(ComponentEvent e){}
   @Override public void componentShown(ComponentEvent e){}
   @Override public void componentResized(ComponentEvent e)
   {
    //System.out.println( e );

      // Get the new size of the FrameBufferPanel.
      final int wFB = fbp.getWidth();
      final int hFB = fbp.getHeight();

      if (show_FB_AspectRatio)
      {
         System.out.printf(
           "Aspect ratio (of framebuffer) = %.2f\n", (double)wFB/(double)hFB);
      }

      if (show_Camera)
      {
         System.out.print( scene.camera );
      }

      if (0 == hFB) return; // there is no window to draw

      // Create a new FrameBuffer that fits the FrameBufferPanel.
      final Color bg1 = fbp.getFrameBuffer().getBackgroundColorFB();
      final Color bg2 = fbp.getFrameBuffer().getViewport()
                                            .getBackgroundColorVP();
      final FrameBuffer fb = new FrameBuffer(wFB, hFB, bg1);
      fb.vp.setBackgroundColorVP(bg2);
      fbp.setFrameBuffer(fb);

      setupViewing();
   }


   // Implement the ActionListener interface (for the timer).
   @Override public void actionPerformed(ActionEvent e)
   {
      rotateModel(modelToRotate, 10); // 10 degrees
      setupViewing();
   }


   private void rotateModel(final Position p,
                              final double angle) // angle in degrees
   {
      final Model m = p.getModel();

      final double angleRad = angle * Math.PI / 180.0; // convert to radians

      for (int i = 0; i < m.vertexList.size(); ++i)
      {
         final Vertex v = m.vertexList.get(i);
         m.vertexList.set(i, new Vertex(
                               v.x * Math.cos(angleRad) - v.y * Math.sin(angleRad),
                               v.x * Math.sin(angleRad) + v.y * Math.cos(angleRad),
                               v.z));
      }
   }


   private void print_help_message()
   {
      System.out.println("Use the 'd/D' key to toggle debugging information on and off.");
      System.out.println("Use the 'a' key to toggle anti-aliasing on and off.");
      System.out.println("Use the 'g' key to toggle gamma correction on and off.");
      System.out.println("Use the 'f' key to toggle showing framebuffer aspect ratio.");
      System.out.println("Use the 'm' key to toggle showing the Camera data.");
      System.out.println("Use the 's/S' key to stop/Start the rotation.");

      System.out.println("Use the '0' key to toggle choosing letterbox/crop mode.");
      System.out.println("Use the '1' through '9' keys to choose a letterbox/crop mode.");
      System.out.println("Use the 'h' key to redisplay this help message.");
   }

   /**
      Create an instance of this class which has
      the affect of creating the GUI application.
   */
   public static void main(String[] args)
   {
      // We need to call the program's constructor in the
      // Java GUI Event Dispatch Thread, otherwise we get a
      // race condition between the constructor (running in
      // the main() thread) and the very first ComponentEvent
      // (running in the EDT).
      javax.swing.SwingUtilities.invokeLater(
         () -> new Circle_v6_CropAndLetterbox("Renderer 7 - Crop & Letterbox")
      );
   }
}
