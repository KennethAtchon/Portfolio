/*
Course: CS 45500
Name: Kenneth Atchon
Email: katchon@pnw.edu
Assignment: 4
*/

import renderer.scene.*;
import renderer.scene.util.ModelShading;
import renderer.scene.Matrix;
import renderer.scene.util.DrawSceneGraph;
import renderer.models_L.*;
import renderer.pipeline.*;
import renderer.framebuffer.*;

import java.awt.Color;
import javax.swing.JFrame;
import java.awt.BorderLayout;
import java.awt.event.KeyListener;
import java.awt.event.KeyEvent;
import java.awt.event.ComponentListener;
import java.awt.event.ComponentEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.Timer;

/**

*/
public class Hw4 implements ActionListener,
                            KeyListener,
                            ComponentListener
{
   private final int wSIZE = 800; // aspect ration = 2.0
   private final int hSIZE = 400;

   private double deltaAngle = 2.0;

   private int fps = 60;
   private Timer timer = null;

   private Scene scene;
   private final Position pPos;
   private final Position nPos;
   private final Position wPos;

   private double pRotation = 0.0;
   private double nRotation = 0.0;
   private double wRotation = 0.0;

   private double focalLength = 4.0;
   private boolean perspective = false;
   private boolean animation = true;
   private boolean debug = false;
   private boolean showViewData = false;
   private boolean viewDataChanged = false;
   private boolean hideBackground = false;

   private final JFrame jf;
   private final FrameBufferPanel fbp;

   /**
      This constructor instantiates the Scene object
      and initializes it with appropriate geometry.
      Then this constructor instantiates the GUI.
   */
   public Hw4()
   {
      scene = new Scene("Hw_4",
                        Camera.projOrtho(-2.0, 2.0, -1, 1));

      // Create a model of a circle.
      final Model disk = new Disk(1.0, 10, 40);
      ModelShading.setColor(disk, Color.darkGray.darker());
      scene.addPosition(new Position(disk));

      // Create a model of an xy-axis.
      final Model axis = new Axes2D(-2.0, 2.0, -1.0, 1.0, 40, 2);
      ModelShading.setColor(axis, Color.red);
      scene.addPosition(new Position(axis));

      // Create the P.
      final Model p = new P();
      ModelShading.setColor(p, Color.yellow);
      scene.addPosition( new Position(p,
                                      "p0",
                                      Matrix.translate(-1.5, -0.5, 0)) );
      pPos = scene.getPosition(scene.positionList.size()-1);

      // Create the N.
      final Model n = new N();
      ModelShading.setColor(n, Color.magenta);
      scene.addPosition( new Position(n,
                                      "p1",
                                      Matrix.translate(-0.5, -0.5, 0)) );
      nPos = scene.getPosition(scene.positionList.size()-1);

      // Create the W.
      final Model w = new W();
      ModelShading.setColor(w, Color.green);
      scene.addPosition( new Position(w,
                                      "p2",
                                      Matrix.translate(0.5, -0.5, 0)) );
      wPos = scene.getPosition(scene.positionList.size()-1);

      //DrawSceneGraph.draw(scene, "SG_Hw_4");


      // Create a FrameBufferPanel that holds a FrameBuffer.
      fbp = new FrameBufferPanel(wSIZE, hSIZE, Color.darkGray);
      fbp.getFrameBuffer().getViewport().setBackgroundColorVP(Color.black);

      // Create a JFrame that will hold the FrameBufferPanel.
      jf = new JFrame("Renderer 9 - Hw 4");
      jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      jf.getContentPane().add(fbp, BorderLayout.CENTER);
      jf.pack();
      jf.setLocationRelativeTo(null);
      jf.setVisible(true);

      // Create event handler objects for events from the JFrame.
      jf.addKeyListener(this);
      jf.addComponentListener(this);

      timer = new Timer(1000/fps, this); // ActionListener
      timer.start();

      print_help_message();
   }


   // Implement the KeyListener interface.
   @Override public void keyPressed(KeyEvent e){}
   @Override public void keyReleased(KeyEvent e){}
   @Override public void keyTyped(KeyEvent e)
   {
      //System.out.println( e );

      final char c = e.getKeyChar();
      if ('h' == c)
      {
         print_help_message();
         return;
      }
      else if ('d' == c && e.isAltDown())
      {
         System.out.println();
         System.out.println( scene );
      }
      else if ('d' == c)
      {
         debug = true; // debug one frame of animation
      }
      else if ('p' == c)
      {
         perspective = ! perspective;
         final String p = perspective ? "perspective" : "orthographic";
         System.out.println("Using " + p + " projection");
      }
      else if ('f' == c)
      {
         focalLength -= 0.2;
         System.out.println("focalLength = " + focalLength);
      }
      else if ('F' == c)
      {
         focalLength += 0.2;
         System.out.println("focalLength = " + focalLength);
      }
      else if ('e' == c)
      {
         deltaAngle -= 0.2;
         System.out.println("degrees per frame = " + deltaAngle);
      }
      else if ('E' == c)
      {
         deltaAngle += 0.2;
         System.out.println("degrees per frame = " + deltaAngle);
      }
      else if ('r' == c)
      {
         fps -= 1;
         if (0 == fps) fps = 1;
         System.out.println("fps = " + fps);
         setFPS();
      }
      else if ('R' == c)
      {
         fps += 1;
         System.out.println("fps = " + fps);
         setFPS();
      }
      else if ('s' == c || 'S' == c)
      {
         animation = ! animation; // turn animation off and on
      }
      else if ('v' == c)
      {
         showViewData = ! showViewData;
      }
      else if ('m' == c)
      {
         hideBackground = ! hideBackground;
         scene.getPosition(0).visible = !hideBackground;
         scene.getPosition(1).visible = !hideBackground;
      }


      if (showViewData && ('v' ==c
                        ||(('f' == c || 'F' ==c) && perspective)
                        || 'p' == c))
      {
         viewDataChanged = true;
      }

      setupViewing();
   }


   private void setFPS()
   {
      timer.stop();
      if (fps > 0)
      {
         timer = new Timer(1000/fps, this);
         if (animation)
         {
            timer.start(); // Start the animation.
         }
      }
   }


   // Implement the ComponentListener interface.
   @Override public void componentMoved(ComponentEvent e){}
   @Override public void componentHidden(ComponentEvent e){}
   @Override public void componentShown(ComponentEvent e){}
   @Override public void componentResized(ComponentEvent e)
   {
      //System.out.println( e );

      // Get the new size of the FrameBufferPanel.
      final int wFB = fbp.getWidth();
      final int hFB = fbp.getHeight();

      // Create a new FrameBuffer that fits the FrameBufferPanel.
      final Color bg1 = fbp.getFrameBuffer().getBackgroundColorFB();
      final Color bg2 = fbp.getFrameBuffer().getViewport()
                                            .getBackgroundColorVP();
      final FrameBuffer fb = new FrameBuffer(wFB, hFB, bg1);
      fb.vp.setBackgroundColorVP(bg2);
      fbp.setFrameBuffer(fb);

      viewDataChanged = true;

      setupViewing();
   }


   // Implement the ActionListener interface (for the timer).
   @Override public void actionPerformed(ActionEvent e)
   {
      //System.out.println( e );

      // Update the parameters for the next frame.
      pRotation += deltaAngle;
      nRotation += deltaAngle;
      wRotation += deltaAngle;

      setupViewing();
   }


   /**
      Get in one place the code to set up
      the view volume and the viewport.
   */
   private void setupViewing()
   {
      // Get the size of the FrameBuffer.
      final FrameBuffer fb = fbp.getFrameBuffer();
      final int wFB = fb.width;
      final int hFB = fb.height;
      fb.setViewport(0,0, wFB, hFB);
      // Set the size of the viewport to
      // be the size of the framebuffer.
      final int wVP = wFB;
      final int hVP = hFB;
      final int SIZE = Math.min(wSIZE, hSIZE);

      final double w;
      final double h;
      if (wFB <= hFB) // aspect ratio >= 1
      {
         w = 2.0;                 //  w/h = wFB/hFB
         h = (2.0 * hFB) / wFB;
      }
      else // aspect ratio < 1
      {
         w = (2.0 * wFB) / hFB;  //  w/h = wFB/hFB
         h = 2.0;
      }


      // Do part 1 of the assignment.
      double left   = -2;
      double right  =  2;
      double bottom = -1;
      double top    =  1;

      // Change the values of these variables
      // to set the camera's view rectangle.
      // double left   = -(wVP/(double)SIZE);
      // double right  =  (wVP/(double)SIZE);
      // double bottom = -(hVP/(double)SIZE);
      // double top    =  (hVP/(double)SIZE);

      if(wSIZE > wFB){
         left = -w/2.0;
         right = w/2.0;
         bottom = 1.0 -h;
         top = 1.0;
      }
      if(hSIZE > hFB){
         left = 1.0 - w;
         right = 1.0;
         bottom = -h / 2.0;
         top = -1.0 + h;
      }
      

      if (! perspective) // orthographic projection
      {
         scene = scene.changeCamera(
                     Camera.projOrtho(left,
                                      right,
                                      bottom,
                                      top));
      }
      else // perspective projection
      {
         scene = scene.changeCamera(
                     Camera.projPerspective(left,
                                            right,
                                            bottom,
                                            top,
                                            focalLength)
                           .translate(0, 0, focalLength));
      }


      // Do part 2 of the assignent.

      // Rotate the letter P around the x-axis.



      // Rotate the letter N around the y-axis.



      // Rotate the letter W simultaneously around
      // the y-axis and the z-axis.





      if (animation)
      {
         timer.start(); // Start the animation.
      }
      else
      {
         timer.stop(); // Stop the animation.
      }

      if (showViewData && viewDataChanged)
      {
         displayViewDtata();
      }

      // Render again.
      fb.clearFB();
      fb.vp.clearVP();
      if (debug) // debug one frame of the animation
      {
         scene.debug = true;
         Clip.debug = true;
      }
      Pipeline.render(scene, fb);
      debug = false;
      scene.debug = false;
      Clip.debug = false;
      fbp.repaint();
   }


   private void displayViewDtata()
   {
      // Get the size of the FrameBuffer.
      final int wFB = fbp.getFrameBuffer().getWidthFB();
      final int hFB = fbp.getFrameBuffer().getHeightFB();
      // Get the size of the Viewport.
      final int wVP = fbp.getFrameBuffer().getViewport().getWidthVP();
      final int hVP = fbp.getFrameBuffer().getViewport().getHeightVP();
      // Get the location of the Viewport in the FrameBuffer.
      final int vp_ul_x = fbp.getFrameBuffer().getViewport().vp_ul_x;
      final int vp_ul_y = fbp.getFrameBuffer().getViewport().vp_ul_y;
      // Get the size of the camera's view rectangle.
      final Camera c = scene.camera;
      final double wVR = c.right - c.left;
      final double hVR = c.top - c.bottom;

      final double rFB  = (double)wFB/(double)hFB;
      final double rVP  = (double)wVP/(double)hVP;
      final double rC   = wVR / hVR;

      System.out.printf(
         "= View information =============================================\n" +
         "  FrameBuffer [w=%4d, h=%4d], aspect ratio = %.2f\n" +
         "  Viewport    [w=%4d, h=%4d, x=%d, y=%d], aspect ratio = %.2f\n" +
         "  view-rect   [w= %.2f, h= %.2f], aspect ratio = %.2f\n",
         wFB, hFB, rFB,
         wVP, hVP, vp_ul_x, vp_ul_y, rVP,
         wVR, hVR, rC);
      System.out.println( c );

      viewDataChanged = false;
   }


   private void print_help_message()
   {
      System.out.println("Use the 'd' key to debug one frame of animation.");
      System.out.println("Use the 'Alt-d' key combination to print the Scene data structure.");
      System.out.println("Use the 'm' key to toggle hiding the background models.");
      System.out.println("Use the 'v' key to toggle showing the view data.");
      System.out.println("Use the f/F keys to decrease/increase the camera's focal-length.");
      System.out.println("Use the r/R keys to decrease/increase the frame rate.");
      System.out.println("Use the e/E keys to decrease/increase the degrees per frame.");
      System.out.println("Use the 's' key to stop/start the animation.");
      System.out.println("Use the 'h' key to redisplay this help message.");
   }


   /**
      Create an instance of this class which has
      the affect of creating the GUI application.
   */
   public static void main(String[] args)
   {
      // We need to call the program's constructor in the
      // Java GUI Event Dispatch Thread, otherwise we get a
      // race condition between the constructor (running in
      // the main() thread) and the very first ComponentEvent
      // (running in the EDT).
      javax.swing.SwingUtilities.invokeLater(
         () -> new Hw4()
      );
   }
}
