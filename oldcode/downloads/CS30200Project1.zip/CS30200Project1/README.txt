To run program.cpp please use Windows Command Line
----------------------------------------------------------
Input Files: input.txt, input2.txt, input3.txt, input4.txt, input5.txt
----------------------------------------------------------
g++ program.cpp -o program

program < input.txt or program.exe < input.txt
----------------------------------------------------------

What the program does:
Puts everything in the txt file in a long string and organizes the info into Process struct
Sort the process by their sort time
Add them to the ready Q according to their start time
Add them to the process table from the ready Q
Schedule each process by putting them in a cpu, disk, or terminal queue
When they put it in cpu scheduler, it checks if it is a real time process then shifts the queue
when a real time process leaves the cpu queue, it checks if theres any other real time processes to move up
Schedules the disk one at a time
Schedules every terminal at the same time since each process reads to a different terminal
Once the process has a empty resource deque, it terminates the process
It then prints the summary
