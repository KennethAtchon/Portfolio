/*
Name: Kenneth Atchon
Course Number: CS302
Due Date: Monday, Feb. 13, 2023
Description: This project stimulates a process scheduler.
*/

#ifndef __cplusplus
#error A C++ compiler is required.
#endif

#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <vector>
#include <queue>
#include <deque>
#include <algorithm>
#include <functional>


// define constants
const std::string REAL_TIME = "REAL-TIME";
const std::string INTERACTIVE = "INTERACTIVE";
const std::string CPU = "CPU";
const std::string DISK = "DISK";
const std::string TTY = "TTY";
const std::string RUNNING = "RUNNING";
const std::string DONE = "DONE";
const std::string READY = "READY";
const std::string WAITING = "WAITING";


// Process struct that represents a REAL TIME or INTERACTIVE process
struct Process {

    // REAL TIME or INTERACTIVE
    std::string type;
    int start_time = -1;
    int deadline = 0;
    int completion_time;

    // Rsources: CPU, TERMINAL, DISK
    struct ResourceRequest {
        std::string type;
        int duration;
    };
    std::deque<ResourceRequest> resource_requests;

};

// Process Queues
std::vector<Process> waiting_real_time_queue;
std::vector<Process> waiting_interactive_queue;

std::vector<Process> ready_real_time_queue;
std::vector<Process> ready_interactive_queue;



// Summary report listing
struct SummaryReport {
    // number of processes completed
    int completed_real_time = 0;
    int completed_interactive = 0;
    // number of real time that missed the deadline
    int real_time_missed_deadline = 0;

    int disk_accesses = 0;
    int duration_of_disk_access = 0;
    int duration_of_waiting_disk = 0;

    int totaltimeelapsed = 0;

    int cpu_utilization = 0;
    int disk_utilization = 0;
};

SummaryReport reporter;

// Entry per Process
struct ProcessEntry {
    int process_sequence_number;
    Process process;
    int arrivaltime;
    // READY, DONE, RUNNING, WAITING
    std::string current_status;

    // constructor
    ProcessEntry(){
        process_sequence_number = 0;
        current_status = "";
        arrivaltime = 0;
    }


};

// process table/vector of pointers to each entry
std::vector<ProcessEntry*> process_table;

std::queue<ProcessEntry*> cpu_queue;
std::queue<ProcessEntry*> disk_queue;
std::deque<ProcessEntry*> terminal_deque;


// sort each waiting queue by its start time
void sortByStartTime(){

    // sorts real time
    std::sort(waiting_real_time_queue.begin(),
     waiting_real_time_queue.end(), 
     [](const Process &a, const Process &b) {

    return a.start_time < b.start_time;
        });

    // sorts interactive
    std::sort(waiting_interactive_queue.begin(),
     waiting_interactive_queue.end(),
      [](const Process &a, const Process &b) {

        return a.start_time < b.start_time;
        });

}

// time
int miliseconds = 0;
// track process sequence number
int process_sequence_num = 1;


// adds to ready Q if miliseconds >= start time
void addToReadyQ(){

    // if real time queue is not empty and miliseconds >= start time, add it to ready queue
    if (!waiting_real_time_queue.empty() && miliseconds >= waiting_real_time_queue[0].start_time){

        // add waiting real time into ready real time
        ready_real_time_queue.push_back(waiting_real_time_queue.front());

        // remove from waiting real time
        waiting_real_time_queue.erase( waiting_real_time_queue.begin() );

        }
       else if (!waiting_interactive_queue.empty() && miliseconds >= waiting_interactive_queue[0].start_time){

            ready_interactive_queue.push_back(waiting_interactive_queue.front());

            waiting_interactive_queue.erase( waiting_interactive_queue.begin() );

        } 
}

// adds ready processes into the process table
void addtoProcessTable(){

    // add real time process to process table
    if (!ready_real_time_queue.empty()){

            // creates a pointer to new ProcessEntry project
            ProcessEntry *entry = new ProcessEntry();

            // assigns a process sequence number to entry and increments process sequence number
            entry->process_sequence_number = process_sequence_num;
            process_sequence_num++;

            // arrival time of entry
            entry->arrivaltime = miliseconds;

            // add process to process entry
            entry->process = ready_real_time_queue[0];

            // remove from ready queue
            ready_real_time_queue.erase( ready_real_time_queue.begin() );

            // set current status to running
            entry->current_status = READY;

            // add into process table
            process_table.push_back(entry);

            std::cout << std::endl;
            std::cout << "Added a " << entry->process.type << " process to the queue" << std::endl;

            std::cout << "The process sequence number is " << entry->process_sequence_number << std::endl;
            std::cout << "This process arrived at: " << entry->arrivaltime << " miliseconds." << std::endl;
            return;

        }
        // add interactive process to process table
        else if (!ready_interactive_queue.empty()){

            
            ProcessEntry *entry = new ProcessEntry();

            entry->process_sequence_number = process_sequence_num;
            process_sequence_num++;

            // arrival time of entry
            entry->arrivaltime = miliseconds;

            entry->process = ready_interactive_queue[0];
            ready_interactive_queue.erase( ready_interactive_queue.begin() );

            // set current status to running
            entry->current_status = READY;

            // add into process table
            process_table.push_back(entry);

            std::cout << std::endl;
            std::cout << "Added a " << entry->process.type << " process to the queue" << std::endl;

            std::cout << "The process sequence number is " << entry->process_sequence_number << std::endl;
            std::cout << "This process arrived at: " << entry->arrivaltime << " miliseconds." <<  std::endl;
            return;

        }

}

// deletes a entry pointer and removes it from process table
void terminateProcess(){
    // index of each process entry
    int index = 0;

    // looks through all the entries
    for(const auto& entry: process_table){

        // if its status is done then it will delete it
        if(entry->current_status == DONE){

            // time the process took to complete
            int time_elapsed = entry->process.completion_time - entry->arrivaltime;

            
            if(entry->process.type == REAL_TIME){
                // add to real time completed if process is a real time process
                reporter.completed_real_time += 1;
                
                // check if the entry was completed after the deadline
                if(entry->process.completion_time > entry->process.deadline){
                    // if it was, then it missed the deadline
                    reporter.real_time_missed_deadline += 1;
                }
            }

            if(entry->process.type == INTERACTIVE){
                reporter.completed_interactive += 1;
            }

            
            std::cout << std::endl << std::endl;
            std::cout << "This process has been terminated. The process sequence number is " << entry->process_sequence_number << std::endl;

            std::cout << "The process took " << time_elapsed << " miliseconds to complete." << std::endl;

            std::cout << "This process was completed at: " << entry->process.completion_time << " miliseconds." <<  std::endl;

            // deletes pointer which also deletes the entry object
            delete(entry);

            // erase index of entry
            process_table.erase(process_table.begin() + index);

            std::cout << std::endl << std::endl;

            break;

        }
        index++;
    }
}

// schedules the cpu
void scheduleCPU(){

    if (cpu_queue.empty()){
        return;
    }

    // if the first process of the queue is done
    if(cpu_queue.front()->process.resource_requests.front().duration == 0){

        std::cout << std::endl << "The duration has reached 0 and therefore the CPU is now free. The CPU has been removed from process number: " << cpu_queue.front()->process_sequence_number << std::endl;

        // pops the resource in the first process
        cpu_queue.front()->process.resource_requests.pop_front();

        std::string shift = cpu_queue.front()->process.type;

        // sets to ready
        cpu_queue.front()->current_status = READY;
        // pops from cpu queue
        cpu_queue.pop();

        // if a real time process is at the front, then it shifts any other real time process up to take its place
        if( shift == REAL_TIME){

            // shifts any real time process up
            for(int i = 0; i < cpu_queue.size(); i++){
                    if( cpu_queue.front()->process.type == REAL_TIME){
                        break;
                    }else{
                        std::cout << "Moving real time process up." << std::endl;
                        cpu_queue.push(cpu_queue.front());
                        cpu_queue.pop();
                    }
                }

        }
        


        return;

    }

    reporter.cpu_utilization++;
    cpu_queue.front()->process.resource_requests.front().duration--;
    

}

// schedules the disk
void scheduleDISK(){
    if (disk_queue.empty()){
        return;
    }

    if(disk_queue.size() > 1){
        reporter.duration_of_waiting_disk++;
    }

    if(disk_queue.front()->process.resource_requests.front().duration == 0){

        std::cout << std::endl << "The duration has reached 0 and therefore the DISK is now free. The DISK has been removed from process number: " << disk_queue.front()->process_sequence_number << std::endl;

        disk_queue.front()->process.resource_requests.pop_front();
        disk_queue.front()->current_status = READY;
        disk_queue.pop();

        return;

    }

    reporter.disk_utilization++;
    disk_queue.front()->process.resource_requests.front().duration--;
}

// schedule the terminal
void scheduleTTY(){

    if (terminal_deque.empty()){
        return;
    }
    

    for(int i = 0; i < terminal_deque.size(); i++)
    {
        
    
    if(terminal_deque[i]->process.resource_requests.front().duration == 0){

        std::cout << std::endl << "The duration has reached 0 and therefore the TERMINAL is now free. The TERMINAL has been removed from process number: " << terminal_deque[i]->process_sequence_number << std::endl;

        terminal_deque[i]->process.resource_requests.pop_front();
        terminal_deque[i]->current_status = READY;
    
        terminal_deque.erase(
            terminal_deque.begin() + i
        );
        

        return;

    }

    terminal_deque[i]->process.resource_requests.front().duration--;
    }

    

}

// schedule a single process 
void scheduleProcess(){

    // scan through process table
    for(auto& entry: process_table){

        // if the process has empty resource requests then termoinate it
        if(entry->process.resource_requests.empty()){
            entry->current_status = DONE;
            entry->process.completion_time = miliseconds;
            terminateProcess();
            return;
        }

        if(entry->current_status != READY){
            continue;
        }
        
        
        if(entry->process.resource_requests.front().type == CPU)
        {
            entry->current_status = RUNNING;
            std::cout << "Putting the process number:  " << entry->process_sequence_number << " in the CPU queue." <<  std::endl;
            cpu_queue.push(entry);
            
            if(entry->process.type == REAL_TIME){
               //  shift queue
            for(int i = 0; i < cpu_queue.size(); i++){
                if( cpu_queue.front()->process.type == REAL_TIME){
                    break;
                }else{
                    std::cout << "Moving any real time process up." << std::endl;
                    cpu_queue.push(cpu_queue.front());
                    cpu_queue.pop();
                }
                } 
            }
            
            
        }
        else if(entry->process.resource_requests.front().type == DISK){
            entry->current_status = RUNNING;
            std::cout << "Putting the process number:  " << entry->process_sequence_number << " in the DISK queue." <<  std::endl;
            reporter.disk_accesses++;

            disk_queue.push(entry);

        } 
        else if(entry->process.resource_requests.front().type == TTY){
            entry->current_status = RUNNING;
            std::cout << "Putting the process number:  " << entry->process_sequence_number << " in the TERMINAL queue." <<  std::endl;

            terminal_deque.push_back(entry);

        }

    }

}

// prints the summary using reporter
void printSummary(){
    std::cout << std::endl << reporter.completed_real_time << " Real Time processes have been completed." << std::endl;

    float misseddeadline = (float)reporter.real_time_missed_deadline/ (float)reporter.completed_real_time;

    std::cout << "The percentage of real-time processes that missed their deadline is " << misseddeadline*100 << "%" << std::endl;

    std::cout << reporter.completed_interactive << " Interactive processes have been completed." << std::endl;

    std::cout << "The disk was accessed " << reporter.disk_accesses << " times."<< std::endl;

    if(reporter.disk_accesses != 0){
        reporter.duration_of_disk_access = reporter.disk_utilization / reporter.disk_accesses;
    }
    
    std::cout << "The average duration of a disk access is " << reporter.duration_of_disk_access << " miliseconds. " << std::endl;

    std::cout <<"The average waiting time in the disk queue is " << reporter.duration_of_waiting_disk << " miliseconds. "<< std::endl;

    std::cout << "Total time elapsed since the start of the first process is "<< reporter.totaltimeelapsed << " miliseconds." << std::endl;

    if(reporter.totaltimeelapsed == 0){
        return;
    }

    float cpuutil = (float)reporter.cpu_utilization / (float)reporter.totaltimeelapsed;

    std::cout <<"The CPU utilization is "<< cpuutil*100 << "%" << std::endl;

    float diskutil = (float)reporter.disk_utilization / (float)reporter.totaltimeelapsed;


    std::cout <<"The Disk utilization is " << diskutil*100 << "%" << std::endl;


}

void stimulate_process(){
    // check if program is done
    bool done = false;
    
    // sorts waiting queues by start time
    sortByStartTime();

    // start time of the first process
    int first_start_time = std::min(waiting_interactive_queue.front().start_time, waiting_real_time_queue.front().start_time);

    while(!done){

        // if all queues and process table is empty, break from the loop
        if(waiting_interactive_queue.empty() && waiting_real_time_queue.empty() && ready_real_time_queue.empty() && ready_interactive_queue.empty() && process_table.empty()){
            done = true;
            break;
        }

        // add waiting queues to ready q
        addToReadyQ();
        // add ready q to process table
        addtoProcessTable();

        // schedule process
        scheduleProcess();

        // schedulers
        scheduleCPU();
        scheduleDISK();
        scheduleTTY();

        miliseconds++;
    }

    std::cout << std::endl;
    reporter.totaltimeelapsed = miliseconds - first_start_time;
    printSummary();

}

int main() {

    std::string line;
    std::string contents;
    // put every input into a string
    while (getline(std::cin, line)) {
        contents = contents + " " + line;
     }

    std::stringstream iss(contents);

    std::string type_str;

    // read the string until its empty
    while(iss >> type_str){

        std::string request_type_str;
        Process process;
        
        // checks if its interactive or real time
        if (type_str == INTERACTIVE || type_str == "I") {
            process.type = INTERACTIVE;
            // scans start time
            iss >> process.start_time;

        } else if (type_str == REAL_TIME || type_str == "R") {
            process.type = REAL_TIME;
            iss >> process.start_time;

            // if real time, scans deadline
            std::string deadline;
            iss >> deadline;

            iss >> process.deadline;
        }
        
        // reads resource requests until real time and interactive is read
        while (iss >> request_type_str) {  
            
            // checks if the string is not real time or interactive
            if (request_type_str == REAL_TIME  || request_type_str == INTERACTIVE || request_type_str == "R" || request_type_str == "I") {
                // puts back the first char of real time or interactive into the stream
                iss.putback(request_type_str[0]);
                break;
            }

        
            // achecks the type of resource and adds it into the process
            Process::ResourceRequest request;
            if (request_type_str == CPU) {
                request.type = CPU;
                
            } else if (request_type_str == DISK) {
                request.type = DISK;
            } else if (request_type_str == TTY) {
                request.type = TTY;
            }
            iss >> request.duration;
            
            process.resource_requests.push_back(request);

        }

        // if process is real time push to real time queue otherwise to interactive queue
        if (process.type == REAL_TIME) {

            waiting_real_time_queue.push_back(process);

        } else {

            waiting_interactive_queue.push_back(process);

        }
     }
    

    stimulate_process();
    return 0;
}


